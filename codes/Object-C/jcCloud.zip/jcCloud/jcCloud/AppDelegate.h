//
//  AppDelegate.h
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
//from own cloud app
#import "PrepareFilesToUpload.h"
#import "UploadsOfflineDto.h"
#import "JCPictureVCViewController.h"
#import "JCMusicPlayer.h"
#import "JCVideoVC.h"
#import "JCAllFilesVC.h"

@class OCCommunication;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,assign)  BOOL isNet;
@property(nonatomic,assign) BOOL isWiFi;

@property (nonatomic, strong) PrepareFilesToUpload *prepareFiles;//文件上传工具类
@property (nonatomic, strong) NSMutableArray *uploadArray;//已上传文件集合
@property (nonatomic, strong) JCPictureVCViewController *presentFilesViewController;//我的照片
@property (nonatomic, strong) JCVideoVC *videoFileVC;//我的视频
@property (nonatomic, strong) JCAllFilesVC *allFileVC;//综合文件
@property (nonatomic) long dateLastRelaunch;

//@property(nonatomic,strong)JCMusicPlayer * musicPlayer;


/*
 * Method to get a Singleton of the OCCommunication to manage all the communications
 */
+ (OCCommunication*)sharedOCCommunication;

- (void) updateProgressView:(NSUInteger)num withPercent:(float)percent;
- (void) updateRecents;
- (void) initUploadsOffline;

/*
 * Method that relaunch upload failed without timeout
 */
- (void) relaunchUploadsFailedForced;

@end


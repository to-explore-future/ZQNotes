//
//  JCForgetPassWordVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/3/20.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCForgetPassWordVC.h"
#import "Masonry.h"
#import "Utils.h"
#import "JCForgetpassWordNext.h"

@interface JCForgetPassWordVC ()

@property(nonatomic,strong)UIImageView * bg;
@property(nonatomic,strong)UIView * titleview;
@property(nonatomic,strong)UIButton * backBtn;
@property(nonatomic,strong)UILabel * viewTitle;
//手机号 验证码
@property(nonatomic,strong)UIView * phoneSecurityBg;
@property CGFloat phoneSecurityBgHeight;
@property(nonatomic,strong)UITextField * phoneNum;
@property(nonatomic,strong)UITextField * securityNum;
@property(nonatomic,strong)UIView * aline;
@property(nonatomic,strong)UIButton * getSecurityCode;
@property(nonatomic,strong)UIButton * nextStep;


@end

@implementation JCForgetPassWordVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setHidden:YES];
    //styleblack 就是白色字  lightstyle 就是黑色字 为了能看到
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    [self initView];
    // Do any additional setup after loading the view.
}

-(void)initData{
    self.phoneSecurityBgHeight = 125;
}

-(void)initView{
    [self.view addSubview:self.bg];
    [self.bg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    [self.view addSubview:self.titleview];
    [self.titleview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(self.view);
        make.height.mas_equalTo(64);
    }];
    //给titleView添加子view
    [self.titleview addSubview:self.backBtn];
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.titleview.mas_bottom);
        make.left.mas_equalTo(self.titleview.mas_left).offset(5);
        make.height.width.mas_equalTo(44);
    }];
    
    [self.titleview addSubview:self.viewTitle];
    [self.viewTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.backBtn.mas_centerY);
        make.centerX.mas_equalTo(self.titleview.mas_centerX);
    }];
    
    [self.view addSubview:self.phoneSecurityBg];
    [self.phoneSecurityBg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(10);
        make.right.mas_equalTo(self.view).offset(-10);
        make.top.mas_equalTo(self.titleview.mas_bottom).offset(95);
        make.height.mas_equalTo(self.phoneSecurityBgHeight);
    }];
    
    [self.view addSubview:self.nextStep];
    [self.nextStep mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.phoneSecurityBg);
        make.top.mas_equalTo(self.phoneSecurityBg.mas_bottom).offset(35);
        make.height.mas_equalTo(52);
    }];
    
    [self.phoneSecurityBg addSubview:self.phoneNum];
    [self.phoneNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.phoneSecurityBg.mas_top).offset(self.phoneSecurityBgHeight / 4);
        make.left.mas_equalTo(self.phoneSecurityBg).offset(10);
        make.height.mas_equalTo(self.phoneSecurityBgHeight / 2);
        make.width.mas_equalTo(self.phoneSecurityBg.mas_width);
    }];
    
    [self.phoneSecurityBg addSubview:self.securityNum];
    [self.securityNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.phoneSecurityBg.mas_top).offset(self.phoneSecurityBgHeight * 3 / 4);
        make.left.mas_equalTo(self.phoneSecurityBg).offset(10);
        make.height.mas_equalTo(self.phoneSecurityBgHeight / 2);
        make.width.mas_equalTo(self.phoneSecurityBg.mas_width);
    }];
    
    [self.phoneSecurityBg addSubview:self.aline];
    [self.aline mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.phoneSecurityBg);
        make.height.mas_equalTo(1);
        make.centerY.mas_equalTo(self.phoneSecurityBg.mas_centerY);
    }];
    
    [self.phoneSecurityBg addSubview:self.getSecurityCode];
    [self.getSecurityCode mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.phoneSecurityBg.mas_right).offset(-10);
        make.width.mas_equalTo(120);
        make.height.mas_equalTo(self.phoneSecurityBgHeight / 2 - 20);
        make.centerY.mas_equalTo(self.phoneSecurityBg.mas_centerY).offset(self.phoneSecurityBgHeight / 4);
    }];
    
}

#pragma mark - action

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)nextStepAction{
    //打开下一个界面
    JCForgetpassWordNext * forgetPassWordNext = [[JCForgetpassWordNext alloc] init];
    [self.navigationController pushViewController:forgetPassWordNext animated:YES];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.phoneNum resignFirstResponder];
    [self.securityNum resignFirstResponder];
}

-(void)securityNumAction{
    //验证手机号 手机号是否输入 手机号是否输入正确
    if (![Utils isMobileNumber:self.phoneNum.text]) {
        return;
    }
    //去获取验证码
}

#pragma mark - lazyload

-(UIImageView *)bg{
    if(_bg == nil){
        _bg = [[UIImageView alloc] init];
        [_bg setImage:[UIImage imageNamed:@"登录背景"]];
    }
    return _bg;
}

-(UIView *)titleview{
    if(_titleview == nil){
        _titleview = [[UIView alloc] init];
        //        [_titleview setBackgroundColor:[UIColor greenColor]];
    }
    return _titleview;
}

-(UIButton *)backBtn{
    if(_backBtn == nil){
        _backBtn = [[UIButton alloc] init];
        [_backBtn setImage:[UIImage imageNamed:@"返回箭头"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [_backBtn setImageEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)];
        //        [_backBtn setBackgroundColor:[UIColor redColor]];
    }
    return _backBtn;
}

-(UILabel *)viewTitle{
    if(_viewTitle == nil){
        _viewTitle = [[UILabel alloc] init];
        [_viewTitle setText:@"忘记密码"];
        [_viewTitle setTextColor:[UIColor whiteColor]];
        [_viewTitle setFont:[UIFont systemFontOfSize:24]];
    }
    return _viewTitle;
}

-(UIView *)phoneSecurityBg{
    if(_phoneSecurityBg == nil){
        _phoneSecurityBg = [[UIView alloc] init];
        [_phoneSecurityBg setBackgroundColor:[Utils getColorWithOneValue:255 withAlpha:0.6]];
        _phoneSecurityBg.layer.cornerRadius = 5;
        [_phoneSecurityBg setClipsToBounds:YES];
    }
    return _phoneSecurityBg;
}

-(UIButton *)nextStep{
    if(_nextStep == nil){
        _nextStep = [[UIButton alloc] init];
        [_nextStep setTitle:@"下一步" forState:UIControlStateNormal];
        [_nextStep setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_nextStep setBackgroundColor:[Utils getColorWithOneValue:182]];
        _nextStep.layer.cornerRadius = 5;
        [_nextStep setClipsToBounds:YES];
        [_nextStep addTarget:self action:@selector(nextStepAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _nextStep;
}

-(UIButton *)getSecurityCode{
    if(_getSecurityCode == nil){
        _getSecurityCode = [[UIButton alloc] init];
        [_getSecurityCode setTitle:@"获取验证码" forState:UIControlStateNormal];
        [_getSecurityCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_getSecurityCode setBackgroundColor:[Utils getColorWithRed:77 Green:114 Blue:140]];
        _getSecurityCode.layer.cornerRadius = 5;
        [_getSecurityCode setClipsToBounds:YES];
        [_getSecurityCode addTarget:self action:@selector(nextStepAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _getSecurityCode;
}

-(UITextField *)phoneNum{
    if (_phoneNum == nil) {
        _phoneNum = [[UITextField alloc] init];
        [_phoneNum setPlaceholder:@"请输入手机号"];
        [_phoneNum setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
        [_phoneNum setValue:[UIFont boldSystemFontOfSize:18] forKeyPath:@"_placeholderLabel.font"];
    }
    return _phoneNum;
}

-(UITextField *)securityNum{
    if (_securityNum == nil) {
        _securityNum = [[UITextField alloc] init];
        [_securityNum setPlaceholder:@"请输入验证码"];
        [_securityNum setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
        [_securityNum setValue:[UIFont boldSystemFontOfSize:18] forKeyPath:@"_placeholderLabel.font"];
        [_securityNum addTarget:self action:@selector(securityNumAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _securityNum;
}

-(UIView *)aline{
    if (_aline == nil) {
        _aline = [[UIView alloc] init];
        [_aline setBackgroundColor:[Utils getColorWithOneValue:200 withAlpha:0.9]];
    }
    return _aline;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

//
//  BaseVC.m
//  baidufanyiTest
//
//  Created by sharingmobile on 2018/2/24.
//  Copyright © 2018年 sharingmobile. All rights reserved.
//

#import "BaseVC.h"

@interface BaseVC ()

@end

@implementation BaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initNotification];
    [self initData];
    [self initFrame];
    [self loadData];
    
}

-(void)initNotification{
    
}

-(void)initData{
    
}

-(void)initFrame{
    
}

-(void)loadData{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

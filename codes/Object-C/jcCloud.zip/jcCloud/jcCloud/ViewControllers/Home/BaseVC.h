//
//  BaseVC.h
//  baidufanyiTest
//
//  Created by sharingmobile on 2018/2/24.
//  Copyright © 2018年 sharingmobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseVC : UIViewController

@end

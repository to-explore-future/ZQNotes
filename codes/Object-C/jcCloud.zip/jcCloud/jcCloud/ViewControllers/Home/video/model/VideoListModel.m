//
//VideoListModel.m 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "VideoListModel.h"
@implementation VideoListModel

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

@end
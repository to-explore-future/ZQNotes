//
//  JCVideoDayListVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/13.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoListModelOcsDataVideos.h"

@interface JCVideoDayListVC : UIViewController

-(void)setDayListData:(VideoListModelOcsDataVideos *)videos;

@end

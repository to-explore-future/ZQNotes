//
//VideoListModelOcs.h 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "VideoListModelOcsMeta.h"
#import "VideoListModelOcsData.h"
@interface VideoListModelOcs:NSObject
@property (nonatomic,strong) VideoListModelOcsMeta *meta;
@property (nonatomic,strong) VideoListModelOcsData *data;

@end
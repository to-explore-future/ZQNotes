//
//  JCVideoVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/8.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCVideoVC.h"
#import "JCPictureVCViewController.h"
#import "NHHomeHeaderOptionalView.h"
#import "NHCustomSlideViewController.h"
#import "JCDayPicVC.h"
#import "DKNetworking.h"
#import "PicList.h"
#import "PicListOcsDataImages.h"
#import "PicListOcsDataImagesFiles.h"
#import "JCCustomCollectionViewCell.h"
#import "JCPicListHeaderCell.h"
#import "JCSliderShowVC.h"
#import "JCWaterFallPicModel.h"
#import "PicForder.h"
#import "JCPicForderListCell.h"
#import "PicForderOcsDataFiles.h"
#import "JCCommenToolView.h"
#import "ELCImagePickerController.h"
#import "ELCAlbumPickerController.h"
#import "MJRefresh.h"
#import "VideoListModel.h"
#import "JCVideListCell.h"
#import "JCVideoPlayVC.h"
#import "JCVideoDayListVC.h"
#import "YFKit.h"
#import "AppDelegate.h"
#import "FileNameUtils.h"
#import "NSString+Encoding.h"
#import "UtilsUrls.h"
#import "OCCommunication.h"

#define screenWidth [[UIScreen mainScreen] bounds].size.width

#define XXWeakSelf(object) __weak __typeof(object) weakSelf = object;

@interface JCVideoVC ()<NHCustomSlideViewControllerDataSource, NHCustomSlideViewControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,ELCImagePickerControllerDelegate,UIActionSheetDelegate>{
    UIButton *channelChangeBtn;
    CGFloat itemWidth ;
    CGFloat titleViewHeight;
    CGFloat folderBtnWidth;
    CGFloat tableViewCellHeight;
    Boolean isSelectStatus;
    NSInteger picNeedMoreCount;         //加载更多次数
    NSInteger forderNeedMoreCount;
    NSNumber * sort;
    NSNumber * direction;
    
    JCCommenToolView *bottomToolView;
    int getPicFolderTime;
}

@property(nonatomic,strong)     NHHomeHeaderOptionalView    * optionalView;
@property(nonatomic,  weak)     NHCustomSlideViewController * slideViewController;
@property(nonatomic,strong)     NSMutableArray          * controllers;
@property(nonatomic,strong)     NSArray                 * titles;
@property(nonatomic,assign)     NSInteger                 nowIndex;//当前选中索引值
@property(nonatomic,strong)     VideoListModel          * videoListModel;
@property(nonatomic,strong)     UICollectionView        * collectionView;
@property(nonatomic,strong)     NSMutableArray          * waterFallPics;
@property(nonatomic,strong)     UIView                  * titleView; //显示方式的分类
@property(nonatomic,strong)     UISegmentedControl      * segmentControl;
@property(nonatomic,strong)     UIView                  * folderActionBtnsView;
@property(nonatomic,strong)     UIButton                * addFolder;
@property(nonatomic,strong)     UIButton                * upload;
@property(nonatomic,strong)     UIButton                * sort;
@property(nonatomic,strong)     UIView                  * aline;
@property(nonatomic,strong)     UITableView             * tableView;
@property(nonatomic,strong)     PicForder               * picForder;

@property CGFloat colletionViewHeaderHeight;
@property (nonatomic, strong) ELCAlbumPickerController *albumController;
@property (nonatomic, strong) ELCImagePickerController *elcPicker;

@end

@implementation JCVideoVC

-(void)viewWillAppear:(BOOL)animated{
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    app.videoFileVC=self;

    [self.tabBarController.tabBar setHidden:YES];
    self.navigationController.navigationBar.topItem.title = @"";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selfPushSelfRightArrowAction:) name:@"JCPicForderListCellRightArrowAction" object:nil];
    if ([self.selectedStatus isEqualToString:@"dir"]) {
        [self.folderActionBtnsView setHidden:NO];
        [self.tableView setHidden:NO];
        [self.collectionView setHidden:YES];
    }else{
        [self.folderActionBtnsView setHidden:YES];
        [self.tableView setHidden:YES];
        [self.collectionView setHidden:NO];
    }
    if ([self.isBasePath isEqualToString:@"isBase"]) {
        [self.segmentControl setHidden:NO];
        self.title = @"我的视频";
        self.navigationController.navigationBar.topItem.title = @"我的视频";
    }else{
        [self.segmentControl setHidden:YES];
        [self getPicFolder];
        NSArray * whichIs = [self.currenPageDirPath componentsSeparatedByString:@"/"];
        NSInteger position = whichIs.count;
        self.title = whichIs[position - 2];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"JCPicForderListCellRightArrowAction" object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNotification];
    [self initData];
    self.title = @"我的视频";
    //搞一个名称数组
//    self.titles = @[@"11"];
//    self.optionalView.titles = self.titles;
//    //根据数组的长度 生成 slideView的vcs
//    for (int i = 0; i < self.titles.count; i++) {
//        UIViewController * vc = [[UIViewController alloc] init];
//        [vc.view setBackgroundColor:[UIColor whiteColor]];
//        [self.controllers addObject:vc];
//    }
//    [self.view addSubview:self.optionalView];
//    XXWeakSelf(self);
//    self.optionalView.homeHeaderOptionalViewItemClickHandle = ^(NHHomeHeaderOptionalView *view, NSString *currentTitle, NSInteger currentIndex) {
//        weakSelf.slideViewController.seletedIndex = currentIndex;
//        weakSelf.nowIndex = currentIndex;
//    };
//    [self addChildViewController:self.slideViewController];
//    [self.slideViewController initializedViewControllerAtIndex:0];
    
    //添加collectionView
    [self.view setBackgroundColor:[UIColor whiteColor]];
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc] init];
    
    layout.headerReferenceSize = CGSizeMake(10, self.colletionViewHeaderHeight);
    //设置布局方向为垂直流布局
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    CGFloat itemSpace = 3;
    CGFloat itemCount = 3;
    itemWidth =(screenWidth - ((itemCount - 1)* itemSpace)) / itemCount;
    //假如设置宽高相等
    layout.itemSize = CGSizeMake(itemWidth, itemWidth);
    //创建
    CGRect frame = CGRectMake(0, 64 + titleViewHeight, kScreen_width, kScreen_height - 64 - titleViewHeight);
    self.collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:layout];
    self.collectionView.showsVerticalScrollIndicator = NO;
    [self.collectionView setBackgroundColor:[UIColor whiteColor]];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        //加载更多代码
        picNeedMoreCount ++;
        [self getPicsFromNetwork];
    }];
    
    //需要注册一个 cell 可以自定义
    [self.collectionView registerClass:[JCVideListCell class] forCellWithReuseIdentifier:@"videocellid"];
    [self.collectionView registerClass:[JCPicListHeaderCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView"];
    [self.view addSubview:self.collectionView];
    
    [self.tableView registerClass:[JCPicForderListCell class] forCellReuseIdentifier:@"tableviewcell"];
    
    //生成头部的titleview
    [self initView];
    [self loadData];
    
    CGRect boxFrame=CGRectMake(0,kScreen_height, kScreen_width, 50);
    bottomToolView=[[JCCommenToolView alloc] initWithFrame:boxFrame isHidden:NO];
    [self.view addSubview:bottomToolView];
    [bottomToolView setHidden:YES];
}

-(void)initNotification{
    //打开瀑布流界面
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rightArrowAction:) name:@"videoListRightArrowAction" object:nil];
}


-(void)initData{
    self.colletionViewHeaderHeight = 40;
    titleViewHeight = 50;
    folderBtnWidth = 20;
    tableViewCellHeight = 60;
    picNeedMoreCount = 1;
    forderNeedMoreCount = 1;
    sort = @1;
    direction = @1;
    getPicFolderTime = 0;
    
}

-(void)initView{
    [self.view addSubview:self.titleView];
    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top).offset(64);
        make.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(titleViewHeight);
    }];
    [self.titleView addSubview:self.segmentControl];
    [self.segmentControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.titleView).offset(10);
        make.centerY.mas_equalTo(self.titleView.mas_centerY);
        make.width.mas_equalTo(140);
        make.height.mas_equalTo(titleViewHeight - 20);
    }];
    [self.titleView addSubview:self.folderActionBtnsView];
    [self.folderActionBtnsView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.bottom.mas_equalTo(self.titleView);
        make.left.mas_equalTo(self.segmentControl.mas_right);
    }];
    [self.folderActionBtnsView addSubview:self.addFolder];
    [self.folderActionBtnsView addSubview:self.upload];
    [self.folderActionBtnsView addSubview:self.sort];
    [self.sort mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.folderActionBtnsView.mas_right).offset(-10);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 33);
        make.width.mas_equalTo(folderBtnWidth);
    }];
    [self.upload mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.sort.mas_left).offset(-30);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 30);
        make.width.mas_equalTo(folderBtnWidth);
    }];
    [self.addFolder mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.upload.mas_left).offset(-30);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 30);
        make.width.mas_equalTo(folderBtnWidth + 5);
    }];
    [self.view addSubview:self.aline];
    [self.aline mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(0.5);
        make.top.mas_equalTo(self.titleView.mas_bottom);
    }];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.titleView.mas_bottom);
        make.bottom.mas_equalTo(self.view.mas_bottom);
    }];
    //添加上啦加载
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        forderNeedMoreCount ++;
        [self getPicFolder];
    }];
    
    //标题右侧的连个button
    UIBarButtonItem * right1 = [[UIBarButtonItem alloc] initWithTitle:@"选择" style:UIBarButtonItemStyleDone target:self action:@selector(selectBtnAction)];
    
    self.navigationItem.rightBarButtonItem = right1;
    
    UIBarButtonItem * right2 = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStyleDone target:self action:@selector(right2Action)];
    NSArray * rightBtns = [NSArray arrayWithObjects:right1,right2, nil];
    self.navigationItem.rightBarButtonItems = rightBtns;
}

-(void)loadData{
    if ([self.isBasePath isEqualToString:@"isBase"]) {
        [self getPicsFromNetwork];
    }
    
}

-(void)getPicsFromNetwork{
    self.collectionView.mj_footer.state = MJRefreshStatePulling;
    [Utils showHUD:self.navigationController.view];
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_video/api/v1/list?format=json";
    //https://x.x.x.x /ocs/v1.php/apps/jiacc_video /api/v1/list
    NSString * page = [NSString stringWithFormat:@"%ld",picNeedMoreCount];
    NSDictionary * param = @{
                             @"page":page,
                             @"pagecount":@"20"
                             };
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [Utils hideHUD];
        NSLog(@"json = %@",[Utils id2Json:responseObject]);
        if (picNeedMoreCount == 1) {
            self.videoListModel = [VideoListModel mj_objectWithKeyValues:responseObject];
            if (self.videoListModel.ocs.data.videos.count < 20) {
                self.collectionView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }else{
            [self.collectionView.mj_footer endRefreshing];
            VideoListModel * videoList = [VideoListModel mj_objectWithKeyValues:responseObject];
//            更多次请求数据
//            判断后台是否返回了更多的数据
            NSArray * moreData = videoList.ocs.data.videos;
            NSInteger count = moreData.count;
            //继续解析 如果数据库还有数据 那么 把数据中images 集合中的 元素添加到 self.picList中
            for (NSInteger i = 0; i < count; i++) {
                VideoListModelOcsDataVideosFiles * video = moreData[i];
                [self.videoListModel.ocs.data.videos addObject:video];
            }
            if (count < 20) {
                self.collectionView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }
        //数据拿下来 重新刷新数据
        [self.collectionView reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}

-(void)getPicFolder{
    self.tableView.mj_footer.state = MJRefreshStatePulling;
    [Utils showHUD:self.navigationController.view];
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_files/api/v1/list?format=json";
    NSString * page = [NSString stringWithFormat:@"%ld",forderNeedMoreCount];
    NSDictionary * param = @{
                             @"page":page,
                             @"pagecount":@"20",
                             @"dir":self.currenPageDirPath,
                             @"mimetype_filter":@"video",
                             @"sort":sort,
                             @"direction":direction,
                             };
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [Utils hideHUD];
        NSLog(@"jsonpic = %@",[Utils id2Json:responseObject]);
        [self.tableView.mj_footer endRefreshing];
        if (forderNeedMoreCount == 1) {
            self.picForder = [PicForder mj_objectWithKeyValues:responseObject];
            if (self.picForder.ocs.data.files.count < 20) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }else{
            PicForder * tempPicForder = [PicForder mj_objectWithKeyValues:responseObject];
            NSArray * files = tempPicForder.ocs.data.files;
            NSInteger count = files.count;
            for (NSInteger i = 0; i < count; i++) {
                PicForderOcsDataFiles * file = files[i];;
                [self.picForder.ocs.data.files addObject:file];
            }
            if (count < 20) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }
        [self.tableView reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}

- (BOOL)navigationShouldPopOnBackButton{
    
    if ([self.currenPageDirPath isEqualToString:@"/"]) {
        for (UIViewController *controller in self.navigationController.viewControllers) {
            if ([controller isKindOfClass:[JCHomeVC class]]) {
                JCHomeVC *home =(JCHomeVC *)controller;
                [self.navigationController popToViewController:home animated:YES];
                break;
            }
        }
        return NO;
    }else {
        return YES;
    }
    
    
    
}

#pragma mark - action

-(void)rightArrowAction:(NSNotification *)notification{
    UIButton * btn = (UIButton *)[notification object];
    NSInteger section = btn.tag;
//    打开视频某一天的详情的
    VideoListModelOcsDataVideos * video = self.videoListModel.ocs.data.videos[section];
    JCVideoDayListVC * videoList = [[JCVideoDayListVC alloc] init];
    [videoList setDayListData:video];
    [self.navigationController pushViewController:videoList animated:YES];
    
}

//自己push 自己
-(void)selfPushSelfRightArrowAction:(NSNotification *)notification{
//    NSString * path = (NSString *)[notification object];
//    NSLog(@"path = %@",path);
//    //push到下一个页面 把请求的 路径拼接好 展示出来
//    NSString * nextPath = @"";
//    if ([self.currenPageDirPath isEqualToString:@"/"]) {
//        nextPath = [NSString stringWithFormat:@"/%@/",path];
//    }else{
//        nextPath = [NSString stringWithFormat:@"%@/%@/",self.currenPageDirPath,path];
//    }
//    JCPictureVCViewController * pic = [[JCPictureVCViewController alloc] init];
//    pic.currenPageDirPath = nextPath;
//    pic.selectedStatus = self.selectedStatus;
//    [self.navigationController pushViewController:pic animated:YES];
}

-(void)segmmentedAction{
    switch (self.segmentControl.selectedSegmentIndex) {
        case 0:
            [self.folderActionBtnsView setHidden:YES];
            [self.tableView setHidden:YES];
            self.selectedStatus = @"pic";
            [self.collectionView setHidden:NO];
//            [self getPicsFromNetwork];
            break;
        case 1:
            [self.folderActionBtnsView setHidden:NO];
            [self.tableView setHidden:NO];
            self.selectedStatus = @"dir";
            [self.collectionView setHidden:YES];
            
            getPicFolderTime ++;
            if (getPicFolderTime == 1) {
                [self getPicFolder];
            }
            
            break;

        default:
            break;
    }
}

//刷新页面
-(void)selectBtnAction{
    UIBarButtonItem * right1 = self.navigationItem.rightBarButtonItems[0];
    
    if ([right1.title isEqualToString:@"选择"]) {
        //目前是选择状态
        isSelectStatus = YES;
        right1.title = @"取消";
        [bottomToolView setHidden:NO];
        
    }else if([right1.title isEqualToString:@"取消"]){
        right1.title = @"选择";
        isSelectStatus = NO;
        //所有的数据的选择状态都取消
        NSArray * videos = self.videoListModel.ocs.data.videos;
        for (int i = 0; i < videos.count; i++) {
            VideoListModelOcsDataVideos * video = videos[i];
            NSArray * files = video.files;
            for (int j = 0; j < files.count; j++) {
                VideoListModelOcsDataVideosFiles * file = files[j];
                file.isSelected = false;
            }
        }
        
        [bottomToolView setHidden:YES];
    }
    [self.collectionView reloadData];
}

-(void)right2Action{
    
}

/*
 * This method show an pop up view to create folder
 */
-(void)addFolderAction{
    NSLog(@"current dir = %@",self.currenPageDirPath);
    _folderView = [[UIAlertView alloc]initWithTitle:@"新建文件夹" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"保存", nil];
    _folderView.alertViewStyle = UIAlertViewStylePlainTextInput;
    [_folderView textFieldAtIndex:0].delegate = self;
    [[_folderView textFieldAtIndex:0] setAutocorrectionType:UITextAutocorrectionTypeNo];
    [[_folderView textFieldAtIndex:0] setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    
    [_folderView show];
}

-(void)sortAction{
    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:@"排序" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"按文件名称排序",@"按文件倒叙排序", nil];
    [actionSheet showInView:self.view];
    actionSheet.delegate = self;
}

#pragma mark - delegate <NHCustomSlideViewControllerDataSource, NHCustomSlideViewControllerDelegate >

- (NSInteger)numberOfChildViewControllersInSlideViewController:(NHCustomSlideViewController *)slideViewController {
    return self.titles.count;
}

- (UIViewController *)slideViewController:(NHCustomSlideViewController *)slideViewController viewControllerAtIndex:(NSInteger)index {
    return self.controllers[index];
}

- (void)customSlideViewController:(NHCustomSlideViewController *)slideViewController slideOffset:(CGPoint)slideOffset {
    self.optionalView.contentOffset = slideOffset;
}

- (void)customSlideViewController:(NHCustomSlideViewController *)slideViewController slideIndex:(NSInteger)slideIndex{
    self.nowIndex = slideIndex;
}

#pragma mark - delegate collectionview delegate

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.videoListModel.ocs.data.videos.count;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    VideoListModelOcsDataVideos * videos = self.videoListModel.ocs.data.videos[section];
    
    NSInteger count = videos.files.count;
    //    if (isSelectStatus) {
    //        return count;
    //    }else{
    if (count >= 3) {
        return 3;
    }else{
        return count;
    }
    //    }
//    return 3;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    JCVideListCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"videocellid" forIndexPath:indexPath];
//    [cell setBackgroundColor:[UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1]];
    //每个cell 在屏幕上的实际的大小
    NSString * itemSize = [NSString stringWithFormat:@"/%f/%f/",itemWidth,itemWidth];
    
    VideoListModelOcsDataVideos * videos = self.videoListModel.ocs.data.videos[indexPath.section];
    VideoListModelOcsDataVideosFiles * file = videos.files[indexPath.row];
    NSString * imagePath = file.path;

    //拼接
    NSString * allURL = [NSString stringWithFormat:@"%@%@%@",picBaseURL,itemSize,imagePath];
    NSString * url_utf8 = [allURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [cell imageSetURL:url_utf8];
    
    //视频名称
    [cell.name setText:file.name];
    
    //根据选中状态 改变cell
    if (file.isSelected) {
        [cell.selectedView setHidden:NO];
        [cell.coveringView setHidden:NO];
    }else{
        [cell.selectedView setHidden:YES];
        [cell.coveringView setHidden:YES];
    }
    
    return cell;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 3;
}

//这个是两行cell之间的间距（上下行cell的间距）
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 3;
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    JCPicListHeaderCell * reusableView;
    if (kind==UICollectionElementKindSectionHeader) {
        reusableView=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
        //        reusableView = [[UICollectionReusableView alloc] initWithFrame:CGRectMake(0, 0, 300, 50)];
    }
    [reusableView setState:@"video"];
    //    reusableView.backgroundColor = [UIColor redColor];
    //拿到网络日期
    VideoListModelOcsDataVideos * videos = self.videoListModel.ocs.data.videos[indexPath.section];
    NSString * timeStr = videos.title;
    //日期
    [reusableView.time setText:timeStr];
    [reusableView.rightArrow setTag:indexPath.section];
    //    if (isSelectStatus) {
    //        [reusableView.selectAllPic setHidden:NO];
    //        [reusableView.rightArrow setHidden:YES];
    //    }else{
    [reusableView.selectAllPic setHidden:YES];
    [reusableView.rightArrow setHidden:NO];
    //    }
    return reusableView;
}

//定义每个Section的四边间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(7, 0, 25, 0);//分别为上、左、下、右
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    VideoListModelOcsDataVideos * videos = self.videoListModel.ocs.data.videos[indexPath.section];
    VideoListModelOcsDataVideosFiles * file = videos.files[indexPath.row];
    
    if (isSelectStatus) {
        //选中状态 改变model的选中状态值
        file.isSelected = !file.isSelected;
        [self.collectionView reloadData];
    }else{
        //点击一个 视频列表 打开视频播放界面
        JCVideoPlayVC * playerVC = [[JCVideoPlayVC alloc] init];
        [playerVC installFile:file];
        [self.navigationController pushViewController:playerVC animated:YES];
    }
    
}

#pragma mark - delegate uitableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.picForder.ocs.data.files.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableViewCellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    JCPicForderListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"tableviewcell"];
    if (cell == nil) {
        cell = [[JCPicForderListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"tableviewcell"];
    }
    //设置数据
    NSArray * array = self.picForder.ocs.data.files;
    NSDictionary * dic = array[indexPath.row];
    PicForderOcsDataFiles * files = [PicForderOcsDataFiles mj_objectWithKeyValues:dic];
    [cell setData:files];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //拿到这个文件或者文件夹名称
    NSArray * array = self.picForder.ocs.data.files;
    NSDictionary * dic = array[indexPath.row];
    PicForderOcsDataFiles * files = [PicForderOcsDataFiles mj_objectWithKeyValues:dic];
    
    //如果点击的是文件 如果自己能够打开 就自己打开,如果自己打不开,就用手机上的其他的应用打开
    if ([files.type isEqualToString:@"file"]) {
        //        if ([files.mimetype isEqualToString:@"image/jpeg"]) {
        //            //这时候把这个文件夹下的所有的图片的路径都扔到 展示图片的那个VC中
        //            JCSliderShowVC * slider = [[JCSliderShowVC alloc] init];
        //            [slider setUrls:array];
        //            [slider setSelectedIndex:indexPath.row];
        //            [self.navigationController pushViewController:slider animated:YES];
        //        }
    }else if([files.type isEqualToString:@"dir"]){
        NSString * path = files.name;
        NSString * nextPath = @"";
        if ([self.currenPageDirPath isEqualToString:@"/"]) {
            nextPath = [NSString stringWithFormat:@"/%@/",path];
        }else{
            nextPath = [NSString stringWithFormat:@"%@/%@/",self.currenPageDirPath,path];
        }
        JCVideoVC * pic = [[JCVideoVC alloc] init];
        pic.currenPageDirPath = nextPath;
        pic.selectedStatus = self.selectedStatus;
        [self.navigationController pushViewController:pic animated:YES];
    }
}

#pragma mark - delegate UIActionSheetDelegate

-(void)actionSheetCancel:(UIActionSheet *)actionSheet{
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            //按照文件名称排序
            sort = @1;
            direction = @1;
            [self getPicFolder];
            break;
            
        case 1:
            //按照文件顺序排序
            sort = @3;
            direction = @1;
            [self getPicFolder];
            break;
            
        default:
            break;
    }
}

#pragma mark - lazyload

- (NHHomeHeaderOptionalView *)optionalView {
    if (!_optionalView) {
        NHHomeHeaderOptionalView *optional = [[NHHomeHeaderOptionalView alloc] init];
        //目前项目需求 没有这个需求 先设置0高度 以后用得到的手 再放开
        optional.frame = CGRectMake(self.view.frame.origin.x, 0, kScreen_width, 40);
        [self.view addSubview:optional];
        _optionalView = optional;
        optional.backgroundColor = [UIColor whiteColor];
    }
    return _optionalView;
}

- (NSMutableArray *)controllers {
    if (!_controllers) {
        _controllers = [NSMutableArray array];
    }
    return _controllers;
}

- (NHCustomSlideViewController *)slideViewController {
    if (!_slideViewController) {
        NHCustomSlideViewController * slide = [[NHCustomSlideViewController alloc] init];
        [slide.view setBackgroundColor:[UIColor clearColor]];
        [slide willMoveToParentViewController:self];
        [self.view addSubview:slide.view];
        slide.view.frame = CGRectMake(0, 64, kScreen_width, kScreen_height - 64 - 49);
        slide.delgate = self;
        slide.dataSource = self;
        _slideViewController = slide;
    }
    return _slideViewController;
}

-(NSMutableArray *)waterFallPics{
    if (_waterFallPics == nil) {
        _waterFallPics = [[NSMutableArray alloc] init];
    }
    return _waterFallPics;
}

-(UIView *)titleView{
    if (_titleView == nil) {
        _titleView = [[UIView alloc]init];
        [_titleView setBackgroundColor:[UIColor whiteColor]];
    }
    return _titleView;
}

-(UISegmentedControl *)segmentControl{
    if (_segmentControl == nil) {
        NSArray *segmentedArray = [[NSArray alloc]initWithObjects:@"视频",@"文件夹",nil];
        _segmentControl = [[UISegmentedControl alloc] initWithItems:segmentedArray];
        if ([self.selectedStatus isEqualToString:@"dir"]) {
            _segmentControl.selectedSegmentIndex = 1;
        }else if([self.selectedStatus isEqualToString:@"pic"]){
            _segmentControl.selectedSegmentIndex = 0;
        }
        
        [_segmentControl addTarget:self action:@selector(segmmentedAction) forControlEvents:UIControlEventValueChanged];
    }
    return _segmentControl;
}

-(UIView *)folderActionBtnsView{
    if (_folderActionBtnsView == nil) {
        _folderActionBtnsView = [[UIView alloc]init];
        [_folderActionBtnsView setBackgroundColor:[UIColor whiteColor]];
        [_folderActionBtnsView setHidden:YES];
    }
    return _folderActionBtnsView;
}

-(UIButton *)addFolder{
    if (_addFolder == nil) {
        _addFolder = [[UIButton alloc] init];
        [_addFolder setImage:[UIImage imageNamed:@"新建文件夹"] forState:UIControlStateNormal];
        [_addFolder addTarget:self action:@selector(addFolderAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _addFolder;
}

-(UIButton *)upload{
    if (_upload == nil) {
        _upload = [[UIButton alloc] init];
        [_upload setImage:[UIImage imageNamed:@"上传"] forState:UIControlStateNormal];
        [_upload addTarget:self action:@selector(upLoadAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _upload;
}

-(UIButton *)sort{
    if (_sort == nil) {
        _sort = [[UIButton alloc] init];
        [_sort setImage:[UIImage imageNamed:@"排序图标"] forState:UIControlStateNormal];
        [_sort addTarget:self action:@selector(sortAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sort;
}

-(UIView *)aline{
    if (_aline == nil) {
        _aline = [[UIView alloc] init];
        [_aline setBackgroundColor:[Utils getColorWithOneValue:230]];
    }
    return _aline;
}

-(UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        [_tableView setBackgroundColor:[UIColor whiteColor]];
        [_tableView setHidden:YES];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        [_tableView setSeparatorInset:UIEdgeInsetsMake(0, 10, 0, 10)];
    }
    return _tableView;
}

-(void)upLoadAction{
    //    if (self.albumController) {
    //        self.albumController = nil;
    //    }
    if (self.elcPicker) {
        self.elcPicker = nil;
    }
    
    //    self.albumController = [[ELCAlbumPickerController alloc] initWithNibName: nil bundle: nil];
    //    self.elcPicker = [[ELCImagePickerController alloc] initWithRootViewController:self.albumController];
    //    [self.albumController setParent: self.elcPicker];
    //    self.elcPicker.imagePickerDelegate = self;
    
    //Info of account and location path
    //    NSString * _currentRemoteFolder = @"http://192.168.133.42/index.php/apps/jiacc_files/api/v1/thumbnail/101.250000/101.250000/我的照片/";
    //    NSArray *splitedUrl = [_currentRemoteFolder componentsSeparatedByString:@"/"];
    //    // int cont = [splitedUrl count];
    //    NSString *folder = [NSString stringWithFormat:@"%@",[splitedUrl objectAtIndex:([splitedUrl count]-2)]];
    
    //    NSLog(@"Folder selected to upload photos is:%@", folder);
    //    if (_fileIdToShowFiles.isRootFolder) {
    //        NSString *appName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
    //        folder=appName;
    //    }
    //
    //    self.albumController.currentRemoteFolder=_currentRemoteFolder;
    //    self.albumController.locationInfo=folder;
    
    //Info of account and location path
    NSString * _currentRemoteFolder = [NSString stringWithFormat:@"%@/remote.php/webdav%@",serverIP,self.currenPageDirPath];
    NSArray *splitedUrl = [_currentRemoteFolder componentsSeparatedByString:@"/"];
    // int cont = [splitedUrl count];
    NSString *folder = [NSString stringWithFormat:@"%@",[splitedUrl objectAtIndex:([splitedUrl count]-2)]];

    // 第一次安装App，还未确定权限，调用这里
    if ([YFKit isPhotoAlbumNotDetermined])
    {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        {
            // 该API从iOS8.0开始支持
            // 系统弹出授权对话框
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied)
                    {
                        // 用户拒绝，跳转到自定义提示页面
                        [self showAlertController:@"提示" message:@"您已拒绝访问相册，可去设置隐私里开启"];
                    }
                    else if (status == PHAuthorizationStatusAuthorized)
                    {
                        // 用户授权，弹出相册对话框
                        //只撸出照片来
                        self.elcPicker = [[ELCImagePickerController alloc]initOnlyVideoPicker:_currentRemoteFolder];
                        self.elcPicker.imagePickerDelegate = self;
                        [self presentViewController:self.elcPicker animated:YES completion:nil];
                    }
                });
            }];
        }
        else
        {
            // 以上requestAuthorization接口只支持8.0以上，如果App支持7.0及以下，就只能调用这里。
            //只撸出照片来
            self.elcPicker = [[ELCImagePickerController alloc]initOnlyVideoPicker:_currentRemoteFolder];
            self.elcPicker.imagePickerDelegate = self;
            [self presentViewController:self.elcPicker animated:YES completion:nil];
        }
    }
    else if ([YFKit isPhotoAlbumDenied])
    {
        // 如果已经拒绝，则弹出对话框
        [self showAlertController:@"提示" message:@"拒绝访问相册，可去设置隐私里开启"];
    }
    else
    {
        // 已经授权，跳转到相册页面
        //只撸出照片来
        self.elcPicker = [[ELCImagePickerController alloc]initOnlyVideoPicker:_currentRemoteFolder];
        self.elcPicker.imagePickerDelegate = self;
        [self presentViewController:self.elcPicker animated:YES completion:nil];
    }

}

- (void)showAlertController:(NSString *)title message:(NSString *)message
{
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - ELCImagePickerControllerDelegate Methods
/*
 * Method Delegate of the upload file selector to bring the selected files
 * @info -> array with the items
 * @remoteURLToUpload -> server path to upload selected files
 */
- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info inURL:(NSString*)remoteURLToUpload
{
    NSLog(@"相册回调：%@\n服务器地址：%@",info,remoteURLToUpload);
    //    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    //
    //    //这两步有JB卵用。。
    //    NSString *path = _nextRemoteFolder;
    //    path = [path stringByRemovingPercentEncoding];
    //
    //    if (!app.userSessionCurrentToken) {
    //        app.userSessionCurrentToken = [UtilsFramework getUserSessionToken];//生成唯一标识符
    //    }
    
    NSDictionary * args = [NSDictionary dictionaryWithObjectsAndKeys:
                           (NSArray *) info, @"info",
                           (NSString *) remoteURLToUpload, @"remoteURLToUpload", nil];//整合开线程所用参数
    [self performSelectorInBackground:@selector(initUploadFileFromGalleryInOtherThread:) withObject:args];
    
    //    app.isUploadViewVisible = NO;
    
}

//开线程，上传数据
- (void)initUploadFileFromGalleryInOtherThread:(NSDictionary *) args {
    //再次拆成俩参数。。。
    NSArray *info = [args objectForKey:@"info"];
    NSString *remoteURLToUpload = [args objectForKey:@"remoteURLToUpload"];
    
    if([info count]>0){
        
        AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //构造PrepareFilesToUpload对象
        if(app.prepareFiles == nil) {
            app.prepareFiles = [[PrepareFilesToUpload alloc] init];
            app.prepareFiles.listOfFilesToUpload = [[NSMutableArray alloc] init];
            app.prepareFiles.listOfAssetsToUpload = [[NSMutableArray alloc] init];
            app.prepareFiles.arrayOfRemoteurl = [[NSMutableArray alloc] init];
            app.prepareFiles.listOfUploadOfflineToGenerateSQL = [[NSMutableArray alloc] init];
        }
        app.prepareFiles.delegate = app;
        app.prepareFiles.counterUploadFiles = 0;
        //        app.uploadTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        //            // If you’re worried about exceeding 10 minutes, handle it here
        //            NSLog(@"上传请求超时，过了10分钟？！");
        //        }];
        
        NSMutableArray *arrayOfRemoteurl = [[NSMutableArray alloc] init];
        
        for (int i = 0 ; i < [info count] ; i++) {
            [arrayOfRemoteurl addObject:remoteURLToUpload];//同样地址存好几遍。。
        }
        
        [self performSelector:@selector(initPrepareFiles:andArrayOFfolders:) withObject:info withObject: arrayOfRemoteurl];
    }
}

//上传数据
- (void) initPrepareFiles:(NSArray *) info andArrayOFfolders: (NSMutableArray *)  arrayOfRemoteurl{
    
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.prepareFiles addAssetsToUploadFromArray:info andRemoteFoldersToUpload: arrayOfRemoteurl];
    
    //Init loading to prepare files to upload
    //    [self initLoading];
    
    //Set global loading screen global flag to YES (only for iPad)
    //    app.isLoadingVisible = YES;
}
#pragma mark - Create Folder

/*
 * This method create new folder in path
 * @name -> it is the name of the new folder
 */
-(void) newFolderSaveClicked:(NSString*)name {
    
    if (![FileNameUtils isForbiddenCharactersInFileName:name withForbiddenCharactersSupported:YES]) {
        
        //Check if exist a folder with the same name
        //        if ([self checkForSameName:name] == NO) {
        
        AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        //            [[AppDelegate sharedOCCommunication] setCredentials:app.activeUser.credDto];
        //
        //            [[AppDelegate sharedOCCommunication] setUserAgent:[UtilsUrls getUserAgent]];
        
        NSString *nowDir = [NSString stringWithFormat:@"%@/remote.php/webdav%@",serverIP,self.currenPageDirPath];
        NSString * newURL = [NSString stringWithFormat:@"%@/remote.php/webdav%@%@",serverIP,self.currenPageDirPath,[name encodeString:NSUTF8StringEncoding]];
        
        //            NSString *newURL = [NSString stringWithFormat:@"%@%@",self.currentRemoteFolder,[name encodeString:NSUTF8StringEncoding]];
        //            NSString *rootPath = [UtilsUrls getFilePathOnDBByFullPath:newURL andUser:app.activeUser];
        
        NSString *pathOfNewFolder = [NSString stringWithFormat:@"%@%@",[nowDir stringByRemovingPercentEncoding], name ];
        
        [[AppDelegate sharedOCCommunication] createFolder:pathOfNewFolder onCommunication:[AppDelegate sharedOCCommunication] withForbiddenCharactersSupported: YES successRequest:^(NSHTTPURLResponse *response, NSString *redirectedServer) {
            NSLog(@"Folder created");
            BOOL isSamlCredentialsError = NO;
            
            //Check the login error in shibboleth
            //                if (k_is_sso_active) {
            //                    //Check if there are fragmens of saml in url, in this case there are a credential error
            //                    isSamlCredentialsError = [FileNameUtils isURLWithSamlFragment:response];
            //                    if (isSamlCredentialsError) {
            //                        [self errorLogin];
            //                    }
            //                }
            if (!isSamlCredentialsError) {
                [self getPicFolder];
            }
        } failureRequest:^(NSHTTPURLResponse *response, NSError *error, NSString *redirectedServer) {
            NSLog(@"error: %@", error);
            NSLog(@"Operation error: %ld", (long)response.statusCode);
            
            BOOL isSamlCredentialsError = NO;
            
            //Check the login error in shibboleth
            //                if (k_is_sso_active) {
            //                    //Check if there are fragmens of saml in url, in this case there are a credential error
            //                    isSamlCredentialsError = [FileNameUtils isURLWithSamlFragment:response];
            //                    if (isSamlCredentialsError) {
            //                        [self errorLogin];
            //                    }
            //                }
            if (!isSamlCredentialsError) {
                //                    [self manageServerErrors:response.statusCode and:error];//先注掉
            }
            
        } errorBeforeRequest:^(NSError *error) {
            if (error.code == OCErrorForbiddenCharacters) {
                //                    [self endLoading];
                NSLog(@"The folder have problematic characters");
                
                NSString *msg = nil;
                msg = @"名字中存在至少一个非法字符。";
                
                _alert = [[UIAlertView alloc] initWithTitle:msg message:@"" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
                [_alert show];
            } else {
                //                    [self endLoading];
                NSLog(@"The folder have problems under controlled");
                _alert = [[UIAlertView alloc] initWithTitle:@"出错了。从服务器收到未知响应消息。" message:@"" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
                [_alert show];
            }
        }];
        //        }else {
        //            [self endLoading];
        //            NSLog(@"Exist a folder with the same name");
        //            _alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"folder_exist", nil) message:@"" delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", nil) otherButtonTitles:nil, nil];
        //            [_alert show];
        //        }
        
    }else{
        //        [self endLoading];
        //Forbidden characters found after the request.
        NSString *msg = nil;
        msg = @"名字中存在至少一个非法字符。";
        
        _alert = [[UIAlertView alloc] initWithTitle:msg message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [_alert show];
        
    }
}

#pragma mark - UIAlertView and UIAlertViewDelegate
- (void) alertView: (UIAlertView *) alertView willDismissWithButtonIndex: (NSInteger) buttonIndex
{
    // cancel
    if( buttonIndex == 1 ){
        //Save "Create Folder"
        
        NSString* result = [alertView textFieldAtIndex:0].text;
        [self performSelector:@selector(newFolderSaveClicked:) withObject:result];
        
    }else if (buttonIndex == 0) {
        //Cancel
        
    }else {
        //Nothing
    }
}


- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    BOOL output = YES;
    
    NSString *stringNow = [alertView textFieldAtIndex:0].text;
    
    
    //Active button of folderview only when the textfield has something.
    NSString *rawString = stringNow;
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    if ([trimmed length] == 0) {
        // Text was empty or only whitespace.
        output = NO;
    }
    
    //Button save disable when the textfield is empty
    if ([stringNow isEqualToString:@""]) {
        output = NO;
    }
    
    return output;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"videoListRightArrowAction" object:nil];
}



@end

//
//  JCVideoDayListVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/13.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCVideoDayListVC.h"
#import "JCCustomCollectionViewCell.h"
#import "JCVideListCell.h"
#import "VideoListModelOcsDataVideosFiles.h"
#import "JCVideoPlayVC.h"

@interface JCVideoDayListVC ()<UICollectionViewDelegate,UICollectionViewDataSource>{
    CGFloat colletionViewHeaderHeight;
    CGFloat itemWidth ;
    CGFloat titleViewHeight;
    CGFloat leftSpace;
    CGFloat rightSpace;
}

@property(nonatomic,strong)     UICollectionView        * collectionView;
@property(nonatomic,strong)     VideoListModelOcsDataVideos * videos;

@end

@implementation JCVideoDayListVC

-(void)setDayListData:(VideoListModelOcsDataVideos *)videos{
    self.videos = videos;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc] init];
    layout.headerReferenceSize = CGSizeMake(10, colletionViewHeaderHeight);
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    CGFloat itemSpace = 3;
    CGFloat itemCount = 3;
    itemWidth =(kScreen_width - ((itemCount - 1)* itemSpace) -leftSpace - rightSpace) / itemCount;
    layout.itemSize = CGSizeMake(itemWidth, itemWidth);
    CGRect frame = CGRectMake(0 + leftSpace, 64 + titleViewHeight, kScreen_width - leftSpace - rightSpace, kScreen_height - 64 - titleViewHeight);
    self.collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:layout];
    [self.collectionView setBackgroundColor:[UIColor greenColor]];
    self.collectionView.showsVerticalScrollIndicator = NO;
    [self.collectionView setBackgroundColor:[UIColor whiteColor]];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
//    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
//        //加载更多代码
////        picNeedMoreCount ++;
////        [self getPicsFromNetwork];
//    }];
    [self.collectionView registerClass:[JCVideListCell class] forCellWithReuseIdentifier:@"dayVideoList"];
//    [self.collectionView registerClass:[JCPicListHeaderCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView"];
    [self.view addSubview:self.collectionView];
}

-(void)initData{
    colletionViewHeaderHeight = 3;
    leftSpace = 3;
    rightSpace = 3;
}

#pragma mark - delegate collectionview delegate

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.videos.files.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    JCVideListCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"dayVideoList" forIndexPath:indexPath];
//    [cell setBackgroundColor:[UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1]];
    NSString * itemSize = [NSString stringWithFormat:@"/%f/%f/",itemWidth,itemWidth];
    VideoListModelOcsDataVideosFiles * file = self.videos.files[indexPath.row];
    NSString * imagePath = file.path;
    
    //拼接
    NSString * allURL = [NSString stringWithFormat:@"%@%@%@",picBaseURL,itemSize,imagePath];
    NSString * url_utf8 = [allURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [cell imageSetURL:url_utf8];
    [cell.name setText:file.name];
    
    return cell;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 3;
}

//这个是两行cell之间的间距（上下行cell的间距）
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 3;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    VideoListModelOcsDataVideosFiles * file = self.videos.files[indexPath.row];
    //点击一个 视频列表 打开视频播放界面
    JCVideoPlayVC * playerVC = [[JCVideoPlayVC alloc] init];
    [playerVC installFile:file];
    [self.navigationController pushViewController:playerVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end

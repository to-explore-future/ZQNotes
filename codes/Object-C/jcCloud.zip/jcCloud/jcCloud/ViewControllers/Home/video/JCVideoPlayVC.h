//
//  JCVideoPlayVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/10.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoListModelOcsDataVideosFiles.h"

@interface JCVideoPlayVC : UIViewController

- (void) installFile:(VideoListModelOcsDataVideosFiles *)file;

@end

//
//  JCVideoPlayVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/10.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCVideoPlayVC.h"
#import "ZFPlayerView.h"

@interface JCVideoPlayVC ()<ZFPlayerDelegate>

@property(nonatomic,strong)ZFPlayerView * playerView;
@property(nonatomic,strong)VideoListModelOcsDataVideosFiles * file;

@end

@implementation JCVideoPlayVC


- (void) installFile:(VideoListModelOcsDataVideosFiles *)file{
    self.file = file;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.file.name;
    UIView * positionView = [[UIView alloc] init];
    [self.view addSubview:positionView];
    [positionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.width.mas_equalTo(self.view.mas_width);
        make.height.mas_equalTo(positionView.mas_width).multipliedBy(9.0f/16.0f);
        make.centerY.mas_equalTo(self.view.mas_centerY);
    }];
    [self.view setBackgroundColor:[Utils getColorWithRed:79 Green:83 Blue:94]];
    self.playerView = [[ZFPlayerView alloc] init];
    
    [positionView addSubview:self.playerView];
    [self.playerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(20);
        make.left.right.equalTo(self.view);
        // 这里宽高比16：9，可以自定义视频宽高比
        make.height.equalTo(self.playerView.mas_width).multipliedBy(9.0f/16.0f);
    }];
    ZFPlayerControlView * controlView = [[ZFPlayerControlView alloc] init];
    
    ZFPlayerModel * playerModel = [[ZFPlayerModel alloc] init];
    //拼接视频的URL
// https://gcs-vimeo.akamaized.net/exp=1523449226~acl=%2A%2F623661526.mp4%2A~hmac=1448b66e55065001aa7de008edd3ca115e05accccff39cc716e810374ccf4307/vimeo-prod-skyfire-std-us/01/2684/7/188421287/623661526.mp4
//    http://test:test@192.168.133.42/remote.php/webdav/我的视频/恶搞.mp4
    NSString * path = self.file.path;
    NSString * urls = [NSString stringWithFormat:@"%@%@",@"http://test:test@192.168.133.42/remote.php/webdav/",path];
    urls = [urls stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL * url = [NSURL URLWithString:urls];
    
//    NSLog(@"user = %@,password = %@",[url user],[url password]);
//    NSLog(@"Scheme: %@", [url scheme]);
//    NSLog(@"Host: %@", [url host]);
//    NSLog(@"Port: %@", [url port]);
//    NSLog(@"Path: %@", [url path]);
//    NSLog(@"Relative path: %@", [url relativePath]);
//    NSLog(@"Path components as array: %@", [url pathComponents]);
//    NSLog(@"Parameter string: %@", [url parameterString]);
//    NSLog(@"Query: %@", [url query]);
//    NSLog(@"Fragment: %@", [url fragment]);
//    NSLog(@"User: %@", [url user]);
//    NSLog(@"Password: %@", [url password]);
    
    playerModel.videoURL = url;
    playerModel.title = @"";
    playerModel.fatherView = positionView;
    
    [self.playerView playerControlView:controlView playerModel:playerModel];
    
    
    // 设置代理
    self.playerView.delegate = self;
    // 是否自动播放，默认不自动播放
    [self.playerView autoPlayTheVideo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

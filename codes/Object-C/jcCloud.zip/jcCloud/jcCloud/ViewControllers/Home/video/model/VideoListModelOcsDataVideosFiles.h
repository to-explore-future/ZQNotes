//
//VideoListModelOcsDataVideosFiles.h 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface VideoListModelOcsDataVideosFiles:NSObject
@property (nonatomic,assign) NSInteger parentId;
@property (nonatomic,copy) NSString *etag;
@property (nonatomic,assign) NSInteger id;
@property (nonatomic,assign) NSInteger mtime;
@property (nonatomic,assign) NSInteger upload_time;
@property (nonatomic,copy) NSString *mimetype;
@property (nonatomic,assign) NSInteger size;
@property (nonatomic,copy) NSString *path;
@property (nonatomic,assign) NSInteger permissions;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *type;
@property Boolean isSelected;//是否被选中

@end

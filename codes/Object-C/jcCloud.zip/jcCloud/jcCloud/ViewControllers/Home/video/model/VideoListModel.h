//
//VideoListModel.h 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "VideoListModelOcs.h"
#import "VideoListModelOcsDataVideosFiles.h"
#import "VideoListModelOcsDataVideos.h"
@interface VideoListModel:NSObject
@property (nonatomic,strong) VideoListModelOcs *ocs;

@end

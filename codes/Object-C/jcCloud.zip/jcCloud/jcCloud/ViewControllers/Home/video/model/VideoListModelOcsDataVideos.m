//
//VideoListModelOcsDataVideos.m 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "VideoListModelOcsDataVideos.h"
@implementation VideoListModelOcsDataVideos

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"files":@"VideoListModelOcsDataVideosFiles"
             };
}

@end

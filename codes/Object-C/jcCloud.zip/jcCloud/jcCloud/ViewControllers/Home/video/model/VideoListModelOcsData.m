//
//VideoListModelOcsData.m 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "VideoListModelOcsData.h"
@implementation VideoListModelOcsData

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"videos":@"VideoListModelOcsDataVideos"
             };
}

@end

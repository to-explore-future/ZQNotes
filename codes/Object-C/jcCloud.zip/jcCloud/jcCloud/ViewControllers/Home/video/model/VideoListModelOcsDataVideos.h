//
//VideoListModelOcsDataVideos.h 
//
//
//Create by sharingmobile on 18/4/8 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface VideoListModelOcsDataVideos:NSObject
@property (nonatomic,copy) NSString *title;
@property (nonatomic,strong) NSMutableArray *files;

@end

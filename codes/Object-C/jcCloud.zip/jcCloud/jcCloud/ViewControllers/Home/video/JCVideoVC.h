//
//  JCVideoVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/8.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCVideoVC : UIViewController

@property(nonatomic,strong) NSString  * currenPageDirPath;
@property(nonatomic,strong) NSString  * selectedStatus;
@property(nonatomic,strong) NSString  * isBasePath;
//View for Create Folder
@property(nonatomic, strong) UIAlertView *folderView;
//Alert to show any alert on Files view. Property to can cancel it on rotate
@property(nonatomic) UIAlertView *alert;

-(void)getPicsFromNetwork;  //获取视频列表

-(void)getPicFolder;        //获取与视频有关的文件夹,文件

@end

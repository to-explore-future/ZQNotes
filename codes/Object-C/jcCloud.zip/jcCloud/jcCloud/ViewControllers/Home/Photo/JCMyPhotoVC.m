//
//  JCMyPhotoVC.m
//  jcCloud
//
//  Created by mac on 2018/1/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCMyPhotoVC.h"
#import "JCPhotoModel.h"
#import "JCTimeSectionModel.h"
#import "JCTimePhotoView.h"
@interface JCMyPhotoVC ()
@property (nonatomic,strong)NSMutableArray *dataArr;
@property (weak, nonatomic) IBOutlet JCTimePhotoView *timeView;
@property (weak, nonatomic) IBOutlet JCTimePhotoView *monthView;
@property (weak, nonatomic) IBOutlet JCTimePhotoView *yearView;
@property (weak, nonatomic) IBOutlet JCTimePhotoView *classifyView;
@property (weak, nonatomic) IBOutlet JCTimePhotoView *nearView;
@property (weak, nonatomic) IBOutlet UIView *slideView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *slideLead;
@end

@implementation JCMyPhotoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArr=@[@[].mutableCopy,@[].mutableCopy,@[].mutableCopy,@[].mutableCopy,@[].mutableCopy].mutableCopy;

    [self getPhotoDataWithType:@1];
    // Do any additional setup after loading the view.
}
-(void)getPhotoDataWithType:(NSNumber *)type
{
    NSMutableDictionary *dic=[NSMutableDictionary dictionary];
    dic[@"sort"]=type;
    dic[@"page"]=@1;
    dic[@"direction"]=@1;
    [HTTPRequest postRequestWithUrl:API_photoList params:dic success:^(NSDictionary *responseDict) {
        NSDictionary *dic=responseDict[@"ocs"][@"data"][@"images"];
        NSMutableArray *arr=self.dataArr[type.integerValue-1];
        for (NSDictionary *fileDic in dic) {
            JCTimeSectionModel *m=[[JCTimeSectionModel alloc]initWithJSONDict:fileDic];
            [arr addObject:m];
        }
        self.timeView.dataArr=arr;
       
    } fail:^(NSString *errorMsg) {
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)backMain:(UIBarButtonItem *)sender {
    [self.tabBarController.navigationController popViewControllerAnimated:YES];
}
- (IBAction)uploadBtnTap:(UIBarButtonItem *)sender {
}
- (IBAction)chooseBtnTap:(UIBarButtonItem *)sender {
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

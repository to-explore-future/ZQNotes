//
//  JCPhotoTabVC.m
//  jcCloud
//
//  Created by mac on 2018/1/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCPhotoTabVC.h"
#import "JCPhotoTabBar.h"
#import "UIDefine.h"
@interface JCPhotoTabVC ()

@end

@implementation JCPhotoTabVC

- (void)viewDidLoad {
    [super viewDidLoad];
    JCPhotoTabBar *photoTab=[JCPhotoTabBar new];
    photoTab.delegateVC=self;
    photoTab.backgroundColor=UIColorFromRGB(0xf8f8f8);
    [self setValue:photoTab forKeyPath:@"tabBar"];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

//
//  JCMusicVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/12.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCMusicVC.h"
#import "JCMusicModel.h"
#import "JCMusicListCell.h"
#import "JCPlayMusicVC.h"
#import "LLAudioPlayer/LLAudioPlayerViewController.h"

@interface JCMusicVC ()<UITableViewDelegate,UITableViewDataSource>{
    NSInteger musicPage;
    NSMutableArray *_fileModels;
}

@property(nonatomic,strong)UITableView * tableview;
@property(nonatomic,strong)UIView * playerBar;
@property(nonatomic,strong)JCMusicModel * musicModel;

@end

@implementation JCMusicVC

-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController.navigationBar setHidden:NO];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的音乐";
    [self initData];
    [self initView];
    [self loadData];
}

-(void)initData{
    [self.tableview registerClass:[JCMusicListCell class] forCellReuseIdentifier:@"musicCell"];
    musicPage = 1;
}

- (BOOL)navigationShouldPopOnBackButton{
    
    for (UIViewController *controller in self.navigationController.viewControllers) {
        if ([controller isKindOfClass:[JCHomeVC class]]) {
            JCHomeVC *home =(JCHomeVC *)controller;
            [self.navigationController popToViewController:home animated:YES];
            break;
        }
    }
    return NO;
    
}

-(void)initView{
    
    [self.tabBarController.tabBar setHidden:YES];
    [self.view  setBackgroundColor:[UIColor whiteColor]];
    
//    [self.view addSubview:self.playerBar];
//    [self.playerBar mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.right.bottom.mas_equalTo(self.view);
//        make.height.mas_equalTo(60);
//    }];
    
    [self.view addSubview:self.tableview];
    [self.tableview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(self.view);
        make.bottom.mas_equalTo(self.view.mas_bottom);
    }];
    
}

-(void)loadData{
    NSString * aa = [NSString stringWithFormat:@"%@%@",serverIP,@"/ocs/v1.php/apps/jiacc_music/api/v1/list?format=json"];
    //    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_image/api/v1/list?format=json";
    NSString * page = [NSString stringWithFormat:@"%ld",musicPage];
    NSDictionary * param = @{
                             @"page":page,
                             @"pagecount":@"20"
                             };
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [Utils hideHUD];
        NSLog(@"jsonmusic = %@",[Utils id2Json:responseObject]);
        self.musicModel = [JCMusicModel mj_objectWithKeyValues:responseObject];
        
        [self.tableview reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}

#pragma mark - delegate UITableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.musicModel.ocs.data.musics.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    JCMusicListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"musicCell"];
    if (cell == nil) {
        cell = [[JCMusicListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"musicCell"];
    }
    //设置model
    JCMusicModelOcsDataMusics * musics = self.musicModel.ocs.data.musics[indexPath.row];
    [cell setMusic:musics];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //打开 音乐播放界面
    NSInteger count = self.musicModel.ocs.data.musics.count;
    _fileModels = [NSMutableArray arrayWithCapacity:count];
    for (NSInteger i = 0; i < count; i ++) {
        LLFileModel *fileModel = [LLFileModel new];
        //播放网络音频
        //有一部分文件较大的网络音频可能需要缓存一定时间之后才开始播放，如：<http://oopas6scq.bkt.clouddn.com/music/任月丽 - 风中奇缘.mp3>，请耐心等待
        JCMusicModelOcsDataMusics * music = self.musicModel.ocs.data.musics[i];
        NSString * basePath = @"http://test:test@192.168.133.42/remote.php/webdav/";
        NSString * path = [NSString stringWithFormat:@"%@%@",basePath,music.path];
        fileModel.filePath    = path;
        
        NSString * nameInfo = [music.name componentsSeparatedByString:@"."][0];
        fileModel.fileName    = [nameInfo componentsSeparatedByString:@" - "][1];
        fileModel.coverImage  = [UIImage imageNamed:@"我的音乐"];
        fileModel.artist      = [nameInfo componentsSeparatedByString:@" - "][0];
        fileModel.albumTitle  = @"";
        [_fileModels addObject:fileModel];
    }
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"initMusicPlayer" object:nil];
    
    LLAudioPlayerViewController * audioPlayVC = [[LLAudioPlayerViewController alloc] init];
    audioPlayVC.flieModels = [_fileModels copy];
    audioPlayVC.currentIndex = indexPath.row;
    [self.navigationController pushViewController:audioPlayVC animated:YES];
}

#pragma mark - lazyload

-(UITableView *)tableview{
    if (_tableview == nil) {
        _tableview = [[UITableView alloc] init];
        _tableview.delegate = self;
        _tableview.dataSource = self;
        _tableview.tableFooterView = [[UIView alloc] init];
    }
    return _tableview;
}

-(UIView *)playerBar{
    if (_playerBar == nil) {
        _playerBar = [[UIView alloc] init];
        [_playerBar setBackgroundColor:[Utils getColorWithOneValue:248]];
        [_playerBar.layer setShadowColor:[[UIColor grayColor] CGColor]];
        [_playerBar.layer setShadowOffset:CGSizeMake(0, 0)];
        [_playerBar.layer setShadowRadius:5];
        [_playerBar.layer setShadowOpacity:1];
    }
    return _playerBar;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

@end

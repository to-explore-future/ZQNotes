//
//  JCMusicListCell.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/13.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCMusicModelOcsDataMusics.h"


@interface JCMusicListCell : UITableViewCell

@property(nonatomic,strong)UIImageView * musicIcon;
@property(nonatomic,strong)UILabel * musicName;
@property(nonatomic,strong)UILabel * singer;
@property(nonatomic,strong)UIImageView * stateView;

-(void)setMusic:(JCMusicModelOcsDataMusics * )music;

@end

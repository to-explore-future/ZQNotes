//
//  JCMusicVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/12.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCMusicVC : UIViewController

-(void)loadData;    //获取音乐列表

@end

//
//  JCPlayMusicVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/16.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCPlayMusicVC : UIViewController

@end

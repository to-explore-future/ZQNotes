//
//  JCPlayMusicVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/16.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCPlayMusicVC.h"
#import "ZFPlayerView.h"
#import <AVFoundation/AVFoundation.h>

@interface JCPlayMusicVC ()<ZFPlayerDelegate>

//@property(nonatomic,strong)ZFPlayerView * playerView;
//@property(nonatomic,strong)UIView * aa;
@property(nonatomic,strong)AVPlayer * player;
@property(nonatomic,strong)NSString * playStatus;//播放状态


@end

@implementation JCPlayMusicVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.view setBackgroundColor:[Utils getColorWithRed:79 Green:83 Blue:94]];
//    self.aa = [[UIView alloc] init];
//    //    http://test:test@192.168.133.42/remote.php/webdav/我的音乐/薛之谦 - 丑八怪.mp3
//    self.playerView = [[ZFPlayerView alloc] init];
//
//    NSString * urls = @"http://test:test@192.168.133.42/remote.php/webdav/我的音乐/薛之谦 - 丑八怪.mp3";
//    urls = [urls stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSURL * url = [NSURL URLWithString:urls];
//
//    ZFPlayerModel * playerModel = [[ZFPlayerModel alloc] init];
//
//    playerModel.videoURL = url;
//    playerModel.title = @"";
//    playerModel.fatherView = self.aa;
//
//    [self.playerView playerControlView:[[UIView alloc] init] playerModel:playerModel];
//
//    // 设置代理
//    self.playerView.delegate = self;
//    // 是否自动播放，默认不自动播放
//    [self.playerView autoPlayTheVideo];
    
    NSString * urls = @"http://test:test@192.168.133.42/remote.php/webdav/我的音乐/薛之谦 - 丑八怪.mp3";
    urls = [urls stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL * url = [NSURL URLWithString:urls];
    
    // 移除监听
//    [self p_currentItemRemoveObserver];
    AVPlayerItem * playerItem = [[AVPlayerItem alloc] initWithURL:url];
//    [self.player initWithPlayerItem:playerItem];
    self.player = [[AVPlayer alloc] initWithPlayerItem:playerItem];
    
    // 添加观察者
    [self p_currentItemAddObserver];
    
}

- (void)p_currentItemRemoveObserver {
    [self.player.currentItem removeObserver:self  forKeyPath:@"status"];
    [self.player.currentItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
//    [self.player removeTimeObserver:self.timeObserver];
}

- (void)p_currentItemAddObserver {
    
    //监控状态属性，注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态
    [self.player.currentItem addObserver:self forKeyPath:@"status" options:(NSKeyValueObservingOptionOld|NSKeyValueObservingOptionNew) context:nil];
    
    //监控缓冲加载情况属性
    [self.player.currentItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionOld|NSKeyValueObservingOptionNew context:nil];
    
    //监控播放完成通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackFinished:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
    
    //监控时间进度
    __weak __typeof(self) weakSelf = self;
//    @weakify(self);
//    self.timeObserver = [weakSelf.player addPeriodicTimeObserverForInterval:CMTimeMake(1, 1) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
//        @strongify(self);
        __strong __typeof(self) strongSelf = weakSelf;
//         在这里将监听到的播放进度代理出去，对进度条进行设置
//        if (strongSelf.delegate && [strongSelf.delegate respondsToSelector:@selector(updateProgressWithPlayer:)]) {
//            [strongSelf.delegate updateProgressWithPlayer:self.player];
//        }
//    }];
}

#pragma mark - KVO

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    AVPlayerItem *playerItem = object;
    if ([keyPath isEqualToString:@"status"]) {
        AVPlayerItemStatus status = [change[@"new"] integerValue];
        switch (status) {
            case AVPlayerItemStatusReadyToPlay:  // 开始播放
            {
                
                // 代理回调，开始初始化状态
//                if (self.delegate && [self.delegate respondsToSelector:@selector(startPlayWithplayer:)]) {
//                    [self.delegate startPlayWithplayer:self.player];
//                }
            }
                break;
            case AVPlayerItemStatusFailed:      //加载失败
            {
                NSLog(@"加载失败");
//                TOAST_MSG(@"播放错误");
            }
                break;
            case AVPlayerItemStatusUnknown:     //未知资源
            {
                NSLog(@"未知资源");
//                TOAST_MSG(@"播放错误");
            }
                break;
                
            default:
                break;
        }
    } else if([keyPath isEqualToString:@"loadedTimeRanges"]){
        NSArray *array=playerItem.loadedTimeRanges;
        //本次缓冲时间范围
        CMTimeRange timeRange = [array.firstObject CMTimeRangeValue];
        float startSeconds = CMTimeGetSeconds(timeRange.start);
        float durationSeconds = CMTimeGetSeconds(timeRange.duration);
        //缓冲总长度
        NSTimeInterval totalBuffer = startSeconds + durationSeconds;
        NSLog(@"共缓冲：%.2f",totalBuffer);
        if (totalBuffer > 0.1) {
            if ([self.playStatus isEqualToString:@"isPlaying"]) {
                
            }else{
                [self.player play];
                self.playStatus = @"isPlaying";
            }
            
        }
//        if (self.delegate && [self.delegate respondsToSelector:@selector(updateBufferProgress:)]) {
//            [self.delegate updateBufferProgress:totalBuffer];
//        }
        
    } else if ([keyPath isEqualToString:@"rate"]) {
        // rate=1:播放，rate!=1:非播放
        float rate = self.player.rate;
//        if (self.delegate && [self.delegate respondsToSelector:@selector(player:changeRate:)]) {
//            [self.delegate player:self.player changeRate:rate];
//        }
    } else if ([keyPath isEqualToString:@"currentItem"]) {
        NSLog(@"新的currentItem");
//        if (self.delegate && [self.delegate respondsToSelector:@selector(changeNewPlayItem:)]) {
//            [self.delegate changeNewPlayItem:self.player];
//        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

//- (AVPlayer *)player {
//    if (_player == nil) {
//        _player = [[AVPlayer alloc] init];
//        _player.volume = 1.0; // 默认最大音量
//    }
//    return _player;
//}


@end

//
//  JCMusicPlayer.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/17.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCMusicPlayer.h"



@implementation JCMusicPlayer


-(instancetype)init{
    self = [super init];
    self.player = [[AVPlayer alloc] init];
    //初始化监听
    [self initNotification];
    return self;
}

- (void)initNotification{
//    //监听音频播放结束
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlayDidEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
//    //监听程序退到后台
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:)name:UIApplicationWillResignActiveNotification object:nil];
//    //监听音频播放中断
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieInterruption:) name:AVAudioSessionInterruptionNotification object:nil];
//    //设置并激活后台播放
//    AVAudioSession *session=[AVAudioSession sharedInstance];
//    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
//    [session setActive:YES error:nil];
//    //允许应用程序接收远程控制
//    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
}



@end

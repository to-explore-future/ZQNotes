//
//JCMusicModelOcsDataMusics.h 
//
//
//Create by sharingmobile on 18/4/13 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface JCMusicModelOcsDataMusics:NSObject
@property (nonatomic,assign) NSInteger id;
@property (nonatomic,assign) NSInteger upload_time;
@property (nonatomic,copy) NSString *album;
@property (nonatomic,copy) NSString *artist;
@property (nonatomic,assign) NSInteger permissions;
@property (nonatomic,copy) NSString *path;
@property (nonatomic,copy) NSString *mimetype;
@property (nonatomic,assign) NSInteger size;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,assign) NSInteger mtime;
@property (nonatomic,copy) NSString *etag;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,assign) NSInteger parentId;

@end
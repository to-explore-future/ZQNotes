//
//JCMusicModelOcsData.h 
//
//
//Create by sharingmobile on 18/4/13 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JCMusicModelOcsData:NSObject

@property (nonatomic,assign) NSInteger total_count;
@property (nonatomic,strong) NSArray *musics;

@end

//
//JCMusicModel.h 
//
//
//Create by sharingmobile on 18/4/13 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JCMusicModelOcs.h"
#import "JCMusicModelOcsData.h"
#import "JCMusicModelOcsDataMusics.h"
#import "JCMusicModelOcsMeta.h"

@interface JCMusicModel:NSObject
@property (nonatomic,strong) JCMusicModelOcs *ocs;

@end

//
//JCMusicModelOcsData.m 
//
//
//Create by sharingmobile on 18/4/13 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "JCMusicModelOcsData.h"
@implementation JCMusicModelOcsData

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"musics":@"JCMusicModelOcsDataMusics"
             };
}

@end

//
//  JCMusicListCell.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/13.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCMusicListCell.h"

@implementation JCMusicListCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initFrame];
    }
    return self;
}

-(void)setMusic:(JCMusicModelOcsDataMusics * )music{
    NSArray * aa = [music.name componentsSeparatedByString:@" - "];
    NSString * name = [aa[1] componentsSeparatedByString:@"."][0];
    [self.musicName setText: name];
    [self.singer setText:aa[0]];
}

-(void)initFrame{
    [self.contentView addSubview:self.musicIcon];
    [self.musicIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView).offset(25);
        make.centerY.mas_equalTo(self.contentView.mas_centerY);
        make.width.height.mas_equalTo(30);
    }];
    
    [self.contentView addSubview:self.musicName];
    [self.musicName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.musicIcon.mas_right).offset(23);
        make.top.mas_equalTo(self.contentView.mas_top).offset(15);
    }];
    
    [self.contentView addSubview:self.singer];
    [self.singer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.musicIcon.mas_right).offset(25);
        make.top.mas_equalTo(self.musicName.mas_bottom).offset(1);
    }];
}

-(UIImageView *)musicIcon{
    if (_musicIcon == nil) {
        _musicIcon = [[UIImageView alloc] init];
        [_musicIcon setImage:[UIImage imageNamed:@"musicIcon"]];
    }
    return _musicIcon;
}

-(UIImageView *)stateView{
    if (_stateView == nil) {
        _stateView = [[UIImageView alloc] init];
        [_stateView setImage:[UIImage imageNamed:@"selected"]];
    }
    return _stateView;
}

-(UILabel *)musicName{
    if (_musicName == nil) {
        _musicName = [[UILabel alloc] init];
        [_musicName setText:@"那一年"];
        [_musicName setFont:[UIFont systemFontOfSize:16]];
        [_musicName setTextColor:[UIColor blackColor]];
        [_musicName sizeToFit];
    }
    return _musicName;
}

-(UILabel *)singer{
    if (_singer == nil) {
        _singer = [[UILabel alloc] init];
        [_singer setText:@"王大"];
        [_singer setFont:[UIFont systemFontOfSize:12]];
        [_singer setTextColor:[UIColor lightGrayColor]];
        [_singer sizeToFit];
    }
    return _singer;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

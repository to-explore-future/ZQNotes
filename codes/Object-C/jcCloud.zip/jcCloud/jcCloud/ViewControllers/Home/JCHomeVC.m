//
//  JCHomeVC.m
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCHomeVC.h"
#import "JCPictureVCViewController.h"
#import "JCVideoVC.h"
#import "JCMusicVC.h"
#import "JCAllFilesVC.h"
#import "JCSearchVC.h"
#import "JCHiddenFilesVC.h"
#import "HiddenFileStatus.h"
#import "JCInputPasswordVC.h"
#import "JCOpenHiddenFiles.h"
#import "JCScreenPassword.h"
#import "AppDelegate.h"



@interface JCHomeVC (){
    NSString * hide_status;//开启状态(1 开启 / 0 未开启)
    NSInteger is_one;//是否为首次开启(1是/0否)
    NSString * is_bind_phone;//是否绑定手机号 (手机号码/false)
//    False:未绑定
//    手机号码:绑定了

}
@property (weak, nonatomic) IBOutlet UILabel *photoCntLabel;
@property (weak, nonatomic) IBOutlet UILabel *videoCntLabel;
@property (weak, nonatomic) IBOutlet UILabel *musicCntLabel;
@property (weak, nonatomic) IBOutlet UILabel *allCntLabel;

@property(nonatomic,strong)AppDelegate * appDelegate;
@property(nonatomic,assign)BOOL isWiFi;
@property(nonatomic,assign)BOOL isOpenJustWiFiNetWorking;
//AppDelegate * appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;

@end

@implementation JCHomeVC


- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    self.appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    _isWiFi = self.appDelegate.isWiFi;
    
    [self getAllFileCountData];
    [self loadData];
}

-(void)initData{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WiFiStatusChanges:) name:@"WiFiStatusChanges" object:nil];
}

-(void)loadData{
//    [Utils showHUD:self.navigationController.view];
//    http://192.168.133.42/ocs/v1.php/apps/jiacc_hide/api/v1/status
//    NSString * aa = @"http://192.168.53.90:7909/ocs/v1.php/apps/jiacc_hide/api/v1/status?format=json"; //邱
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_hide/api/v1/status?format=json"; //郭
    
    NSDictionary * param = @{

                             };
    
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        [Utils hideHUD];
        
        NSLog(@"json-->status = %@",[Utils id2Json:responseObject]);
        HiddenFileStatus * status = [HiddenFileStatus mj_objectWithKeyValues:responseObject];
        hide_status = status.ocs.data.hide_status;
        is_one = status.ocs.data.is_one;
        is_bind_phone = status.ocs.data.is_bind_phone;
    
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden=NO;
    self.tabBarController.tabBar.hidden=NO;
    self.navigationController.navigationBar.topItem.title = @"家丞存储";
//    _isWiFi = self.appDelegate.isWiFi;
    NSUserDefaults * user = [NSUserDefaults standardUserDefaults];
    _isOpenJustWiFiNetWorking = [user boolForKey:@"WIFI_STATUES"];
}

-(void)WiFiStatusChanges:(NSNotification *) notification{
    NSString * status =(NSString *)notification.object;
    if ([status isEqualToString:@"YES"]) {
        _isWiFi = YES;
    }else{
        _isWiFi = NO;
    }
   
}

- (IBAction)searchAction:(UIButton *)sender {
    JCSearchVC * search = [[JCSearchVC alloc] init];
    [self.navigationController pushViewController:search animated:YES];
}

-(void)getAllFileCountData
{
//    [self showLoadingHUD];
//    [HTTPRequest postRequestWithUrl:API_fileIndex params:nil success:^(NSDictionary *responseDict) {
//        NSDictionary *dataDic=responseDict[@"ocs"][@"data"];
//        self.photoCntLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"image_count"]];
//        self.videoCntLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"video_count"]];
//        self.musicCntLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"music_count"]];
//        self.allCntLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"file_count"]];
//    } fail:^(NSString *errorMsg) {
//
//    }];
}
- (void)openPic {
    if ([Utils isSettingScreenPassword]) {
        //打开密码验证页面
        JCScreenPassword * screenPassword = [[JCScreenPassword alloc] init];
        screenPassword.status = @"verify";
        screenPassword.whereWant2Go = @"JCPictureVCViewController";
        [self.navigationController pushViewController:screenPassword animated:YES];
    }else{
        JCPictureVCViewController * picture = [[JCPictureVCViewController alloc] init];
        picture.currenPageDirPath = @"/";
        picture.selectedStatus = @"pic";
        picture.isBasePath = @"isBase";
        [self.navigationController pushViewController:picture animated:YES];
    }
}

- (void)openVideo {
    if ([Utils isSettingScreenPassword]) {
        //打开密码验证页面
        JCScreenPassword * screenPassword = [[JCScreenPassword alloc] init];
        screenPassword.status = @"verify";
        screenPassword.whereWant2Go = @"JCVideoVC";
        [self.navigationController pushViewController:screenPassword animated:YES];
    }else{
        //我的视频
        JCVideoVC * video = [[JCVideoVC alloc] init];
        video.currenPageDirPath = @"/";
        video.selectedStatus = @"pic";
        video.isBasePath = @"isBase";
        [self.navigationController pushViewController:video animated:YES];
    }
}

- (void)openMusic {
    if ([Utils isSettingScreenPassword]) {
        //打开密码验证页面
        JCScreenPassword * screenPassword = [[JCScreenPassword alloc] init];
        screenPassword.status = @"verify";
        screenPassword.whereWant2Go = @"JCMusicVC";
        [self.navigationController pushViewController:screenPassword animated:YES];
    }else{
        JCMusicVC * music = [[JCMusicVC alloc] init];
        [self.navigationController pushViewController:music animated:YES];
    }
}

- (void)openAllFiles {
    if ([Utils isSettingScreenPassword]) {
        //打开密码验证页面
        JCScreenPassword * screenPassword = [[JCScreenPassword alloc] init];
        screenPassword.status = @"verify";
        screenPassword.whereWant2Go = @"JCAllFilesVC";
        [self.navigationController pushViewController:screenPassword animated:YES];
    }else{
        JCAllFilesVC * allFiles = [[JCAllFilesVC alloc] init];
        allFiles.currenPageDirPath = @"/";
        allFiles.selectedStatus = @"pic";
        allFiles.isBasePath = @"isBase";
        [self.navigationController pushViewController:allFiles animated:YES];
    }
}

- (void)openHiddenFile {
    if (is_one == 0) {
        if ([hide_status isEqualToString:@"0"]) {
        }else{
            JCInputPasswordVC * pass = [[JCInputPasswordVC alloc] init];
            [pass.phone setText:is_bind_phone];
            [self.navigationController pushViewController:pass animated:YES];
        }
    }else{
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"提示"
                                                                       message:@"您还没有开启隐藏文件,是否立即开启?"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {
                                                                  JCOpenHiddenFiles * open = [[JCOpenHiddenFiles alloc] init];//打开注册页面
                                                                  [self.navigationController pushViewController:open animated:YES];
                                                              }];
        UIAlertAction* cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction * action) {
                                                             }];
        [alert addAction:cancleAction];
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)wifiAlert {
    [Utils showAlertWithMessage:@"您已开启节省流量模式，仅在WIFI下可访问数据，如需关闭该模式，请在我的设置下关闭该选项既可" withVC:self];
}

- (IBAction)btnTap:(UIButton *)sender {
    switch (sender.tag) {
        case 0:
        {
//            UIViewController *photoTab = [self.class initialViewControllerForStoryBoardName:@"Photo"];
//            self.navigationController.navigationBar.hidden=YES;
//            self.tabBarController.tabBar.hidden=YES;
//            [self.navigationController pushViewController:photoTab animated:YES];
            
            if (_isWiFi ) {
                [self openPic];
            }else{
                if (_isOpenJustWiFiNetWorking ) {
                    [self wifiAlert];
                    break;
                }else{
                    [self openPic];
                }
            }
        }
            break;
            
        case 1:
        {
            if (_isWiFi) {
                [self openVideo];
            }else{
                if (_isOpenJustWiFiNetWorking ) {
                    [self wifiAlert];
                    break;
                }else{
                    [self openVideo];
                }
            }
        }
            break;
            
        case 2:
        {
            if (_isWiFi) {
                [self openMusic];
            }else{
                if (_isOpenJustWiFiNetWorking ) {
                    [self wifiAlert];
                    break;
                }else{
                    [self openMusic];
                }
            }
        }
            break;
            
        case 3:
        {
            if (_isWiFi) {
                [self openAllFiles];
            }else{
                if (_isOpenJustWiFiNetWorking ) {
                    [self wifiAlert];
                    break;
                }else{
                    [self openAllFiles];
                }
            }
        }
            break;
           
        case 6:
        {
            if (_isWiFi) {
                [self openHiddenFile];
            }else{
                if (_isOpenJustWiFiNetWorking ) {
                    [self wifiAlert];
                    break;
                }else{
                    [self openAllFiles];
                }
            }
        }
            break;
            
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

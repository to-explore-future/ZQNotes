//
//  XXShop.m
//  WaterFallLayout
//
//  Created by sky on 16/6/6.
//  Copyright © 2016年 sky. All rights reserved.
//

#import "JRShop.h"

@implementation JRShop

@end

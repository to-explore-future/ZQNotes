//
//PicListOcs.h 
//
//
//Create by sharingmobile on 18/3/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PicListOcsMeta.h"
#import "PicListOcsData.h"
@interface PicListOcs:NSObject
@property (nonatomic,strong) PicListOcsMeta *meta;
@property (nonatomic,strong) PicListOcsData *data;

@end
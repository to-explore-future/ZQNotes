//
//PicForderOcsMeta.m 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "PicForderOcsMeta.h"
@implementation PicForderOcsMeta

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

@end
//
//  JCPictureVCViewController.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/15.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCPictureVCViewController : UIViewController

@property(nonatomic,strong) NSString  * currenPageDirPath;      //当前目录的远程路径
@property(nonatomic,strong) NSString  * selectedStatus;
@property(nonatomic,strong) NSString  * isBasePath;
//View for Create Folder
@property(nonatomic, strong) UIAlertView *folderView;
//Alert to show any alert on Files view. Property to can cancel it on rotate
@property(nonatomic) UIAlertView *alert;

-(void)getPicsFromNetwork;  //获取图片列表

-(void)getPicFolder;        //获取与图片有关的文件夹

@end

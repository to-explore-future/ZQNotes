//
//  JCDayPicVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/15.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCBaseViewController.h"

@interface JCDayPicVC : JCBaseViewController

-(void)setPics:(NSMutableArray *)pics;

-(void)setPicUrls:(NSArray *)picUrls;

@end

//
//  JCPicListHeaderCell.m
//  jcCloud
//
//  Created by sharingmobile on 2018/3/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCPicListHeaderCell.h"

@interface JCPicListHeaderCell()

@end

@implementation JCPicListHeaderCell

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initFrame];
    }
    return self;
}

-(void)initFrame{
    [self addSubview:self.time];
    [self.time mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(self.mas_width);
        make.left.mas_equalTo(self.mas_left).offset(10);
    }];
    
    [self addSubview:self.rightArrow];
    [self.rightArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(50);
    }];
    [self addSubview:self.selectAllPic];
    [self.selectAllPic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(50);
    }];
}

#pragma mark - action

-(void)rightArrowAction:(UIButton *)btn{
    if ([self.categoryState isEqualToString:@"pic"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"picListRightArrowAction" object:btn];
    }else if([self.categoryState isEqualToString:@"video"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"videoListRightArrowAction" object:btn];
    }
    
}

-(void)setState:(NSString *)categoryState{
    self.categoryState = categoryState;
}

#pragma mark - lazyload

-(UILabel *)time{
    if (_time == nil) {
        _time = [[UILabel alloc] init];
//        [_time setBackgroundColor:[UIColor greenColor]];
//        [_time setText:@"我再试试"];
        [_time setTextColor:[UIColor blackColor]];
        [_time setFont:[UIFont systemFontOfSize:21]];
    }
    return _time;
}

-(UIButton *)rightArrow{
    if (_rightArrow == nil) {
        _rightArrow = [[UIButton alloc] init];
        [_rightArrow setImage:[UIImage imageNamed:@"picture_right_arrow"]forState:UIControlStateNormal];
//        [_rightArrow setBackgroundColor:[UIColor greenColor]];
        [_rightArrow addTarget:self action:@selector(rightArrowAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightArrow;
}

-(UIButton *)selectAllPic{
    if (_selectAllPic == nil) {
        _selectAllPic = [[UIButton alloc]init];
        [_selectAllPic setTitle:@"选择" forState:UIControlStateNormal];
        [_selectAllPic setTitleColor:[Utils getColorWithRed:0 Green:110 Blue:190] forState:UIControlStateNormal];
        [_selectAllPic setHidden:YES];
    }
    return _selectAllPic;
}



@end

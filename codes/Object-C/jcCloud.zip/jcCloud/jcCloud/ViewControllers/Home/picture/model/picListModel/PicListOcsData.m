//
//PicListOcsData.m 
//
//
//Create by sharingmobile on 18/3/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "PicListOcsData.h"
@implementation PicListOcsData

//-(instancetype)init{
//    self = [super init];
//    if(self){
//
//    }
//    return self;
//}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"images":@"PicListOcsDataImages"
             };
}

@end

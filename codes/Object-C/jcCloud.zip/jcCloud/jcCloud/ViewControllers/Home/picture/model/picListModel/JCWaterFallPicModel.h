//
//  JCWaterFallPicModel.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/28.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCWaterFallPicModel : NSObject

@property(nonatomic,assign)CGFloat width;
@property(nonatomic,assign)CGFloat height;
@property(nonatomic,strong)NSString * path;
@property(nonatomic,assign)Boolean isSelected;

@end

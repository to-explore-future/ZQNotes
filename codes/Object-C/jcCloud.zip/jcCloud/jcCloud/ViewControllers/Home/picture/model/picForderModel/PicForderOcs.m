//
//PicForderOcs.m 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "PicForderOcs.h"
@implementation PicForderOcs

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

@end
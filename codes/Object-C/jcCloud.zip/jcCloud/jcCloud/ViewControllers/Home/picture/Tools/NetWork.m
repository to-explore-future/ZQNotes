//
//  NetWork.m
//  IMTranslate
//
//  Created by sharingmobile on 2018/3/1.
//  Copyright © 2018年 分享通讯-随译行. All rights reserved.
//

#import "NetWork.h"



@implementation NetWork

+(AFHTTPSessionManager *)getInstance{
    if (manager == nil) {
        manager = [AFHTTPSessionManager manager];
//        [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];                 //邱
        [manager.requestSerializer setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];//郭
        [manager.requestSerializer setValue:@"true" forHTTPHeaderField:@"OCS-APIREQUEST"];//郭
//        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"authorization"];
        
//        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json",@"text/javascript",@"text/html",@"text/plain",nil];
        [manager.requestSerializer setAuthorizationHeaderFieldWithUsername:@"test" password:@"test"];

        manager.responseSerializer = [AFHTTPResponseSerializer serializer];     //http请求
        manager.requestSerializer.timeoutInterval = 60;                         //设置超时时间
        [manager.requestSerializer setStringEncoding:NSUTF8StringEncoding];     //设置编码格式
//        manager.requestSerializer = [AFJSONRequestSerializer serializer];       //发送json数据进行请求
//        [manager.securityPolicy setAllowInvalidCertificates:YES];
    }
    return manager;
}

@end

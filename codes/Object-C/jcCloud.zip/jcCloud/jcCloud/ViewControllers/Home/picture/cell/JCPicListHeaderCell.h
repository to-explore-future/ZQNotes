//
//  JCPicListHeaderCell.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCPicListHeaderCell : UICollectionReusableView

@property(nonatomic,strong)UILabel * time;
@property(nonatomic,strong)UIButton * rightArrow;
@property(nonatomic,strong)UIButton * selectAllPic;
@property(nonatomic,strong)NSString * categoryState;

-(void)setState:(NSString*)categoryState;

@end

//
//  JCDayPicVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/3/15.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCDayPicVC.h"
#import "JRWaterFallLayout.h"
#import "JRShopCell.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "JRShop.h"
#import "DKNetworking.h"
#import "DKNetworkCache.h"
#import "JCWaterFallPicModel.h"
#import "JCSliderShowVC.h"
#import "JCCommenToolView.h"



// collectionViewCell的重用标识符
static NSString * const shopCellReuseID = @"shop";

@interface JCDayPicVC ()<JRWaterFallLayoutDelegate,UICollectionViewDataSource,JRShopCellDelegate>{
    JCCommenToolView *bottomToolView;
    Boolean isSelectStatus;
}
@property(nonatomic,strong)UICollectionView * collectionView;//瀑布流
@property(nonatomic,strong)NSMutableArray * shops;
/** 当前页码 */
@property (nonatomic, assign) NSUInteger currentPage;

@property(nonatomic,strong)NSMutableArray * pics;
@property CGFloat   lineSpace;
@property CGFloat   rowSpace;
@property NSInteger lineNum;
@property CGFloat   edgesTop;
@property CGFloat   edgesLeft;
@property CGFloat   edgesBottom;
@property CGFloat   edgesRight;
@property(nonatomic,strong)NSArray * urls;

@end


@implementation JCDayPicVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    
    //标题右侧的连个button
    UIBarButtonItem * right1 = [[UIBarButtonItem alloc] initWithTitle:@"选择" style:UIBarButtonItemStyleDone target:self action:@selector(selectBtnAction)];
    
    self.navigationItem.rightBarButtonItem = right1;
    
    UIBarButtonItem * right2 = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStyleDone target:self action:@selector(right2Action)];
    NSArray * rightBtns = [NSArray arrayWithObjects:right1,right2, nil];
    self.navigationItem.rightBarButtonItems = rightBtns;
    
    
    
    //当前页码为0
    self.currentPage = 0;
    //初始化瀑布流
    JRWaterFallLayout * layout = [[JRWaterFallLayout alloc] init];
    //设置代理
    layout.delegate = self;
    //创建瀑布流
    UICollectionView * collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    //设置数据源
    collectionView.dataSource = self;
    [collectionView setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:collectionView];
    self.collectionView = collectionView;
    
    //可以在这里注册cell
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([JRShopCell class]) bundle:nil] forCellWithReuseIdentifier:shopCellReuseID];
    
    //为瀑布流控件添加上拉加载 和 下拉刷新
//    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
////            [self.shops removeAllObjects];
////            [self.shops addObjectsFromArray:[self newShops]];
//            [self.collectionView reloadData];
//            [self.collectionView.mj_header endRefreshing];
//        });
//    }];
//
//    //第一进入的时候 首先刷新
//    //等网络数据回来了 再刷新
//
//    [self.collectionView.mj_header beginRefreshing];
    
    //添加上拉加载
    self.collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        //下面的注释 只是用来 过一段时间 做什么事情 
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//
//        });
        //上拉加载更多的代码
        [self.collectionView reloadData];
        self.collectionView.mj_footer.state = MJRefreshStateNoMoreData;
    }];
    
    [self.collectionView.mj_footer beginRefreshing];
    
    
    //底部的工具条
    CGRect boxFrame=CGRectMake(0,kScreen_height, kScreen_width, 50);
    bottomToolView=[[JCCommenToolView alloc] initWithFrame:boxFrame isHidden:NO];
    [self.view addSubview:bottomToolView];
    [bottomToolView setHidden:YES];
}

-(void)initData{
    self.lineNum        = 3;
    self.lineSpace      = 3;
    self.rowSpace       = 3;
    self.edgesTop       = 0;
    self.edgesLeft      = 2;
    self.edgesBottom    = 0;
    self.edgesRight     = 2;
}

-(void)loadData{

}

- (NSArray *)moreShopsWithCurrentPage:(NSUInteger)currentPage{
    // 页码的判断 ,因为plist 中数据有限
    if (currentPage == 3) {
        self.currentPage = 0;
    } else {
        self.currentPage++;
    }
    NSString *nextPage = [NSString stringWithFormat:@"%lu.plist", self.currentPage];
    NSLog(@"nextPage = %@",nextPage);
    return [JRShop mj_objectArrayWithFilename:nextPage];
}

#pragma mark - 内部方法
- (NSArray *)newShops{
    return [JRShop mj_objectArrayWithFilename:@"0.plist"];//打plist 转变成 数组
}

-(void)setPics:(NSMutableArray *)pics{
    if (_pics == nil) {
        _pics = [NSMutableArray arrayWithArray:pics];
    }
}

-(void)selectBtnAction{
    UIBarButtonItem * right1 = self.navigationItem.rightBarButtonItems[0];
    
    if ([right1.title isEqualToString:@"选择"]) {
        //目前是选择状态
        isSelectStatus = YES;
        right1.title = @"取消";
        [bottomToolView setHidden:NO];
        
        
    }else if([right1.title isEqualToString:@"取消"]){
        right1.title = @"选择";
        isSelectStatus = NO;
        [bottomToolView setHidden:YES];
        //所有的model 取消 状态
        NSInteger count = self.pics.count;
        for (NSInteger i = 0; i < count; i ++) {
            JCWaterFallPicModel * model = self.pics[i];
            model.isSelected = false;
        }
        [self.collectionView reloadData];
        [bottomToolView setHidden:YES];
    }
    [self.collectionView reloadData];
}

-(void)right2Action{
    
}

#pragma mark - delegate

#pragma mark - delegate JRWaterFallLayoutDelegate

//返回控件的高度
- (CGFloat)waterFallLayout:(JRWaterFallLayout *)waterFallLayout heightForItemAtIndex:(NSUInteger)index width:(CGFloat)width{
    JCWaterFallPicModel * model = self.pics[index];
    CGFloat pWidth = model.width;
    CGFloat pHeight = model.height;
    return pHeight * width / pWidth;
}

// 返回瀑布流显示的列数
- (NSUInteger)columnCountOfWaterFallLayout:(JRWaterFallLayout *)waterFallLayout{
    return self.lineNum;
}
// 返回行间距
- (CGFloat)rowMarginOfWaterFallLayout:(JRWaterFallLayout *)waterFallLayout{
    return self.rowSpace;
}
// 返回列间距
- (CGFloat)columnMarginOfWaterFallLayout:(JRWaterFallLayout *)waterFallLayout{
    return self.lineSpace;
}
// 返回边缘间距
- (UIEdgeInsets)edgeInsetsOfWaterFallLayout:(JRWaterFallLayout *)waterFallLayout{
    return UIEdgeInsetsMake(self.edgesTop, self.edgesLeft, self.edgesBottom, self.edgesRight);
}

#pragma mark - delegate UICollectionViewDateSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.pics.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    JRShopCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:shopCellReuseID forIndexPath:indexPath] ;
    //计算瀑布流的宽度
    CGFloat width = ( kScreen_width - self.edgesLeft - self.edgesRight - self.lineSpace * (self.lineNum - 1) ) / self.lineNum;
    [cell setCellWidth:width];
    cell.model = self.pics[indexPath.row];
    [cell setTag:indexPath.row];
    cell.delegate = self;
    return cell;
}

#pragma mark - delegate JRShopCellDelegate

-(void)cellClickedPositio:(NSInteger)position{
    if (isSelectStatus) {
        //改变数据模型 从新刷新
        JCWaterFallPicModel * model = self.pics[position];
        model.isSelected = !model.isSelected;
        [self.collectionView reloadData];
    }else{
        JCSliderShowVC * slider = [[JCSliderShowVC alloc] init];
        [slider setUrls:self.urls];
        [slider setSelectedIndex:position];
        [self.navigationController pushViewController:slider animated:YES];
    }
    
}

#pragma mark - action

/**
 *  sliderView 需要特殊的数据类型 由于没有太多的时间 再次重新优化,直接要什么给什么 先这样 下一版本 优化
 */
-(void)setPicUrls:(NSArray *)picUrls{
    self.urls = picUrls;
}

#pragma mark - other

-(NSMutableArray *)shops{
    if (_shops == nil) {
        _shops = [NSMutableArray array];
    }
    return _shops;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

@end

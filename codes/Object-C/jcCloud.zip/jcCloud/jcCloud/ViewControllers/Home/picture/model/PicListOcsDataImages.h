//
//PicListOcsDataImages.h 
//
//
//Create by sharingmobile on 18/3/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface PicListOcsDataImages:NSObject
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSArray *files;

@end
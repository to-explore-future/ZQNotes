//
//PicListOcsDataImagesFiles.h 
//
//
//Create by sharingmobile on 18/3/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface PicListOcsDataImagesFiles:NSObject
@property (nonatomic,assign) NSInteger id;
@property (nonatomic,assign) NSInteger upload_time;
@property (nonatomic,copy) NSString *country;
@property (nonatomic,assign) NSInteger permissions;
@property (nonatomic,copy) NSString *province;
@property (nonatomic,copy) NSString *street;
@property (nonatomic,copy) NSString *path;
@property (nonatomic,copy) NSString *mimetype;
@property (nonatomic,assign) NSInteger size;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,assign) NSInteger mtime;
@property (nonatomic,copy) NSString *city;
@property (nonatomic,copy) NSString *district;
@property (nonatomic,copy) NSString *etag;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,assign) NSInteger parentId;
@property (nonatomic,assign) NSNumber * width;
@property (nonatomic,assign) NSNumber * height;
@property Boolean isSelected;//是否被选中

@end

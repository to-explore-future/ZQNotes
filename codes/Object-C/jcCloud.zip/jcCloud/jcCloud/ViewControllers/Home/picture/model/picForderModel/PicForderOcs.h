//
//PicForderOcs.h 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PicForderOcsMeta.h"
#import "PicForderOcsData.h"
@interface PicForderOcs:NSObject
@property (nonatomic,strong) PicForderOcsMeta *meta;
@property (nonatomic,strong) PicForderOcsData *data;

@end
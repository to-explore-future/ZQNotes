//
//  NetWork.h
//  IMTranslate
//
//  Created by sharingmobile on 2018/3/1.
//  Copyright © 2018年 分享通讯-随译行. All rights reserved.
//

#import <Foundation/Foundation.h>


static AFHTTPSessionManager * manager;

@interface NetWork : NSObject

+(AFHTTPSessionManager *)getInstance;

@end

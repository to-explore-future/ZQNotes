//
//PicForderOcsDataFiles.m 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "PicForderOcsDataFiles.h"
@implementation PicForderOcsDataFiles

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

@end
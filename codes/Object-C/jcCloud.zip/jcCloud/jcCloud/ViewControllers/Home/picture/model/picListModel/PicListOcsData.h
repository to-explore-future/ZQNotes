//
//PicListOcsData.h 
//
//
//Create by sharingmobile on 18/3/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PicListOcsDataImages.h"
@interface PicListOcsData:NSObject
@property (nonatomic,strong) NSMutableArray * images;
@property (nonatomic,assign) NSInteger total_count;

@end

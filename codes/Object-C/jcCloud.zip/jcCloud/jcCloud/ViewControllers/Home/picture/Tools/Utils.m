//
//  Utils.m
//  baidufanyiTest
//
//  Created by sharingmobile on 2018/2/23.
//  Copyright © 2018年 sharingmobile. All rights reserved.
//

#import "Utils.h"
#import<CommonCrypto/CommonDigest.h>

static MBProgressHUD * hud;

@implementation Utils

/**
 *  对 uiColor 的封装
 */
+(UIColor*)getColorWithRed:(int)red Green:(int)green Blue:(int)blue Alpha:(float)alpha{
    return [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha/1.0];
}


/**
 *  对 uiColor 的封装 alpha 默认为1
 */
+(UIColor*)getColorWithRed:(int)red Green:(int)green Blue:(int)blue{
    return [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1.0];
}

/**
 *  好多时候 取色都是 r g b 相同
 */
+(UIColor*)getColorWithOneValue:(int)value{
    return [UIColor colorWithRed:value/255.0 green:value/255.0 blue:value/255.0 alpha:1.0];
}

/**
 *  好多时候 取色都是 r g b 相同 附加一个alpha
 */
+(UIColor*)getColorWithOneValue:(int)value withAlpha:(float)alpha{
    return [UIColor colorWithRed:value/255.0 green:value/255.0 blue:value/255.0 alpha:alpha];
}

/**
 *  设置圆角 ：注意 这个方式使用与 一个view 已经有了 frame 所以如果使用masonry 就在view 设置frame、之后 再调用这个方法
 */
+(void)setViewCorner:(UIView *)someView withNSOptions:(UIRectCorner)corner withCornerRadii:(CGSize)size{
    
    [someView layoutIfNeeded];
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:someView.bounds byRoundingCorners:corner cornerRadii:size];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = someView.bounds;
    maskLayer.path = maskPath.CGPath;
    someView.layer.mask = maskLayer;
}
/**
 *  得到一个可可以释放的UIImage
 */
+(UIImage*)getImageByPathWithImageName:(NSString*)imageName {
    NSString * imagePath = [[NSBundle mainBundle] pathForResource:imageName ofType:nil];
    UIImage * image = [UIImage imageWithContentsOfFile:imagePath];
    return image;
}

/**
 *  弹出一个提示框 仅仅提示用户 需要用户 点击确定或者取消
 */
+(void)showAlertWithMessage:(NSString*)message withVC:(UIViewController *)controller{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"提示"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              //响应事件
                                                              NSLog(@"action = %@", action);
                                                          }];
    
    [alert addAction:defaultAction];
    [controller presentViewController:alert animated:YES completion:nil];
}

/**
 *  弹出一个指定时间消失消失的提示框
 */
+(void)showAlertwithMessage:(NSString *)message withDuration:(CGFloat)duration withVC:(UIViewController*)controller{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"提示"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [NSTimer scheduledTimerWithTimeInterval:duration repeats:NO block:^(NSTimer * _Nonnull timer) {
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    [controller presentViewController:alert animated:YES completion:nil];
}



/**
 *  字典转json
 */
+ (NSString *)dic2Json:(NSDictionary*)dic{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString;
    if (!jsonData) {
        NSLog(@"%@",error);
    }else{
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];
    NSRange range = {0,jsonString.length};
    //去掉字符串中的空格
    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];
    NSRange range2 = {0,mutStr.length};

    //去掉字符串中的换行符
    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    return mutStr;
}

/**
 *  id 转变成 json
 */
+(NSString *)id2Json:(id)objc{
    NSData * jsondata = (NSData*)objc;
//    return [[NSString alloc] initWithData:jsonDate encoding:NSUTF8StringEncoding];
    NSString * jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
    return jsonString;
}

/**
 *  传入一个imageview 返回这个imageview 大小的 虚线
 */
+ (void)drawLineOfDashByImageView:(UIImageView *)imageView withColor:(UIColor*)color withLengths:(CGFloat [])lengh{
    // 开始划线 划线的frame
    UIGraphicsBeginImageContext(imageView.frame.size);
    
    [imageView.image drawInRect:CGRectMake(0, 0, imageView.frame.size.width, imageView.frame.size.height)];
    
    // 获取上下文
    CGContextRef line = UIGraphicsGetCurrentContext();
    
    // 设置线条终点的形状
    CGContextSetLineCap(line, kCGLineCapRound);
    // 设置虚线的长度 和 间距
//    CGFloat lengths[] = {5,5};
    
    CGContextSetStrokeColorWithColor(line, color.CGColor);
    // 开始绘制虚线
    CGContextSetLineDash(line, 0, lengh, 2);
    
    CGContextMoveToPoint(line, 0.0, 2.0);
    
    CGContextAddLineToPoint(line, imageView.frame.size.width, 2.0);
    
    CGContextStrokePath(line);
    
    [imageView setImage:UIGraphicsGetImageFromCurrentImageContext()];
    
}

+ (BOOL)isMobileNumber:(NSString *)mobileNum{
    if (mobileNum.length != 11)
    {
        return NO;
    }
    /**
     * 手机号码:
     * 13[0-9], 14[5,7], 15[0, 1, 2, 3, 5, 6, 7, 8, 9], 17[6, 7, 8], 18[0-9], 170[0-9]
     * 移动号段: 134,135,136,137,138,139,150,151,152,157,158,159,182,183,184,187,188,147,178,1705
     * 联通号段: 130,131,132,155,156,185,186,145,176,1709
     * 电信号段: 133,153,180,181,189,177,1700
     */
    NSString *MOBILE = @"^1(3[0-9]|4[57]|5[0-35-9]|8[0-9]|7[0678])\\d{8}$";
    /**
     * 中国移动：China Mobile
     * 134,135,136,137,138,139,150,151,152,157,158,159,182,183,184,187,188,147,178,1705
     */
    NSString *CM = @"(^1(3[4-9]|4[7]|5[0-27-9]|7[8]|8[2-478])\\d{8}$)|(^1705\\d{7}$)";
    /**
     * 中国联通：China Unicom
     * 130,131,132,155,156,185,186,145,176,1709
     */
    NSString *CU = @"(^1(3[0-2]|4[5]|5[56]|7[6]|8[56])\\d{8}$)|(^1709\\d{7}$)";
    /**
     * 中国电信：China Telecom
     * 133,153,180,181,189,177,1700
     */
    NSString *CT = @"(^1(33|53|77|8[019])\\d{8}$)|(^1700\\d{7}$)";
    
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    
    if (([regextestmobile evaluateWithObject:mobileNum] == YES)
        || ([regextestcm evaluateWithObject:mobileNum] == YES)
        || ([regextestct evaluateWithObject:mobileNum] == YES)
        || ([regextestcu evaluateWithObject:mobileNum] == YES)){
        
        return YES;
    }else{
        return NO;
    }
}

/**
 MD5加密
 @param input 待加密字符串
 @return MD5加密后的字符串
 */
+ (NSString *)dk_md5:(NSString *)input{
    const char *cStr = [[input dataUsingEncoding:NSUTF8StringEncoding] bytes];
    unsigned char digest[16];
    CC_MD5(cStr, (uint32_t)[[input dataUsingEncoding:NSUTF8StringEncoding] length], digest);
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
    return output;
}

/**
 *  string 类型时间戳转变成时间
 */
+ (NSString *)stringTimeStamp2StringTime:(NSString *)timeStamp{
   return [Utils intTimeStamp2StringTime:[timeStamp integerValue]];
}

/**
 *  int 类型时间戳转变成时间
 */
+ (NSString *)intTimeStamp2StringTime:(NSInteger)timeStamp{
    // iOS 生成的时间戳是10位
    NSTimeInterval interval    =timeStamp / 1000.0;
    NSDate *date               = [NSDate dateWithTimeIntervalSince1970:interval];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString * dateString      = [formatter stringFromDate: date];
    return dateString;
}

/**
 *  展示
 */
+ (void)showHUD:(UIView *)view{
    hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
}

+ (void)hideHUD{
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            [hud hideAnimated:YES];
        });
    });
}

+ (BOOL)isSettingScreenPassword{
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
    NSString * screenPassword = [userDefault objectForKey:@"屏幕密码"];
    if (screenPassword.length == 4) {
        return YES;
    }else{
        return NO;
    }
}

@end

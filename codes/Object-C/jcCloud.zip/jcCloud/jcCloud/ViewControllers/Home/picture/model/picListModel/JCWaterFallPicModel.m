//
//  JCWaterFallPicModel.m
//  jcCloud
//
//  Created by sharingmobile on 2018/3/28.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCWaterFallPicModel.h"

@implementation JCWaterFallPicModel

@end

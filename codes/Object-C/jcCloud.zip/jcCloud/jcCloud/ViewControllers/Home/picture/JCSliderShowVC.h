//
//  JCSliderShowVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeleteFile.h"

@interface JCSliderShowVC : UIViewController<DeleteFileDelegate>

//Delete file/folder option
@property(nonatomic, strong) DeleteFile *mDeleteFile;

-(void)setUrls:(NSArray *)urls;

-(void)setSelectedIndex:(NSInteger )selectedIndex;

@end

//
//  JCCustomCollectionViewCell.m
//  jcCloud
//
//  Created by sharingmobile on 2018/3/23.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCCustomCollectionViewCell.h"


@interface JCCustomCollectionViewCell()

@end

@implementation JCCustomCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initFrame];
    }
    return self;
}

-(void)initFrame{
    [self.contentView addSubview:self.imageview];
    [self.imageview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView);
    }];
    [self.contentView addSubview:self.coveringView];
    [self.coveringView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.imageview);
    }];
    [self.contentView addSubview:self.selectedView];
    [self.selectedView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.imageview.mas_right).offset(-5);
        make.bottom.mas_equalTo(self.imageview.mas_bottom).offset(-5);
        make.height.width.mas_equalTo(15);
    }];
}

- (void)imageSetURL:(NSString *)url{
    //设置网址
    NSURL * URL = [NSURL URLWithString:url];
    [self.imageview sd_setImageWithURL:URL];
}

-(UIImageView *)imageview{
    if (_imageview == nil) {
        _imageview = [[UIImageView alloc] init];
    }
    return _imageview;
}

-(UIImageView *)coveringView{
    if (_coveringView == nil) {
        _coveringView = [[UIImageView alloc]init];
        [_coveringView setBackgroundColor:[Utils getColorWithOneValue:255 withAlpha:0.5]];
        [_coveringView setHidden:YES];
    }
    return _coveringView;
}

-(UIImageView *)selectedView{
    if (_selectedView == nil) {
        _selectedView = [[UIImageView alloc] init];
        [_selectedView setImage:[UIImage imageNamed:@"selected"]];
    }
    return _selectedView;
}

@end

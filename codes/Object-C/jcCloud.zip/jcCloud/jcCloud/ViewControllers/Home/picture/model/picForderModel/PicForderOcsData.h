//
//PicForderOcsData.h 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface PicForderOcsData:NSObject
@property (nonatomic,strong) NSMutableArray *files;
@property (nonatomic,assign) NSInteger total_count;

@end

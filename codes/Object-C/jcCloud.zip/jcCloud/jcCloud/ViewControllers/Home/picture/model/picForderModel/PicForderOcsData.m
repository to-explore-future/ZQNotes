//
//PicForderOcsData.m 
//
//
//Create by sharingmobile on 18/3/29 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "PicForderOcsData.h"
@implementation PicForderOcsData

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"files":@"PicForderOcsDataFiles"
             };
}

@end

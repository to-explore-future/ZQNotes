//
//  Utils.h
//  baidufanyiTest
//
//  Created by sharingmobile on 2018/2/23.
//  Copyright © 2018年 sharingmobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface Utils : NSObject

//static MBProgressHUD * hud;

/**
 *  对 UIColor 的封装
 */
+(UIColor*)getColorWithRed:(int)red Green:(int)green Blue:(int)blue Alpha:(float)alpha;


/**
 *  对 UIColor 的封装 alpha 默认为1
 */
+(UIColor*)getColorWithRed:(int)red Green:(int)green Blue:(int)blue ;

/**
 *  好多时候 取色都是 r g b 相同
 */
+(UIColor*)getColorWithOneValue:(int)value;

/**
 *  好多时候 取色都是 r g b 相同
 */
+(UIColor*)getColorWithOneValue:(int)value withAlpha:(float)alpha;

/**
 *  设置圆角
 */
+(void)setViewCorner:(UIView *)someView withNSOptions:(UIRectCorner)corner withCornerRadii:(CGSize)size;

/**
 *  生成一个能够释放的 uiImage ,这种方式生成的 Image 不会再内存中长留
 *  注意：带着文件的后缀名
 */
+(UIImage*)getImageByPathWithImageName:(NSString*)imagePath;

/**
 *  弹出一个提示框 仅仅提示用户
 */
+(void)showAlertWithMessage:(NSString*)message withVC:(UIViewController *)controller;

/**
 *  弹出一个指定时间消失消失的提示框
 */
+(void)showAlertwithMessage:(NSString *)message withDuration:(CGFloat)duration withVC:(UIViewController*)controller;


/**
 *  字典转json
 */
+(NSString*)dic2Json:(NSDictionary*)dic;

/**
 *  id 转变成 json
 */
+(NSString *)id2Json:(id)objc;

/**
 *  传入一个imageview 返回这个imageview 大小的 虚线
 */
+ (void)drawLineOfDashByImageView:(UIImageView *)imageView withColor:(UIColor*)color withLengths:(CGFloat [])lengh;

/**
 *  正则验证手机号码
 */
+ (BOOL)isMobileNumber:(NSString *)mobileNum;

/**
 *  数据加密md5
 */
+ (NSString *)dk_md5:(NSString *)input;

/**
 *  string类型时间戳转变成时间
 */
+ (NSString *)stringTimeStamp2StringTime:(NSString *)timeStamp;

/**
 *  nsinteger类型时间戳转变成时间
 */
+ (NSString *)intTimeStamp2StringTime:(NSInteger)timeStamp;

/**
 *  展示HUD
 */
+ (void)showHUD:(UIView *)view;

+ (void)hideHUD;

/**
 *  是否开启屏幕密码
 */
+ (BOOL)isSettingScreenPassword;

@end

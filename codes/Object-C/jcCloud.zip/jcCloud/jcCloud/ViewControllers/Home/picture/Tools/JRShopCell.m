//
//  XXShopCell.m
//  WaterFallLayout
//
//  Created by sky on 16/6/6.
//  Copyright © 2016年 sky. All rights reserved.
//

#import "JRShopCell.h"
#import "UIImageView+WebCache.h"
#import "JRShop.h"

@interface JRShopCell (){
    NSInteger iconTag;
}

@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectedView;

@property CGFloat width;

@end

@implementation JRShopCell

- (void)setShop:(JRShop *)shop{
    _shop = shop;
    
    NSLog(@"url:%@",shop.img);
//    [self.iconView sd_setImageWithURL:[NSURL URLWithString:shop.img] ];
    if (self.iconView == nil) {
        
    }else{
        [self.iconView sd_setImageWithURL:[NSURL URLWithString:shop.img] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
            NSLog(@"error = %@",error);
            NSLog(@"url = %@",imageURL);
        }];
    }
    self.priceLabel.text = shop.price;
}

-(void)setCellWidth:(CGFloat)width{
    self.width = width;
}

- (void)setModel:(JCWaterFallPicModel *)model{
    self.iconView.userInteractionEnabled = YES;
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(iconViewAction)];
    [self.iconView addGestureRecognizer:tap];
    
    _model = model;
    [self.priceLabel setHidden:YES];
    if (self.iconView == nil) {
        
    }else{
        //求出 我需要的图片 宽度 高度 我要匹配 实际的大小
        CGFloat height = self.width * model.height / model.width ;
        //拼接url
        NSString * url = [NSString stringWithFormat:@"%@/%f/%f/%@",picBaseURL,self.width,height,model.path];
        NSString * urlUTF8 = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSLog(@"adjfajs   =%@",urlUTF8);
        [self.iconView sd_setImageWithURL:[NSURL URLWithString:urlUTF8] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
            NSLog(@"error = %@",error);
            NSLog(@"url = %@",imageURL);
        }];
    }
    if (model.isSelected) {
        [self.selectedView setHidden:NO];
    }else{
        [self.selectedView setHidden:YES];
    }
    
}

-(void)iconViewAction{
    NSLog(@"tag = %ld",iconTag);
    [self.delegate cellClickedPositio:iconTag];
    
    
}

-(void)setTag:(NSInteger)tag{
    iconTag = tag;
}


@end

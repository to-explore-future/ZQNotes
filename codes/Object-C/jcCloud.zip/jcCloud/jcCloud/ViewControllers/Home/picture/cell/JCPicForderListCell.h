//
//  JCPicForderListCell.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/29.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PicForderOcsDataFiles.h"

@protocol JCPicForderCellDelegate<NSObject>

-(void)catchImageForDownload:(UIImage *)catchImage;

@end

@interface JCPicForderListCell : UITableViewCell

@property(nonatomic,strong)UIImageView * image;
@property(nonatomic,strong)UILabel * name;
@property(nonatomic,strong)UILabel * info;
@property(nonatomic,strong)UIButton * rightArrow;
@property(nonatomic,weak)id<JCPicForderCellDelegate> delegate;

-(void)setType:(NSString *)type;

-(void)setData:(PicForderOcsDataFiles *)files;

@end

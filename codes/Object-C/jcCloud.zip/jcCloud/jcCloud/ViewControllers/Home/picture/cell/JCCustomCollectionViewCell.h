//
//  JCCustomCollectionViewCell.h
//  jcCloud
//
//  Created by sharingmobile on 2018/3/23.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCCustomCollectionViewCell : UICollectionViewCell

@property(nonatomic,strong)UIImageView * imageview;
@property(nonatomic,strong)UIImageView * coveringView;//覆盖层
@property(nonatomic,strong)UIImageView * selectedView;

-(void)imageSetURL:(NSString *)url;

@end

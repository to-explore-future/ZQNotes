//
//  XXShopCell.h
//  WaterFallLayout
//
//  Created by sky on 16/6/6.
//  Copyright © 2016年 sky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCWaterFallPicModel.h"
@class JRShop;

@protocol JRShopCellDelegate<NSObject>

-(void)cellClickedPositio:(NSInteger)position;

@end

@interface JRShopCell : UICollectionViewCell

@property(nonatomic,weak)id<JRShopCellDelegate> delegate;

@property (nonatomic, strong) JRShop *shop;
@property(nonatomic,strong)JCWaterFallPicModel * model;

-(void)setCellWidth:(CGFloat)width;

@end

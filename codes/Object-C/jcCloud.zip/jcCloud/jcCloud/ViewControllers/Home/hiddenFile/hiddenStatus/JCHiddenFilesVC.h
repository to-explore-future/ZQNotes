//
//  JCHiddenFilesVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/20.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCHiddenFileModel.h"

@interface JCHiddenFilesVC : UIViewController{
    NSString * pass;
    
}

@property(nonatomic,strong) NSString  * currenPageDirPath;      //当前目录的远程路径
@property(nonatomic,strong) NSString  * selectedStatus;
@property(nonatomic,strong) NSString  * isBasePath;

@property(nonatomic,strong) JCHiddenFileModel * baseModel;



-(void)getPicFolder;    //获取所有的文件夹

@end

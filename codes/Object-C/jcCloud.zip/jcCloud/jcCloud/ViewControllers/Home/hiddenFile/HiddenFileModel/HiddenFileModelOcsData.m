//
//HiddenFileModelOcsData.m 
//
//
//Create by sharingmobile on 18/4/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "HiddenFileModelOcsData.h"
@implementation HiddenFileModelOcsData

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"files":@"HiddenFileModelOcsDataFiles"
             };
}

@end

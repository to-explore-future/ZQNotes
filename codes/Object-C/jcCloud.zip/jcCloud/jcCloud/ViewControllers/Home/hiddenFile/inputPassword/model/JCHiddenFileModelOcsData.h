//
//JCHiddenFileModelOcsData.h 
//
//
//Create by sharingmobile on 18/4/20 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JCHiddenFileModelOcsDataDirinfo.h"
@interface JCHiddenFileModelOcsData:NSObject
@property (nonatomic,strong) NSMutableArray *files;
@property (nonatomic,strong) JCHiddenFileModelOcsDataDirinfo *dirinfo;
@property (nonatomic,assign) NSInteger total_count;

@end

//
//HiddenFileStatusOcs.h 
//
//
//Create by sharingmobile on 18/4/20 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HiddenFileStatusOcsMeta.h"
#import "HiddenFileStatusOcsData.h"
@interface HiddenFileStatusOcs:NSObject
@property (nonatomic,strong) HiddenFileStatusOcsMeta *meta;
@property (nonatomic,strong) HiddenFileStatusOcsData *data;

@end
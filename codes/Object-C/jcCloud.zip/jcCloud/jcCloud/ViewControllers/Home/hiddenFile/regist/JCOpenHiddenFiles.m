//
//  JCOpenHiddenFiles.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/22.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCOpenHiddenFiles.h"

#define TIMECOUNT 120

@interface JCOpenHiddenFiles ()

@property(nonatomic,strong)AFHTTPSessionManager * manager;
@property(nonatomic,strong)NSString * code;
@property(nonatomic,assign)NSInteger residueDegree;


@end

@implementation JCOpenHiddenFiles

-(void)viewWillAppear:(BOOL)animated{
    [self.tabBarController.tabBar setHidden:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view setBackgroundColor:[Utils getColorWithOneValue:237]];
    
    [self.view addSubview:self.phone];
    [self.phone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.view.mas_top).offset(104);
        make.height.mas_equalTo(50);
    }];
    
    [self.view addSubview:self.getSecurityCode];
    [self.getSecurityCode mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.view.mas_right).offset(-10);
        make.top.mas_equalTo(self.phone.mas_bottom).offset(15);
        make.width.mas_equalTo(120);
        make.height.mas_equalTo(48);
    }];
    
    [self.view addSubview:self.securityCode];
    [self.securityCode mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).offset(10);
        make.top.mas_equalTo(self.phone.mas_bottom).offset(15);
        make.right.mas_equalTo(self.getSecurityCode.mas_left).offset(-10);
        make.height.mas_equalTo(48);
    }];
    
    [self.view addSubview:self.hintTimes];
//    [self.hintTimes mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.mas_equalTo(self.view.mas_centerX);
//        make.top.mas_equalTo(self.securityCode.mas_bottom).offset(15);
//        make.height.mas_equalTo(30);
//        make.width.mas_equalTo(300);
//    }];
    
    [self.view addSubview:self.password];
    [self.password mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.hintTimes.mas_bottom).offset(15);
        make.height.mas_equalTo(50);
    }];
    
    [self.view addSubview:self.passwordAgain];
    [self.passwordAgain mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.password.mas_bottom).offset(-0.5);
        make.height.mas_equalTo(50);
    }];
    
    [self.view addSubview:self.ok];
    [self.ok mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(10);
        make.right.mas_equalTo(self.view).offset(-10);
        make.height.mas_equalTo(50);
        make.top.mas_equalTo(self.passwordAgain.mas_bottom).offset(40);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - method

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.phone resignFirstResponder];
    [self.securityCode resignFirstResponder];
    [self.passwordAgain resignFirstResponder];
    [self.password resignFirstResponder];
}

//开启倒计时
- (void)countDown {
    __block NSInteger second = TIMECOUNT;
    //(1)
    dispatch_queue_t quene = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    //(2)
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, quene);
    //(3)
    dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
    //(4)
    dispatch_source_set_event_handler(timer, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if (second == 0) {
                self.getSecurityCode.userInteractionEnabled = YES;
                [self.getSecurityCode setTitle:[NSString stringWithFormat:@"获取验证码"] forState:UIControlStateNormal];
                second = TIMECOUNT;
                //(6)
                dispatch_cancel(timer);
                
            } else {
                self.getSecurityCode.userInteractionEnabled = NO;
                [self.getSecurityCode setTitle:[NSString stringWithFormat:@"获取验证码(%ld)",second] forState:UIControlStateNormal];
                second--;
            }
        });
    });
    //(5)
    dispatch_resume(timer);
}

//提示用户还有几次验证码获取机会
- (void)showSMSTimes {
    CGFloat x = self.hintTimes.frame.origin.x;
    CGFloat y = self.hintTimes.frame.origin.y;
    CGFloat width = self.hintTimes.frame.size.width;
    CGFloat height = self.hintTimes.frame.size.height;
    [self.hintTimes setText:[NSString stringWithFormat:@"今日还剩余%ld次验证码获取机会",self.residueDegree]];
    if (height == 0) {
        [UIView animateWithDuration:0.5 animations:^{
            [self.hintTimes setFrame:CGRectMake(x , y , width, 30)];
        }];
    }else{
        NSLog(@"sldfjklafd");
    }
}

-(void)TogetSecurityCode{
    //验证手机号
    if ([Utils isMobileNumber:self.phone.text]) {
        [self countDown];
        
        //调用 验证码接口
        //    http://192.168.133.40:9091
        //    http://192.168.53.46:9092
        NSString * aa = @"http://192.168.133.40:9091/sharing/msg/shotmsg";
        NSString * apiKey = @"FXJC_20180323L";
        NSString * bus_code = @"1112";
        NSString * phone = @"18701038538";
        self.code = @"1423";
        
        
        NSString * sign = [NSString stringWithFormat:@"%@%@{\"phone\":\"%@\",\"code\":\"%@\"}%@",apiKey,phone,phone,self.code,bus_code];
        NSLog(@"sign = %@",sign);
        sign = [Utils dk_md5:sign];
        NSLog(@"sign = %@",sign);
        //    sgin=md5(FXJC_20180323L+1112+{"code": "1423","phone":"17001200107"}+17001200107)
        
        NSDictionary * param = @{
                                 @"sign":sign,
                                 @"bus_code":bus_code,
                                 @"mobile":phone,
                                 @"content":@{
                                         @"code":self.code,
                                         @"phone":phone
                                         }
                                 };
        NSLog(@"sign = %@",param);
        self.manager = [AFHTTPSessionManager manager];
        [self.manager.requestSerializer setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];//请求数据类型
        self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];     //http请求
        self.manager.requestSerializer.timeoutInterval = 60;                         //设置超时时间
        [self.manager.requestSerializer setStringEncoding:NSUTF8StringEncoding];     //设置编码格式
        self.manager.requestSerializer = [AFJSONRequestSerializer serializer];
        
        [self.manager POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //        [Utils hideHUD];
            NSLog(@"json-->sms = %@",[Utils id2Json:responseObject]);
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:nil error:nil];
            NSDictionary * result = dic[@"result"];
            self.residueDegree = [result[@"limit_times"] integerValue];
            [self showSMSTimes];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            //        [Utils hideHUD];
            NSLog(@"出错了 : = %@",error);
            [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
        }];
    }else{
        [Utils showAlertWithMessage:@"请检查手机号" withVC:self];
    }
    
    
}

-(void)openHiddenSpace{
    //当用户点击确定的时候呢 调用开启隐藏空间的 功能
//    http://x.x.x.x/ocs/v1.php/apps/jiacc_hide/api/v1/open
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_hide/api/v1/open?format=json";
    
    NSDictionary * param = @{//设置的隐藏空间的密码
                             // @"pwd":self.password.text
                             @"pwd":@"1234"
                             };
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //        [Utils hideHUD];
        NSLog(@"json-- status = %@",[Utils id2Json:responseObject]);
        //两种模式 一种是没有开启 一种是已经开启
        //1.没有开启
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:nil error:nil];
        NSDictionary * osc = dic[@"ocs"];
        NSInteger statuscode = [osc[@"statuscode"] integerValue];
        if (statuscode == 500) {//已经开启了
            
        }else if(statuscode == 100){//首次开启成功
            //绑定手机号
            
        }
        [self bindPhone];
       
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
    
    
}

//2.确认开启之后 绑定手机号 页面退出 提示用户 再次登录  还是 直接登录
-(void)bindPhone{
//    http://x.x.x.x/ocs/v1.php/apps/jiacc_hide/api/v1/bindphone
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_hide/api/v1/bindphone?format=json";
    
    NSDictionary * param = @{//设置的隐藏空间的密码
                             // @"pwd":self.password.text
                             @"phone":@"18701038538"
                             };
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //        [Utils hideHUD];
        NSLog(@"json-- status = %@",[Utils id2Json:responseObject]);
        
        //1.没有开启
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:nil error:nil];
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}




#pragma mark - lazyload

-(UITextField *)phone{
    if (_phone == nil) {
        _phone = [[UITextField alloc] init];
        _phone.placeholder = @"绑定手机号方便找回密码";
        _phone.layer.borderWidth = 0.5;
        _phone.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _phone.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _phone.leftViewMode = UITextFieldViewModeAlways;
        [_phone setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _phone;
}

-(UITextField *)securityCode{
    if (_securityCode == nil) {
        _securityCode = [[UITextField alloc] init];
        _securityCode.placeholder = @"请输入收到的验证码";
        _securityCode.layer.borderWidth = 0.5;
        _securityCode.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _securityCode.layer.cornerRadius = 3;
        _securityCode.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _securityCode.leftViewMode = UITextFieldViewModeAlways;
        [_securityCode setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _securityCode;
}

-(UITextField *)password{
    if (_password == nil) {
        _password = [[UITextField alloc] init];
        _password.placeholder = @"请输入密码";
        _password.layer.borderWidth = 0.5;
        _password.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _password.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _password.leftViewMode = UITextFieldViewModeAlways;
        [_password setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _password;
}

-(UITextField *)passwordAgain{
    if (_passwordAgain == nil) {
        _passwordAgain = [[UITextField alloc] init];
        _passwordAgain.placeholder = @"请再次输入密码";
        _passwordAgain.layer.borderWidth = 0.5;
        _passwordAgain.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _passwordAgain.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _passwordAgain.leftViewMode = UITextFieldViewModeAlways;
        [_passwordAgain setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _passwordAgain;
}

-(UIButton *)ok{
    if (_ok == nil) {
        _ok = [[UIButton alloc] init];
        [_ok setBackgroundColor:[Utils getColorWithRed:77 Green:114 Blue:140]];
        [_ok setTitle:@"确认" forState:UIControlStateNormal];
        [_ok setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_ok addTarget:self action:@selector(openHiddenSpace) forControlEvents:UIControlEventTouchUpInside];
        _ok.layer.cornerRadius = 5;
        _ok.layer.masksToBounds = YES;
    }
    return _ok;
}

-(UIButton *)getSecurityCode{
    if (_getSecurityCode == nil) {
        _getSecurityCode = [[UIButton alloc] init];
        [_getSecurityCode setBackgroundColor:[Utils getColorWithRed:61 Green:135 Blue:202]];
        [_getSecurityCode setTitle:@"获取验证码" forState:UIControlStateNormal];
        [_getSecurityCode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_getSecurityCode addTarget:self action:@selector(TogetSecurityCode) forControlEvents:UIControlEventTouchUpInside];
        [_getSecurityCode.titleLabel setFont:[UIFont systemFontOfSize:15]];
        _getSecurityCode.layer.cornerRadius = 3;
        _getSecurityCode.layer.masksToBounds = YES;
    }
    return _getSecurityCode;
}

-(UILabel *)hintTimes{
    if (_hintTimes == nil) {
        _hintTimes = [[UILabel alloc] initWithFrame:CGRectMake(30, 230, kScreen_width - 60, 0)];
        [_hintTimes setText:@"今日还剩余2次验证码获取机会"];
        [_hintTimes setTextColor:[Utils getColorWithRed:239 Green:122 Blue:0]];
        [_hintTimes setFont:[UIFont systemFontOfSize:16]];
        [_hintTimes setTextAlignment:NSTextAlignmentCenter];
//        [_hintTimes sizeToFit];
    }
    return _hintTimes;
}

@end

//
//HiddenFileStatus.h 
//
//
//Create by sharingmobile on 18/4/20 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HiddenFileStatusOcs.h"
#import "HiddenFileStatusOcsData.h"
#import "HiddenFileStatusOcsMeta.h"
@interface HiddenFileStatus:NSObject
@property (nonatomic,strong) HiddenFileStatusOcs *ocs;

@end

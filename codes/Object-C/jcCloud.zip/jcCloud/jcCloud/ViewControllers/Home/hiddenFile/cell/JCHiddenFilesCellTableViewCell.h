//
//  JCHiddenFilesCellTableViewCell.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/20.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCHiddenFileModelOcsDataFiles.h"

@interface JCHiddenFilesCellTableViewCell : UITableViewCell

@property(nonatomic,strong)UIImageView * image;
@property(nonatomic,strong)UILabel * name;
@property(nonatomic,strong)UILabel * info;
@property(nonatomic,strong)UIButton * rightArrow;
@property(nonatomic,strong)UIImageView * isSelected;
@property(nonatomic,strong)UIActivityIndicatorView * indicator;


-(void)setType:(NSString *)type;

-(void)setData:(JCHiddenFileModelOcsDataFiles *)files;

-(void)changeFlagViewFrameShow;

-(void)changeFlagViewFrameHidden;

@end

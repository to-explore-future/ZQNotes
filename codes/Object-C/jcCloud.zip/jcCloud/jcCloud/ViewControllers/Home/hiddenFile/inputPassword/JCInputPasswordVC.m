//
//  JCInputPasswordVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/20.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCInputPasswordVC.h"
#import "PicForder.h"
#import "JCHiddenFileModel.h"
#import "JCHiddenFilesVC.h"

@interface JCInputPasswordVC ()

@property(nonatomic,strong)JCHiddenFileModel * model;

@end

@implementation JCInputPasswordVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self.tabBarController.tabBar setHidden:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[Utils getColorWithOneValue:237]];
    
    [self.view addSubview:self.phone];
    [self.phone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.view.mas_top).offset(104);
        make.height.mas_equalTo(50);
    }];
    
    [self.view addSubview:self.password];
    [self.password mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.phone.mas_bottom).offset(-0.5);
        make.height.mas_equalTo(50);
    }];
    
    [self.view addSubview:self.ok];
    [self.ok mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(20);
        make.right.mas_equalTo(self.view.mas_right).offset(-20);
        make.height.mas_equalTo(50);
        make.top.mas_equalTo(self.password.mas_bottom).offset(60);
    }];
    
    [self.view addSubview:self.forgetPass];
    [self.forgetPass mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view);
        make.bottom.mas_equalTo(self.view.mas_bottom).offset(-10);
    }];
    
}

#pragma mark - method

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.phone resignFirstResponder];
    [self.password resignFirstResponder];
}

-(void)getHiddenInfo{
    
//    [Utils showHUD:self.navigationController.view];
    //    http://x.x.x.x/ocs/v1.php/apps/jiacc_hide/api/v1/list
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_hide/api/v1/in?format=json";
//    NSString * aa = @"http://192.168.53.90:7909/ocs/v1.php/apps/jiacc_hide/api/v1/list?format=json";
//    NSString * page = [NSString stringWithFormat:@"%ld",forderNeedMoreCount];
    NSDictionary * param = @{
//                             @"pwd":self.password.text
                             @"pwd":@"1234"
                             };

    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
//        [Utils hideHUD];

        NSLog(@"json-- status = %@",[Utils id2Json:responseObject]);
       NSDictionary* dic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        NSDictionary * ocs = dic[@"ocs"];
        NSDictionary * meta = ocs[@"meta"];
        NSInteger statuscode = [meta[@"statuscode"] integerValue];
//        [Utils hideHUD];
        if (statuscode == 100) {
            //说明手机验证成功
            //开启隐藏文件jiemian
            JCHiddenFilesVC * hiddenFile = [[JCHiddenFilesVC alloc] init];
            hiddenFile.currenPageDirPath = @"/";
            hiddenFile.selectedStatus = @"pic";
            hiddenFile.isBasePath = @"isBase";

            [self.navigationController pushViewController:hiddenFile animated:YES];

        }else{
            [Utils showAlertwithMessage:@"密码不正确" withDuration:2 withVC:self];
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}


#pragma mark - lazyload

-(UITextField *)phone{
    if (_phone == nil) {
        _phone = [[UITextField alloc] init];
        _phone.placeholder = @"输入手机号";
        _phone.layer.borderWidth = 0.5;
        _phone.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _phone.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _phone.leftViewMode = UITextFieldViewModeAlways;
        [_phone setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _phone;
}

-(UITextField *)password{
    if (_password == nil) {
        _password = [[UITextField alloc] init];
        _password.placeholder = @"输入密码";
        _password.layer.borderWidth = 0.5;
        _password.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _password.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 50)];
        _password.leftViewMode = UITextFieldViewModeAlways;
        [_password setBackgroundColor:[Utils getColorWithOneValue:254]];
    }
    return _password;
}

-(UIButton *)ok{
    if (_ok == nil) {
        _ok = [[UIButton alloc] init];
        [_ok setBackgroundColor:[Utils getColorWithRed:77 Green:114 Blue:140]];
        [_ok setTitle:@"确认" forState:UIControlStateNormal];
        [_ok setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_ok addTarget:self action:@selector(getHiddenInfo) forControlEvents:UIControlEventTouchUpInside];
        _ok.layer.cornerRadius = 5;
        _ok.layer.masksToBounds = YES;
    }
    return _ok;
}

-(UIButton *)forgetPass{
    if (_forgetPass == nil) {
        _forgetPass = [[UIButton alloc] init];
//        [_ok setBackgroundColor:[Utils getColorWithRed:77 Green:114 Blue:140]];
        [_forgetPass setTitle:@"忘记密码" forState:UIControlStateNormal];
        [_forgetPass setTitleColor:[Utils getColorWithOneValue:180] forState:UIControlStateNormal];
        [_forgetPass sizeToFit];
    }
    return _forgetPass;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



@end

//
//JCHiddenFileModelOcs.h 
//
//
//Create by sharingmobile on 18/4/20 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "JCHiddenFileModelOcsMeta.h"
#import "JCHiddenFileModelOcsData.h"
@interface JCHiddenFileModelOcs:NSObject
@property (nonatomic,strong) JCHiddenFileModelOcsMeta *meta;
@property (nonatomic,strong) JCHiddenFileModelOcsData *data;

@end
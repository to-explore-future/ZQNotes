//
//HiddenFileModelOcsMeta.h 
//
//
//Create by sharingmobile on 18/4/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface HiddenFileModelOcsMeta:NSObject
@property (nonatomic,copy) NSString *status;
@property (nonatomic,assign) NSInteger statuscode;
@property (nonatomic,copy) NSString *message;

@end
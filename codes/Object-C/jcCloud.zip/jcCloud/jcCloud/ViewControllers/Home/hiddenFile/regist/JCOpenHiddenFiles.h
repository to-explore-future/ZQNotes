//
//  JCOpenHiddenFiles.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/22.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCOpenHiddenFiles : UIViewController

@property(nonatomic,strong)UITextField * phone;
@property(nonatomic,strong)UITextField * securityCode;
@property(nonatomic,strong)UITextField * password;
@property(nonatomic,strong)UITextField * passwordAgain;

@property(nonatomic,strong)UILabel * hintTimes;


@property(nonatomic,strong)UIButton * ok;
@property(nonatomic,strong)UIButton * getSecurityCode;

@end

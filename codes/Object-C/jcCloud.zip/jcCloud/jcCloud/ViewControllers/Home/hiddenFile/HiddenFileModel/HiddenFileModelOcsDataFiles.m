//
//HiddenFileModelOcsDataFiles.m 
//
//
//Create by sharingmobile on 18/4/23 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import "HiddenFileModelOcsDataFiles.h"
@implementation HiddenFileModelOcsDataFiles

-(instancetype)init{
	self = [super init];
	if(self){

	}
	return self;
}

@end
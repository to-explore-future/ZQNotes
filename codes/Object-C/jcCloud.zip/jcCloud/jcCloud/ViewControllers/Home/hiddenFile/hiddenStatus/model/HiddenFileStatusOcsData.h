//
//HiddenFileStatusOcsData.h 
//
//
//Create by sharingmobile on 18/4/20 
//Copyright (c) 2018年 sharingmobile. All rights reserved.
//
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface HiddenFileStatusOcsData:NSObject
@property (nonatomic,copy) NSString *is_bind_phone;
@property (nonatomic,copy) NSString *hide_status;
@property (nonatomic,assign) NSInteger is_one;

@end
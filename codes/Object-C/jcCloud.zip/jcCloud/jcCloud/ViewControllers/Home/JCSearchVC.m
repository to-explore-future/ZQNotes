//
//  JCSearchVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/18.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCSearchVC.h"
#import "IATConfig.h"
#import "ISRDataHelper.h"
#import "JCSearchResult.h"
#import "MicroPhoneBottom.h"
#import "JCVolumeSearchVC.h"

@interface JCSearchVC ()<IFlySpeechRecognizerDelegate>{
    CGFloat deltaY;
}

@property(nonatomic,strong)UITextField * textTitle;
@property(nonatomic,strong)UIButton * searchIconBtn;
@property(nonatomic,strong)UIButton * searchBtn;
@property(nonatomic,strong)UIButton * cancleBtn;
@property(nonatomic,strong)UIButton * voiceSearch;
//不带界面的识别对象
@property (nonatomic, strong) IFlySpeechRecognizer *iFlySpeechRecognizer;

@property(nonatomic,strong)NSString * XFResult;

@property(nonatomic,strong)UIView * volume;
@property(nonatomic,strong)CAShapeLayer * layer;

@end

@implementation JCSearchVC

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden=NO;
    self.tabBarController.tabBar.hidden=YES;
    self.navigationController.navigationBar.topItem.title = @"家丞存储";
    NSLog(@"阿斯顿发生撒打发斯蒂芬  展现出阿里");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNotification];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"家丞存储";
    [self initView];
}

-(void)initNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(transformView:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

-(void)initView{
    [self.view addSubview:self.textTitle];
    [self.textTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).offset(20);
        make.right.mas_equalTo(self.view.mas_right).offset(-60);
        make.top.mas_equalTo(self.view.mas_top).offset(74);
        make.height.mas_equalTo(38);
    }];
    
    [self.view addSubview:self.searchBtn];
    [self.searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.textTitle.mas_right);
        make.top.mas_equalTo(self.textTitle.mas_top);
        make.bottom.mas_equalTo(self.textTitle.mas_bottom);
        make.width.mas_equalTo(80);
    }];
    
    [self.view addSubview:self.cancleBtn];
    [self.cancleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.textTitle.mas_right).offset(5);
        make.centerY.mas_equalTo(self.textTitle.mas_centerY);
        make.right.mas_equalTo(self.view.mas_right);
        make.height.mas_equalTo(38);
    }];
    
    [self.view addSubview:self.voiceSearch];
    
//    CGRect phoneBottomRect = CGRectMake(0, 0, 100, 100);
//    MicroPhoneBottom * phoneB = [[MicroPhoneBottom alloc] initWithFrame:phoneBottomRect];
//
//    CGRect bottomviewRect = CGRectMake(kScreen_width / 2, kScreen_height / 2, 100, 100);
//    UIView * bottomView = [[UIView alloc] initWithFrame:bottomviewRect];
//
//    [bottomView addSubview:phoneB];
//    [self.view addSubview:bottomView];
    
//    self.volume = [[UIView alloc] initWithFrame:CGRectMake(-40, -135, 80, 150)];
//    [self.volume setBackgroundColor:[UIColor lightGrayColor]];
//    self.volume.layer.cornerRadius = 40;
//    self.volume.layer.masksToBounds = YES;
//    UIBezierPath * path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 150, 80, 0) cornerRadius:0];
//    _layer = [CAShapeLayer layer];
//    _layer.path = path.CGPath;
//    _layer.fillColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.5].CGColor;
//    [self.volume.layer addSublayer:_layer];
//
//    [bottomView addSubview:self.volume];
}

-(void)transformView:(NSNotification *)aNSNotification{
    NSLog(@"");
    //获取键盘弹出前的Rect
    NSValue *keyBoardBeginBounds=[[aNSNotification userInfo]objectForKey:UIKeyboardFrameBeginUserInfoKey];
    CGRect beginRect=[keyBoardBeginBounds CGRectValue];
    
    //获取键盘弹出后的Rect
    NSValue *keyBoardEndBounds=[[aNSNotification userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect  endRect=[keyBoardEndBounds CGRectValue];
    
    //获取键盘位置变化前后纵坐标Y的变化值
    deltaY =endRect.origin.y-beginRect.origin.y;
    //    CGFloat absDeltaY = fabs(deltaY);
    CGFloat y = self.voiceSearch.frame.origin.y;
    CGFloat width = self.voiceSearch.frame.size.width;
    CGFloat height = self.voiceSearch.frame.size.height;
    
    if (deltaY < 0 ) { //向上移动
        [UIView animateWithDuration:0.25f animations:^{
            [self.voiceSearch setFrame:CGRectMake(0, y + deltaY, width, height)];
        }];
    }else{
        [UIView animateWithDuration:0.25f animations:^{
            [self.voiceSearch setFrame:CGRectMake(0, y + deltaY, width, height)];
        }];
    }
    
}

-(UITextField *)textTitle{
    if (_textTitle == nil) {
        _textTitle = [[UITextField alloc] init];
        [_textTitle.layer setCornerRadius:10];
        _textTitle.layer.borderColor = [Utils getColorWithOneValue:222].CGColor;
        _textTitle.layer.borderWidth = 2;
        _textTitle.leftView = self.searchIconBtn;
        _textTitle.leftViewMode = UITextFieldViewModeAlways;
        _textTitle.placeholder = @"搜索";
        [_textTitle setBackgroundColor:[Utils getColorWithOneValue:238]];
        //        _textTitle.rightView = self.searchBtn;
        //        _textTitle.rightViewMode = UITextFieldViewModeAlways;
        [_textTitle clipsToBounds];
        //        [_textTitle setBackgroundColor:[UIColor greenColor]];
    }
    return _textTitle;
}

-(UIButton *)searchIconBtn{
    if (_searchIconBtn == nil) {
        _searchIconBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 0, 40, 40)];
        [_searchIconBtn setImage:[UIImage imageNamed:@"search"] forState:UIControlStateNormal];
        
    }
    return _searchIconBtn;
}

-(UIButton *)searchBtn{
    if (_searchBtn == nil) {
        _searchBtn = [[UIButton alloc] init];
        [_searchBtn setBackgroundColor:[Utils getColorWithRed:132 Green:139 Blue:147]];
        [_searchBtn setTitle:@"搜索" forState:UIControlStateNormal];
        [_searchBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _searchBtn.layer.cornerRadius = 10;
        [_searchBtn addTarget:self action:@selector(gotoVoiceSearchVC) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchBtn;
}

-(UIButton *)cancleBtn{
    if (_cancleBtn == nil) {
        _cancleBtn = [[UIButton alloc] init];
        //        [_cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
        [_cancleBtn setImage:[UIImage imageNamed:@"语音识别"] forState:UIControlStateNormal];
        //        [_cancleBtn setTitleColor:[Utils getColorWithRed:0 Green:107 Blue:195] forState:UIControlStateNormal];
        [_cancleBtn addTarget:self action:@selector(openVolumeSearchVC) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cancleBtn;
}

-(UIButton *)voiceSearch{
    if (_voiceSearch == nil) {
        _voiceSearch = [[UIButton alloc] initWithFrame:CGRectMake(0, kScreen_height - 50, kScreen_width, 50)];
        [_voiceSearch setBackgroundColor:[Utils getColorWithRed:61 Green:135 Blue:202]];
        [_voiceSearch setTitle:@"  语音智能搜索" forState:UIControlStateNormal];
        [_voiceSearch setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_voiceSearch setImage:[UIImage imageNamed:@"voiceSearch"] forState:UIControlStateNormal];
        [_voiceSearch addTarget:self action:@selector(stopRecord) forControlEvents:UIControlEventTouchUpInside];
        [_voiceSearch addTarget:self action:@selector(startRecord) forControlEvents:UIControlEventTouchDown];
    }
    return _voiceSearch;
}

-(void)gotoVoiceSearchVC{
    JCSearchResult * result = [[JCSearchResult alloc] init];
    result.searchKey = self.textTitle.text;
    [self.navigationController pushViewController:result animated:YES];
}

-(void)openVolumeSearchVC{
    JCVolumeSearchVC * volumeS = [[JCVolumeSearchVC alloc] init];
    volumeS.callBackBlock = ^(NSString * text){
        NSLog(@"阿斯顿发生撒打发斯蒂芬  text = %@",text);
        [self.textTitle setText:text];
        
    };
    [self.navigationController pushViewController:volumeS animated:YES];
}

-(void)startRecord{
    //创建语音识别对象
    _iFlySpeechRecognizer = [IFlySpeechRecognizer sharedInstance];
    //设置识别参数
    //设置为听写模式
    [_iFlySpeechRecognizer setParameter: @"iat" forKey: [IFlySpeechConstant IFLY_DOMAIN]];
    //asr_audio_path 是录音文件名，设置value为nil或者为空取消保存，默认保存目录在Library/cache下。
    [_iFlySpeechRecognizer setParameter:@"iat.pcm" forKey:[IFlySpeechConstant ASR_AUDIO_PATH]];
    _iFlySpeechRecognizer.delegate = self;
    //启动识别服务
    [_iFlySpeechRecognizer startListening];
    //开启等待录音动画
}

-(void)stopRecord{
    [_iFlySpeechRecognizer stopListening];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.textTitle resignFirstResponder];
}

#pragma mark - IFlyRecognizerViewDelegate delegate

//IFlySpeechRecognizerDelegate协议实现
//识别结果返回代理
- (void) onResults:(NSArray *) results isLast:(BOOL)isLast{
    NSMutableString * resultString = [[NSMutableString alloc] init];
    NSDictionary * dic = results[0];
    NSLog(@"dic = %@",dic);
    for (NSString * key in dic) {
        [resultString appendFormat:@"%@",key];
    }
    NSString * result = [NSString stringWithFormat:@"%@%@",@"",resultString];
    NSLog(@"正式结果 ：%@",result);
    
    NSString * aaa = nil;
    if ([IATConfig sharedInstance].isTranslate) {//是否开起来了 自动翻译
        
    }else{
        aaa = [ISRDataHelper stringFromJson:resultString];
    }
    NSLog(@"aaa = %@",aaa);
    self.XFResult = [NSString stringWithFormat:@"%@%@",self.XFResult,aaa];
    NSLog(@"IFlySpeechRecognizer-onResults-录音有了结果:%@",self.XFResult);
    //去掉结果中的标点符号,以及其他的没用的字符
    //1.去掉 null
    if ([self.XFResult containsString:@"(null)"]) {
        self.XFResult = [self.XFResult componentsSeparatedByString:@"(null)"][1];
    }
    //去掉标点符号
    if ([self.XFResult containsString:@"。"]) {
        self.XFResult = [self.XFResult componentsSeparatedByString:@"。"][0];
    }
    
    [self.textTitle setText:self.XFResult];
    
}
//识别会话结束返回代理
- (void)onError: (IFlySpeechError *) error{
    self.XFResult = @"";
    NSLog(@"会话结束");
    
}
//停止录音回调
- (void) onEndOfSpeech{
    NSLog(@"停止录音");
}
//开始录音回调
- (void) onBeginOfSpeech{
    //我觉的一旦开始录音 就震动一下 提示用户
    //这里应该有 手机震动的代码
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    NSLog(@"开始录音");
    
//    self.waveView = [FingerWaveView showInView:self.view center:center];
    
}
//音量回调函数
- (void) onVolumeChanged: (int)volume{//返回的 0 -- 30 之间的数
    //volume 的高度是 150
    // volume : 0  --> y = 150  h = 0;
    // volume : 30 --> y = 0    h = 150;
    [_layer removeFromSuperlayer];
    
    CGFloat height = volume * 5;
    NSLog(@"height = %f",height);
    CGFloat y = 150 - height;
    UIBezierPath * path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, y, 80, height) cornerRadius:0];
    _layer = [CAShapeLayer layer];
    _layer.path = path.CGPath;
    _layer.fillColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.5].CGColor;
    [self.volume.layer addSublayer:_layer];
//    NSLog(@"音量： = %d",volume);
//    int temp = abs(self.volumBefore - volume);
//    if (temp > 3) {
//        //如果说音量很大 说明能量很大 那么能量波传播的更快 ：duration 变小
//        //这里把音量转换成一个与总音量的 比值 用这个比值 表示 波纹产生的频率
//        //设置波纹最慢 2 秒产生一次
//        CGFloat maxT = 3;
//        CGFloat minT = 0.2; //很密集
//
//        CGFloat vol = volume;
//        vol = (30 - vol) / 30;  //取值范围 在 0 - 1
//        if (vol < 0.2)
//            vol = 0.2;
    
//        [self.waveView setInterval:vol];
//    }
    
}
//会话取消回调
- (void) onCancel{
    NSLog(@"会话取消");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end

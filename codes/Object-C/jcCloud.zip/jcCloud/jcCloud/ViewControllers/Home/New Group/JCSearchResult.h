//
//  JCSearchResult.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/19.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCSearchResult : UIViewController

@property(nonatomic,strong)NSString* searchKey;

@end

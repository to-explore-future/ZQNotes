//
//  JCVolumeSearchVC.h
//  jcCloud
//
//  Created by sharingmobile on 2018/4/27.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^CallBackBlock) (NSString * text);

@interface JCVolumeSearchVC : UIViewController

@property(nonatomic,copy)CallBackBlock callBackBlock;

@end

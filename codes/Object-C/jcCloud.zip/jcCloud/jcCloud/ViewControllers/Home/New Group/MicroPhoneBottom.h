//
//  MicroPhoneBottom.h
//  LayerTest
//
//  Created by sharingmobile on 2018/4/27.
//  Copyright © 2018年 869518570@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MicroPhoneBottom : UIView

@property CGRect frame;

@end

//
//  JCSearchResult.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/19.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCSearchResult.h"
#import "PicForder.h"
#import "PicForderOcsDataFiles.h"
#import "JCAllFilesCell.h"

@interface JCSearchResult ()<UITableViewDelegate,UITableViewDataSource>{
    NSInteger forderNeedMoreCount;
    CGFloat tableViewCellHeight;
}

@property(nonatomic,strong)UITableView * tableview;
@property(nonatomic,strong)PicForder * picForder;

@end

@implementation JCSearchResult

-(void)viewWillAppear:(BOOL)animated{
   self.navigationController.navigationBar.topItem.title = @"";
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    self.title = @"搜索结果";
    [self initData];
    
    [self.view addSubview:self.tableview];
    [self.tableview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    [self loadData];
    
}

-(void)initData{
    forderNeedMoreCount = 1;
    tableViewCellHeight = 60;
}

-(void)loadData{
    self.tableview.mj_footer.state = MJRefreshStatePulling;
    [Utils showHUD:self.navigationController.view];
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_files/api/v1/list?format=json";
    NSString * page = [NSString stringWithFormat:@"%ld",forderNeedMoreCount];
    NSDictionary * param = @{
                             @"page":page,
                             @"pagecount":@"20",
                             @"key":self.searchKey
//                             @"dir":self.currenPageDirPath,
                             //                             @"mimetype_filter":@"image",
//                             @"sort":sort,
//                             @"direction":direction,
                             };
    
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [Utils hideHUD];
        NSLog(@"json = %@",[Utils id2Json:responseObject]);
//        [self.tableView.mj_footer endRefreshing];
        if (forderNeedMoreCount == 1) {
            self.picForder = [PicForder mj_objectWithKeyValues:responseObject];
            if (self.picForder.ocs.data.files.count < 20) {
                self.tableview.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }else{
            PicForder * tempPicForder = [PicForder mj_objectWithKeyValues:responseObject];
            NSArray * files = tempPicForder.ocs.data.files;
            NSInteger count = files.count;
            for (NSInteger i = 0; i < count; i++) {
                PicForderOcsDataFiles * file = files[i];;
                [self.picForder.ocs.data.files addObject:file];
            }
            if (count < 20) {
                self.tableview.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }
        [self.tableview reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}


#pragma mark - delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.picForder.ocs.data.files.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableViewCellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    JCAllFilesCell * cell = [tableView dequeueReusableCellWithIdentifier:@"allFilesTableviewCell"];
    if (cell == nil) {
        cell = [[JCAllFilesCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"allFilesTableviewCell"];
    }
   
    //设置数据
    PicForderOcsDataFiles * files = self.picForder.ocs.data.files[indexPath.row];
    [cell setData:files];
    
    return cell;
}





-(UITableView *)tableview{
    if (_tableview == nil) {
        _tableview = [[UITableView alloc] init];
        _tableview.delegate = self;
        _tableview.dataSource =self;
        _tableview.tableFooterView = [[UIView alloc] init];
    }
    return _tableview;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

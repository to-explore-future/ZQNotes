//
//  SelectLanguageVC.h
//  IMTranslate
//
//  Created by sharingmobile on 2018/3/6.
//  Copyright © 2018年 分享通讯-随译行. All rights reserved.
//

#import "BaseVC.h"

@interface SelectLanguageVC : BaseVC

@property(nonatomic,strong)NSString * notificationIdentifer; //消息标记

@end

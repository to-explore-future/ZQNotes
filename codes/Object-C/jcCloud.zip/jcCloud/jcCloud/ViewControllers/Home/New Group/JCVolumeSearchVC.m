//
//  JCVolumeSearchVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/27.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCVolumeSearchVC.h"
#import "IATConfig.h"
#import "ISRDataHelper.h"

@interface JCVolumeSearchVC ()<IFlySpeechRecognizerDelegate>



@property(nonatomic,strong)UIView * titleview;
@property(nonatomic,strong)UIButton * backBtn;
@property(nonatomic,strong)UILabel * viewTitle;

@property(nonatomic,strong)UIButton * microPhoneBtn;
@property(nonatomic,strong)UILabel * status;

@property (nonatomic, strong) IFlySpeechRecognizer *iFlySpeechRecognizer;

@property(nonatomic,strong)NSString * XFResult;

@end

@implementation JCVolumeSearchVC

-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController.navigationBar setHidden:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    UIColor * startColor = [Utils getColorWithRed:1 Green:104 Blue:147];
    UIColor * endColor = [Utils getColorWithRed:102 Green:207 Blue:212];
    gradientLayer.colors = @[(__bridge id)startColor.CGColor, (__bridge id)endColor.CGColor];
    gradientLayer.locations = @[@0, @1];
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1.0, 1.0);
    gradientLayer.frame = CGRectMake(0, 0, ScreenWidth, kScreen_height);
    [self.view.layer addSublayer:gradientLayer];
    
    [self.view addSubview:self.titleview];
    [self.titleview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(self.view);
        make.height.mas_equalTo(64);
    }];
    //给titleView添加子view
    [self.titleview addSubview:self.backBtn];
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.titleview.mas_bottom);
        make.left.mas_equalTo(self.titleview.mas_left).offset(5);
        make.height.width.mas_equalTo(44);
    }];
    
    [self.titleview addSubview:self.viewTitle];
    [self.viewTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.backBtn.mas_centerY);
        make.centerX.mas_equalTo(self.titleview.mas_centerX);
    }];
    
    [self.view addSubview:self.microPhoneBtn];
    [self.microPhoneBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.centerY.mas_equalTo(self.view);
        make.width.height.mas_equalTo(200);
    }];
    
    [self.view addSubview:self.status];
    [self.status mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.microPhoneBtn.mas_centerX);
        make.top.mas_equalTo(self.microPhoneBtn.mas_bottom).offset(30);
    }];
}

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

-(UIView *)titleview{
    if(_titleview == nil){
        _titleview = [[UIView alloc] init];
    }
    return _titleview;
}

-(UIButton *)backBtn{
    if(_backBtn == nil){
        _backBtn = [[UIButton alloc] init];
        [_backBtn setImage:[UIImage imageNamed:@"返回箭头"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [_backBtn setImageEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)];
        //        [_backBtn setBackgroundColor:[UIColor redColor]];
    }
    return _backBtn;
}

-(UILabel *)viewTitle{
    if(_viewTitle == nil){
        _viewTitle = [[UILabel alloc] init];
        [_viewTitle setText:@"语音识别"];
        [_viewTitle setTextColor:[UIColor whiteColor]];
        [_viewTitle setFont:[UIFont systemFontOfSize:24]];
    }
    return _viewTitle;
}

-(UIButton *)microPhoneBtn{
    if (_microPhoneBtn == nil) {
        _microPhoneBtn = [[UIButton alloc] init];
        [_microPhoneBtn setImage:[UIImage imageNamed:@"microPhone"] forState:UIControlStateNormal];
        [_microPhoneBtn addTarget:self action:@selector(startListen) forControlEvents:UIControlEventTouchUpInside];
    }
    return _microPhoneBtn;
}

-(UILabel *)status{
    if (_status == nil) {
        _status = [[UILabel alloc] init];
        [_status setText:@"倾听中 . . ."];
        [_status setTextColor:[Utils getColorWithOneValue:255 withAlpha:0.8]];
        [_status setFont:[UIFont systemFontOfSize:24]];
        [_status setHidden:YES];
    }
    return _status;
}

-(void)startListen{
    //创建语音识别对象
    _iFlySpeechRecognizer = [IFlySpeechRecognizer sharedInstance];
    //设置识别参数
    //设置为听写模式
    [_iFlySpeechRecognizer setParameter: @"iat" forKey: [IFlySpeechConstant IFLY_DOMAIN]];
    //asr_audio_path 是录音文件名，设置value为nil或者为空取消保存，默认保存目录在Library/cache下。
    [_iFlySpeechRecognizer setParameter:@"iat.pcm" forKey:[IFlySpeechConstant ASR_AUDIO_PATH]];
    _iFlySpeechRecognizer.delegate = self;
    //启动识别服务
    [_iFlySpeechRecognizer startListening];
    
    [self.status setHidden:NO];
}

#pragma mark - IFlyRecognizerViewDelegate delegate

//IFlySpeechRecognizerDelegate协议实现
//识别结果返回代理
- (void) onResults:(NSArray *) results isLast:(BOOL)isLast{
    NSMutableString * resultString = [[NSMutableString alloc] init];
    NSDictionary * dic = results[0];
    NSLog(@"dic = %@",dic);
    for (NSString * key in dic) {
        [resultString appendFormat:@"%@",key];
    }
    NSString * result = [NSString stringWithFormat:@"%@%@",@"",resultString];
    NSLog(@"正式结果 ：%@",result);
    
    NSString * aaa = nil;
    if ([IATConfig sharedInstance].isTranslate) {//是否开起来了 自动翻译
        
    }else{
        aaa = [ISRDataHelper stringFromJson:resultString];
    }
    NSLog(@"aaa = %@",aaa);
    self.XFResult = [NSString stringWithFormat:@"%@%@",self.XFResult,aaa];
    NSLog(@"IFlySpeechRecognizer-onResults-录音有了结果:%@",self.XFResult);
    //去掉结果中的标点符号,以及其他的没用的字符
    //1.去掉 null
    if ([self.XFResult containsString:@"(null)"]) {
        self.XFResult = [self.XFResult componentsSeparatedByString:@"(null)"][1];
    }
    //去掉标点符号
    if ([self.XFResult containsString:@"。"]) {
        self.XFResult = [self.XFResult componentsSeparatedByString:@"。"][0];
    }
    
//    [self.textTitle setText:self.XFResult];
    
}
//识别会话结束返回代理
- (void)onError: (IFlySpeechError *) error{
    NSLog(@"会话结束");
    self.callBackBlock(self.XFResult);
    [self.navigationController popViewControllerAnimated:YES];
}
//停止录音回调
- (void) onEndOfSpeech{
    NSLog(@"停止录音");
    
}
//开始录音回调
- (void) onBeginOfSpeech{
    //我觉的一旦开始录音 就震动一下 提示用户
    //这里应该有 手机震动的代码
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    NSLog(@"开始录音");
    
    //    self.waveView = [FingerWaveView showInView:self.view center:center];
    
}
//音量回调函数
- (void) onVolumeChanged: (int)volume{//返回的 0 -- 30 之间的数
    //volume 的高度是 150
    // volume : 0  --> y = 150  h = 0;
    // volume : 30 --> y = 0    h = 150;
//    [_layer removeFromSuperlayer];
//
//    CGFloat height = volume * 5;
//    NSLog(@"height = %f",height);
//    CGFloat y = 150 - height;
//    UIBezierPath * path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, y, 80, height) cornerRadius:0];
//    _layer = [CAShapeLayer layer];
//    _layer.path = path.CGPath;
//    _layer.fillColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.5].CGColor;
//    [self.volume.layer addSublayer:_layer];
    //    NSLog(@"音量： = %d",volume);
    //    int temp = abs(self.volumBefore - volume);
    //    if (temp > 3) {
    //        //如果说音量很大 说明能量很大 那么能量波传播的更快 ：duration 变小
    //        //这里把音量转换成一个与总音量的 比值 用这个比值 表示 波纹产生的频率
    //        //设置波纹最慢 2 秒产生一次
    //        CGFloat maxT = 3;
    //        CGFloat minT = 0.2; //很密集
    //
    //        CGFloat vol = volume;
    //        vol = (30 - vol) / 30;  //取值范围 在 0 - 1
    //        if (vol < 0.2)
    //            vol = 0.2;
    
    //        [self.waveView setInterval:vol];
    //    }
    
}
//会话取消回调
- (void) onCancel{
    NSLog(@"会话取消");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end

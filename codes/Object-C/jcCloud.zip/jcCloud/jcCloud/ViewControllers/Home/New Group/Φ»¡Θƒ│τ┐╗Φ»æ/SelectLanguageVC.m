//
//  SelectLanguageVC.m
//  IMTranslate
//
//  Created by sharingmobile on 2018/3/6.
//  Copyright © 2018年 分享通讯-随译行. All rights reserved.
//

#import "SelectLanguageVC.h"

@interface SelectLanguageVC ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView * tableView;         //语言选择
@property(nonatomic,strong)NSArray * titleHeader;
@property(nonatomic,strong)NSArray * language;
@property(nonatomic,strong)NSArray * lauguageIdentifer;

@end

@implementation SelectLanguageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.navigationItem.title = @"语言选择";
    [self.navigationController.navigationBar setBackgroundImage:[Utils getImageByPathWithImageName:@"statusbar.png"] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    //设置左侧的返回 按钮
    UIBarButtonItem * backBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Ios_Back_Icon.png"] style:UIBarButtonItemStyleDone target:self action:@selector(backAction)];
    [backBtn setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = backBtn;
}

-(void)initNotification{
    
}

-(void)initData{
    
}

-(void)initFrame{
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
}

-(void)loadData{
    //还有更简单的方法吗
    self.titleHeader = @[@"常用语言",
                              @"A",
                              @"B",
                              @"D",
                              @"E",
                              @"F",
                              @"H",
                              @"J",
                              @"L",
                              @"P",
                              @"R",
                              @"S",
                              @"T",
                              @"W",
                              @"X",
                              @"Y",
                              @"Z"];
    self.language =     @[
                           @[@"中文",@"英语",@"自动检测"],
                           @[@"阿拉伯语",@"爱沙尼亚语"],
                           @[@"保加利亚语",@"波兰语"],
                           @[@"德语",@"丹麦语"],
                           @[@"俄语"],
                           @[@"芬兰语",@"法语"],
                           @[@"韩语",@"荷兰语"],
                           @[@"捷克语"],
                           @[@"罗马尼亚语"],
                           @[@"葡萄牙语"],
                           @[@"日语",@"瑞典语"],
                           @[@"斯洛文尼亚语"],
                           @[@"泰语"],
                           @[@"文言文"],
                           @[@"西班牙语",@"希腊语",@"匈牙利语"],
                           @[@"英语",@"粤语",@"意大利语",@"越南语"],
                           @[@"中文",@"中文繁体"]
                           ];
    self.lauguageIdentifer =     @[
                          @[@"zh",@"en",@"auto"],
                          @[@"ara",@"est"],
                          @[@"bul",@"pl"],
                          @[@"de",@"dan"],
                          @[@"ru"],
                          @[@"nl",@"fra"],
                          @[@"kor",@"nl"],
                          @[@"cs"],
                          @[@"rom"],
                          @[@"pt"],
                          @[@"jp",@"swe"],
                          @[@"slo"],
                          @[@"th"],
                          @[@"wyw"],
                          @[@"spa",@"el",@"hu"],
                          @[@"en",@"yue",@"it",@"vie"],
                          @[@"zh",@"cht"]
                          ];
}

#pragma mark - action

-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - delegate

#pragma mark UITableView delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.titleHeader.count;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return self.titleHeader[section];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray * aa = self.language[section];
    return aa.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString * reuseID = @"name";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:reuseID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseID];
    }
    cell.textLabel.text = self.language[indexPath.section][indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //生成要发送的信息
    NSMutableArray * languageInfo = [[NSMutableArray alloc] init];
    [languageInfo addObject:self.language[indexPath.section][indexPath.row]];
    [languageInfo addObject:self.lauguageIdentifer[indexPath.section][indexPath.row]];
    if ([self.notificationIdentifer isEqualToString:@"textTranslate_from"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"textTranslate_from" object:languageInfo];
    }else if([self.notificationIdentifer isEqualToString:@"textTranslate_to"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"textTranslate_to" object:languageInfo];
    }else if([self.notificationIdentifer isEqualToString:@"VoiceTranslate_from"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"VoiceTranslate_from" object:languageInfo];
    }else if([self.notificationIdentifer isEqualToString:@"VoiceTranslate_to"]){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"VoiceTranslate_to" object:languageInfo];
    }
    
    //最后关闭页面
    [self.navigationController popViewControllerAnimated:YES];
}



#pragma mark - lazyload

-(UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
//        [_tableView setBackgroundColor:[UIColor greenColor]];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

//
//  JCAllFilesCell.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/17.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCAllFilesCell.h"

@implementation JCAllFilesCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initFrame];
    }
    return self;
}

-(void)initFrame{
    [self.contentView addSubview:self.isSelected];
//    [self.isSelected mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(self.mas_left).offset(-20);
//        make.centerY.mas_equalTo(self.mas_centerY);
//        make.width.height.mas_equalTo(20);
//    }];
    [self.contentView addSubview:self.rightArrow];
    [self.rightArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.image];
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.isSelected.mas_right).offset(20);
        make.top.mas_equalTo(self.mas_top).offset(10);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-10);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.name];
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(10);
        make.top.mas_equalTo(self.mas_top).offset(5);
        make.height.mas_equalTo(30);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-10);
    }];
    [self.contentView addSubview:self.info];
    [self.info mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.name.mas_left);
        make.top.mas_equalTo(self.name.mas_bottom);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-5);
        make.height.mas_equalTo(15);
    }];
    
}

#pragma mark - action

-(void)setType:(NSString *)type{
    
}

-(void)setData:(PicForderOcsDataFiles *)files{
    NSString * name = files.name;
    NSInteger upload_time = files.upload_time;
    //如果是文件夹  如果是文件
    NSInteger fileCount = files.file_count;
    [self.name setText:name];
    NSString * time = [Utils intTimeStamp2StringTime:upload_time];
    if ([files.type isEqualToString:@"dir"]) {
        NSLog(@"文件夹");
        //文件夹显示 数目
        [self.info setText:[NSString stringWithFormat:@"%ld项  %@",fileCount,time]];
        [self.rightArrow setHidden:NO];
        [self.image setImage:[UIImage imageNamed:@"列表文件夹"]];
    }else{
        //文件不显示 数目
        [self.info setText:[NSString stringWithFormat:@"%@",time]];
        [self.rightArrow setHidden:YES];
        //        if ([files.mimetype isEqualToString:@"video/mp4"]  || [files.mimetype isEqualToString:@"image/png"]) {
        NSLog(@"文件");
        NSString * itemSize = [NSString stringWithFormat:@"/%f/%f/",50.0,50.0];
        NSString * allURL = [NSString stringWithFormat:@"%@%@%@",picBaseURL,itemSize,files.path];
        NSString * url_utf8 = [allURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        //            NSLog(@"allURLaaa : %@",url_utf8);
        [self.image sd_setImageWithURL:[NSURL URLWithString:url_utf8]];
        //        }
    }
    
    if (files.isSelected) {
        [self.isSelected setImage:[UIImage imageNamed:@"selected"]];
    }else{
        [self.isSelected setImage:[UIImage imageNamed:@"unSelected"]];
    }
    
}

-(void)changeFlagViewFrameShow{
    [self.contentView setNeedsLayout];
    [self.contentView layoutIfNeeded];
    
    [self.isSelected setFrame:CGRectMake(20, 20, 20, 20)];
    
    [self.contentView addSubview:self.rightArrow];
    [self.rightArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.image];
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.isSelected.mas_right).offset(20);
        make.top.mas_equalTo(self.mas_top).offset(10);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-10);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.name];
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(10);
        make.top.mas_equalTo(self.mas_top).offset(5);
        make.height.mas_equalTo(30);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-10);
    }];
    [self.contentView addSubview:self.info];
    [self.info mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.name.mas_left);
        make.top.mas_equalTo(self.name.mas_bottom);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-5);
        make.height.mas_equalTo(15);
    }];
}

-(void)changeFlagViewFrameHidden{
    [self.contentView setNeedsLayout];
    [self.contentView layoutIfNeeded];
    
    [self.isSelected setFrame:CGRectMake(-20, 20, 20, 20)];
    
    [self.contentView addSubview:self.rightArrow];
    [self.rightArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.height.mas_equalTo(self.mas_height);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.image];
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.isSelected.mas_right).offset(20);
        make.top.mas_equalTo(self.mas_top).offset(10);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-10);
        make.width.mas_equalTo(50);
    }];
    [self.contentView addSubview:self.name];
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.image.mas_right).offset(10);
        make.top.mas_equalTo(self.mas_top).offset(5);
        make.height.mas_equalTo(30);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-10);
    }];
    [self.contentView addSubview:self.info];
    [self.info mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.name.mas_left);
        make.top.mas_equalTo(self.name.mas_bottom);
        make.right.mas_equalTo(self.rightArrow.mas_left).offset(-5);
        make.height.mas_equalTo(15);
    }];
    
}

#pragma mark - lazyload

-(UILabel *)name{
    if (_name == nil) {
        _name = [[UILabel alloc] init];
        [_name setTextColor:[UIColor blackColor]];
        [_name setFont:[UIFont systemFontOfSize:18]];
        //        [_name setBackgroundColor:[UIColor greenColor]];
    }
    return _name;
}

-(UIButton *)rightArrow{
    if (_rightArrow == nil) {
        _rightArrow = [[UIButton alloc] init];
        [_rightArrow setImage:[UIImage imageNamed:@"picture_right_arrow"]forState:UIControlStateNormal];
    }
    return _rightArrow;
}

-(UIImageView *)image{
    if (_image == nil) {
        _image = [[UIImageView alloc] init];
        [_image setImage:[UIImage imageNamed:@"列表文件夹"]];
    }
    return _image;
}

-(UILabel *)info{
    if (_info == nil) {
        _info = [[UILabel alloc]init];
        [_info setTextColor:[UIColor lightGrayColor]];
        [_info setFont:[UIFont systemFontOfSize:14]];
        //        [_info setBackgroundColor:[UIColor redColor]];
    }
    return _info;
}

-(UIImageView *)isSelected{
    if (_isSelected == nil) {
        _isSelected = [[UIImageView alloc] initWithFrame:CGRectMake(-20, 20, 20, 20)];
        [_isSelected setImage:[UIImage imageNamed:@"unSelected"]];
    }
    return _isSelected;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

//
//  JCAllFilesVC.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/17.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCAllFilesVC.h"
#import "JCPictureVCViewController.h"
#import "NHHomeHeaderOptionalView.h"
#import "NHCustomSlideViewController.h"
#import "JCDayPicVC.h"
#import "DKNetworking.h"
#import "PicList.h"
#import "PicListOcsDataImages.h"
#import "PicListOcsDataImagesFiles.h"
#import "JCCustomCollectionViewCell.h"
#import "JCPicListHeaderCell.h"
#import "JCSliderShowVC.h"
#import "JCWaterFallPicModel.h"
#import "PicForder.h"
#import "JCPicForderListCell.h"
#import "PicForderOcsDataFiles.h"
#import "JCCommenToolView.h"
#import "ELCImagePickerController.h"
#import "ELCAlbumPickerController.h"
#import "MJRefresh.h"
#import "AppDelegate.h"
#import "JCAllFilesCell.h"
#import "JCNewTextFile.h"
#import "YFKit.h"
#import "FileNameUtils.h"
#import "NSString+Encoding.h"
#import "UtilsUrls.h"
#import "OCCommunication.h"

#define screenWidth [[UIScreen mainScreen] bounds].size.width

#define XXWeakSelf(object) __weak __typeof(object) weakSelf = object;

@interface JCAllFilesVC ()<NHCustomSlideViewControllerDataSource, NHCustomSlideViewControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,ELCImagePickerControllerDelegate,UIActionSheetDelegate>{
    UIButton *channelChangeBtn;
    CGFloat itemWidth ;
    CGFloat titleViewHeight;
    CGFloat folderBtnWidth;
    CGFloat tableViewCellHeight;
    Boolean isSelectStatus;
    NSInteger picNeedMoreCount;//加载更多次数
    NSInteger forderNeedMoreCount;
    NSNumber * sort;
    NSNumber * direction;
    int getPicFolderTime;
    
    JCCommenToolView *bottomToolView;
}

@property(nonatomic,strong)     NHHomeHeaderOptionalView    * optionalView;
@property(nonatomic,  weak)     NHCustomSlideViewController * slideViewController;
@property(nonatomic,strong)     NSMutableArray          * controllers;
@property(nonatomic,strong)     NSArray                 * titles;
@property(nonatomic,assign)     NSInteger                 nowIndex;//当前选中索引值
@property(nonatomic,strong)     PicList                 * picList;
//@property(nonatomic,strong)     UICollectionView        * collectionView;
@property(nonatomic,strong)     NSMutableArray          * waterFallPics;
@property(nonatomic,strong)     UIView                  * titleView; //显示方式的分类
//@property(nonatomic,strong)     UISegmentedControl      * segmentControl;
@property(nonatomic,strong)     UIView                  * folderActionBtnsView;
@property(nonatomic,strong)     UIButton                * addFolder;
@property(nonatomic,strong)     UIButton                * upload;
@property(nonatomic,strong)     UIButton                * sort;
@property(nonatomic,strong)     UIView                  * aline;
@property(nonatomic,strong)     UITableView             * tableView;
@property(nonatomic,strong)     PicForder               * picForder;
//PicForderOcsDataFiles * files
@property(nonatomic,strong)PicForderOcsDataFiles * files;

@property CGFloat colletionViewHeaderHeight;
@property (nonatomic, strong) ELCAlbumPickerController *albumController;
@property (nonatomic, strong) ELCImagePickerController *elcPicker;

@end

@implementation JCAllFilesVC

-(void)viewWillAppear:(BOOL)animated{
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    app.allFileVC=self;

    [self.tabBarController.tabBar setHidden:YES];
    if ([self.isBasePath isEqualToString:@"isBase"]) {
        self.navigationController.navigationBar.topItem.title = @"综合文件";
    }else{
        self.navigationController.navigationBar.topItem.title = @"";
        NSArray * whichIs = [self.currenPageDirPath componentsSeparatedByString:@"/"];
        NSInteger position = whichIs.count;
        self.title = whichIs[position - 2];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"JCPicForderListCellRightArrowAction" object:nil];
}

- (BOOL)navigationShouldPopOnBackButton{
    
    if ([self.currenPageDirPath isEqualToString:@"/"]) {
        for (UIViewController *controller in self.navigationController.viewControllers) {
            if ([controller isKindOfClass:[JCHomeVC class]]) {
                JCHomeVC *home =(JCHomeVC *)controller;
                [self.navigationController popToViewController:home animated:YES];
                break;
            }
        }
        return NO;
    }else {
        return YES;
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNotification];
    [self initData];
    self.title = @"综合文件";
    //搞一个名称数组
//    self.titles = @[@"11"];
//    self.optionalView.titles = self.titles;
//    //根据数组的长度 生成 slideView的vcs
//    for (int i = 0; i < self.titles.count; i++) {
//        UIViewController * vc = [[UIViewController alloc] init];
//        [vc.view setBackgroundColor:[UIColor whiteColor]];
//        [self.controllers addObject:vc];
//    }
//    [self.view addSubview:self.optionalView];
//    XXWeakSelf(self);
//    self.optionalView.homeHeaderOptionalViewItemClickHandle = ^(NHHomeHeaderOptionalView *view, NSString *currentTitle, NSInteger currentIndex) {
//        weakSelf.slideViewController.seletedIndex = currentIndex;
//        weakSelf.nowIndex = currentIndex;
//    };
//    [self addChildViewController:self.slideViewController];
//    [self.slideViewController initializedViewControllerAtIndex:0];
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.tableView registerClass:[JCAllFilesCell class] forCellReuseIdentifier:@"allFilesTableviewCell"];
    
    //生成头部的titleview
    [self initView];
    [self loadData];
    
    CGRect boxFrame=CGRectMake(0,kScreen_height, kScreen_width, 50);
    bottomToolView=[[JCCommenToolView alloc] initWithFrame:boxFrame isHidden:NO];
    [self.view addSubview:bottomToolView];
    [bottomToolView setHidden:YES];
}

-(void)initNotification{
    //打开瀑布流界面
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rightArrowAction:) name:@"picListRightArrowAction" object:nil];
}


-(void)initData{
    self.colletionViewHeaderHeight = 40;
    titleViewHeight = 50;
    folderBtnWidth = 50;
    tableViewCellHeight = 60;
    picNeedMoreCount = 1;
    forderNeedMoreCount = 1;
    sort = @1;
    direction = @1;
    getPicFolderTime = 0;
}

-(void)initView{
    [self.view addSubview:self.titleView];
    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top).offset(64);
        make.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(titleViewHeight);
    }];

    [self.titleView addSubview:self.folderActionBtnsView];
    [self.folderActionBtnsView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.bottom.mas_equalTo(self.titleView);
        make.left.mas_equalTo(self.view.mas_left).offset(100);
    }];
    [self.folderActionBtnsView addSubview:self.addFolder];
    [self.folderActionBtnsView addSubview:self.upload];
    [self.folderActionBtnsView addSubview:self.sort];
    [self.sort mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.folderActionBtnsView.mas_right).offset(-10);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 10);
        make.width.mas_equalTo(folderBtnWidth);
    }];
    [self.upload mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.sort.mas_left).offset(-10);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 10);
        make.width.mas_equalTo(folderBtnWidth);
    }];
    [self.addFolder mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.upload.mas_left).offset(-10);
        make.centerY.mas_equalTo(self.folderActionBtnsView.mas_centerY);
        make.height.mas_equalTo(titleViewHeight - 10);
        make.width.mas_equalTo(folderBtnWidth + 5);
    }];
    [self.view addSubview:self.aline];
    [self.aline mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(0.5);
        make.top.mas_equalTo(self.titleView.mas_bottom);
    }];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.top.mas_equalTo(self.titleView.mas_bottom);
        make.bottom.mas_equalTo(self.view.mas_bottom);
    }];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        forderNeedMoreCount ++;
        [self getPicFolder];
    }];
    
    //标题右侧的连个button
    UIBarButtonItem * right1 = [[UIBarButtonItem alloc] initWithTitle:@"选择" style:UIBarButtonItemStyleDone target:self action:@selector(selectBtnAction)];
    
    self.navigationItem.rightBarButtonItem = right1;
    
    UIBarButtonItem * right2 = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStyleDone target:self action:@selector(right2Action)];
    NSArray * rightBtns = [NSArray arrayWithObjects:right1,right2, nil];
    self.navigationItem.rightBarButtonItems = rightBtns;
}

-(void)loadData{
    [self getPicFolder];
}

-(void)getPicFolder{
    self.tableView.mj_footer.state = MJRefreshStatePulling;
    [Utils showHUD:self.navigationController.view];
    NSString * aa = @"http://192.168.133.42/ocs/v1.php/apps/jiacc_files/api/v1/list?format=json";
    NSString * page = [NSString stringWithFormat:@"%ld",forderNeedMoreCount];
    NSDictionary * param = @{
                             @"page":page,
                             @"pagecount":@"20",
                             @"dir":self.currenPageDirPath,
//                             @"mimetype_filter":@"image",
                             @"sort":sort,
                             @"direction":direction,
                             };
    
    [[NetWork getInstance] POST:aa parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        [Utils hideHUD];
        NSLog(@"json = %@",[Utils id2Json:responseObject]);
        [self.tableView.mj_footer endRefreshing];
        if (forderNeedMoreCount == 1) {
            self.picForder = [PicForder mj_objectWithKeyValues:responseObject];
            if (self.picForder.ocs.data.files.count < 20) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }else{
            PicForder * tempPicForder = [PicForder mj_objectWithKeyValues:responseObject];
            NSArray * files = tempPicForder.ocs.data.files;
            NSInteger count = files.count;
            for (NSInteger i = 0; i < count; i++) {
                PicForderOcsDataFiles * file = files[i];;
                [self.picForder.ocs.data.files addObject:file];
            }
            if (count < 20) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }
        }
        [self.tableView reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [Utils hideHUD];
        NSLog(@"出错了 : = %@",error);
        [Utils showAlertwithMessage:@"网络繁忙,请稍后重试" withDuration:2 withVC:self];
    }];
}

#pragma mark - action

//自己push 自己
-(void)selfPushSelfRightArrowAction:(NSNotification *)notification{
    NSString * path = (NSString *)[notification object];
    NSLog(@"path = %@",path);
    //push到下一个页面 把请求的 路径拼接好 展示出来
    NSString * nextPath = @"";
    if ([self.currenPageDirPath isEqualToString:@"/"]) {
        nextPath = [NSString stringWithFormat:@"/%@/",path];
    }else{
        nextPath = [NSString stringWithFormat:@"%@/%@/",self.currenPageDirPath,path];
    }
    JCPictureVCViewController * pic = [[JCPictureVCViewController alloc] init];
    pic.currenPageDirPath = nextPath;
    pic.selectedStatus = self.selectedStatus;
    [self.navigationController pushViewController:pic animated:YES];
}

//刷新页面
-(void)selectBtnAction{
    UIBarButtonItem * right1 = self.navigationItem.rightBarButtonItems[0];
    
    if ([right1.title isEqualToString:@"选择"]) {
        //目前是选择状态
        isSelectStatus = YES;
        right1.title = @"取消";
        [bottomToolView setHidden:NO];
        
        
    }else if([right1.title isEqualToString:@"取消"]){
        right1.title = @"选择";
        isSelectStatus = NO;
        //所有的数据的选择状态都取消
        NSUInteger iCount = self.picForder.ocs.data.files.count;
        for (NSUInteger i = 0; i < iCount; i++) {
            PicForderOcsDataFiles * file = self.picForder.ocs.data.files[i];
            file.isSelected = false;
        }
        [bottomToolView setHidden:YES];
    }
    [self.tableView reloadData];
}

-(void)right2Action{
    
}

-(void)addFolderAction{
    NSLog(@"current dir = %@",self.currenPageDirPath);

    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"新建文件夹",@"新建文本文件", nil];
    [actionSheet setTag:2];
    [actionSheet showInView:self.view];
    actionSheet.delegate = self;
}

-(void)sortAction{
    UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:@"排序" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"按文件名称排序",@"按文件倒叙排序", nil];
    [actionSheet setTag:1];
    [actionSheet showInView:self.view];
    actionSheet.delegate = self;
}

#pragma mark - delegate <NHCustomSlideViewControllerDataSource, NHCustomSlideViewControllerDelegate >

- (NSInteger)numberOfChildViewControllersInSlideViewController:(NHCustomSlideViewController *)slideViewController {
    return self.titles.count;
}

- (UIViewController *)slideViewController:(NHCustomSlideViewController *)slideViewController viewControllerAtIndex:(NSInteger)index {
    return self.controllers[index];
}

- (void)customSlideViewController:(NHCustomSlideViewController *)slideViewController slideOffset:(CGPoint)slideOffset {
    self.optionalView.contentOffset = slideOffset;
}

- (void)customSlideViewController:(NHCustomSlideViewController *)slideViewController slideIndex:(NSInteger)slideIndex{
    self.nowIndex = slideIndex;
}

#pragma mark - delegate uitableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.picForder.ocs.data.files.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableViewCellHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    JCAllFilesCell * cell = [tableView dequeueReusableCellWithIdentifier:@"allFilesTableviewCell"];
    if (cell == nil) {
        cell = [[JCAllFilesCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"allFilesTableviewCell"];
    }
    if (isSelectStatus) {
        [cell changeFlagViewFrameShow];
    }else{
        [cell changeFlagViewFrameHidden];
    }
    //设置数据
    PicForderOcsDataFiles * files = self.picForder.ocs.data.files[indexPath.row];
    [cell setData:files];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //拿到这个文件或者文件夹名称
    self.files = self.picForder.ocs.data.files[indexPath.row];
 
    if (isSelectStatus) {
        //首先判断 当前的选中的file 的选中的状态
        //如果是选中状态  变成取消选中就好
        if (self.files.isSelected) {
            self.files.isSelected = !self.files.isSelected;
        }else{
            for (int i = 0 ; i < self.picForder.ocs.data.files.count; i ++) {
                PicForderOcsDataFiles * file1 = self.picForder.ocs.data.files[i];
                file1.isSelected = false;
            }
            self.files.isSelected = true;
        }

        //选中那个就改变 对应的model 重新刷新
//        files.isSelected = !files.isSelected;
        [self.tableView reloadData];
    }else{
        if ([self.files.type isEqualToString:@"file"]) {
            
        }else if([self.files.type isEqualToString:@"dir"]){
            NSString * path = self.files.name;
            NSString * nextPath = @"";
            if ([self.currenPageDirPath isEqualToString:@"/"]) {
                nextPath = [NSString stringWithFormat:@"/%@/",path];
            }else{
                nextPath = [NSString stringWithFormat:@"%@/%@/",self.currenPageDirPath,path];
            }
            JCAllFilesVC * allFile = [[JCAllFilesVC alloc] init];
            allFile.currenPageDirPath = nextPath;
            allFile.selectedStatus = self.selectedStatus;
            [self.navigationController pushViewController:allFile animated:YES];
        }
    }
}

#pragma mark - delegate UIActionSheetDelegate

-(void)actionSheetCancel:(UIActionSheet *)actionSheet{
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (actionSheet.tag == 2 ) {//新建
        switch (buttonIndex) {
            case 0:{
                NSLog(@"current dir = %@",self.currenPageDirPath);
                _folderView = [[UIAlertView alloc]initWithTitle:@"新建文件夹" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"保存", nil];
                _folderView.alertViewStyle = UIAlertViewStylePlainTextInput;
                [_folderView textFieldAtIndex:0].delegate = self;
                [[_folderView textFieldAtIndex:0] setAutocorrectionType:UITextAutocorrectionTypeNo];
                [[_folderView textFieldAtIndex:0] setAutocapitalizationType:UITextAutocapitalizationTypeNone];
                
                [_folderView show];
            }
                
                break;
                
            case 1://新建文本文件
                {
                    NSString *nowDir = [NSString stringWithFormat:@"%@/remote.php/webdav%@",serverIP,self.currenPageDirPath];
                    JCNewTextFile * newTextFile = [[JCNewTextFile alloc] init];
                    newTextFile.remoteUrl = nowDir;
                    [self.navigationController pushViewController:newTextFile animated:YES];
                }
                
                break;
                
            default:
                break;
        }
    }else if(actionSheet.tag == 1){//排序
        switch (buttonIndex) {
            case 0:
                //按照文件名称排序
                sort = @1;
                direction = @1;
                [self getPicFolder];
                break;
                
            case 1:
                //按照文件顺序排序
                sort = @3;
                direction = @1;
                [self getPicFolder];
                break;
                
            default:
                break;
        }
    }
    
}

#pragma mark - lazyload

- (NHHomeHeaderOptionalView *)optionalView {
    if (!_optionalView) {
        NHHomeHeaderOptionalView *optional = [[NHHomeHeaderOptionalView alloc] init];
        //目前项目需求 没有这个需求 先设置0高度 以后用得到的手 再放开
        optional.frame = CGRectMake(self.view.frame.origin.x, 0, kScreen_width, 40);
        [self.view addSubview:optional];
        _optionalView = optional;
        optional.backgroundColor = [UIColor whiteColor];
    }
    return _optionalView;
}

- (NSMutableArray *)controllers {
    if (!_controllers) {
        _controllers = [NSMutableArray array];
    }
    return _controllers;
}

- (NHCustomSlideViewController *)slideViewController {
    if (!_slideViewController) {
        NHCustomSlideViewController *slide = [[NHCustomSlideViewController alloc] init];
        [slide.view setBackgroundColor:[UIColor clearColor]];
        [slide willMoveToParentViewController:self];
        [self.view addSubview:slide.view];
        slide.view.frame = CGRectMake(0, 64, kScreen_width, kScreen_height - 64 - 49);
        slide.delgate = self;
        slide.dataSource = self;
        _slideViewController = slide;
    }
    return _slideViewController;
}

-(NSMutableArray *)waterFallPics{
    if (_waterFallPics == nil) {
        _waterFallPics = [[NSMutableArray alloc] init];
    }
    return _waterFallPics;
}

-(UIView *)titleView{
    if (_titleView == nil) {
        _titleView = [[UIView alloc]init];
        [_titleView setBackgroundColor:[UIColor whiteColor]];
        
    }
    return _titleView;
}



-(UIView *)folderActionBtnsView{
    if (_folderActionBtnsView == nil) {
        _folderActionBtnsView = [[UIView alloc]init];
        [_folderActionBtnsView setBackgroundColor:[UIColor whiteColor]];
//        [_folderActionBtnsView setHidden:YES];
    }
    return _folderActionBtnsView;
}

-(UIButton *)addFolder{
    if (_addFolder == nil) {
        _addFolder = [[UIButton alloc] init];
        [_addFolder setImage:[UIImage imageNamed:@"新建文件夹"] forState:UIControlStateNormal];
        [_addFolder addTarget:self action:@selector(addFolderAction) forControlEvents:UIControlEventTouchUpInside];
        [_addFolder setImageEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)];
//        [_addFolder setBackgroundColor:[UIColor greenColor]];
    }
    return _addFolder;
}

-(UIButton *)upload{
    if (_upload == nil) {
        _upload = [[UIButton alloc] init];
        [_upload setImage:[UIImage imageNamed:@"上传"] forState:UIControlStateNormal];
        [_upload addTarget:self action:@selector(upLoadAction) forControlEvents:UIControlEventTouchUpInside];
        [_upload setImageEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)];
//        [_upload setBackgroundColor:[UIColor greenColor]];
    }
    return _upload;
}

-(UIButton *)sort{
    if (_sort == nil) {
        _sort = [[UIButton alloc] init];
        [_sort setImage:[UIImage imageNamed:@"排序图标"] forState:UIControlStateNormal];
        [_sort addTarget:self action:@selector(sortAction) forControlEvents:UIControlEventTouchUpInside];
        [_sort setImageEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)];
//        [_sort setBackgroundColor:[UIColor greenColor]];
    }
    return _sort;
}

-(UIView *)aline{
    if (_aline == nil) {
        _aline = [[UIView alloc] init];
        [_aline setBackgroundColor:[Utils getColorWithOneValue:230]];
    }
    return _aline;
}

-(UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        [_tableView setBackgroundColor:[UIColor whiteColor]];
//        [_tableView setHidden:NO];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        [_tableView setSeparatorInset:UIEdgeInsetsMake(0, 10, 0, 10)];
    }
    return _tableView;
}

-(void)upLoadAction{
    //    if (self.albumController) {
    //        self.albumController = nil;
    //    }
    if (self.elcPicker) {
        self.elcPicker = nil;
    }
    
    //    self.albumController = [[ELCAlbumPickerController alloc] initWithNibName: nil bundle: nil];
    //    self.elcPicker = [[ELCImagePickerController alloc] initWithRootViewController:self.albumController];
    //    [self.albumController setParent: self.elcPicker];
    //    self.elcPicker.imagePickerDelegate = self;
    
    //Info of account and location path
    NSString * _currentRemoteFolder = [NSString stringWithFormat:@"%@/remote.php/webdav%@",serverIP,self.currenPageDirPath];
    NSArray *splitedUrl = [_currentRemoteFolder componentsSeparatedByString:@"/"];
    // int cont = [splitedUrl count];
    NSString *folder = [NSString stringWithFormat:@"%@",[splitedUrl objectAtIndex:([splitedUrl count]-2)]];
    
    //    NSLog(@"Folder selected to upload photos is:%@", folder);
    //    if (_fileIdToShowFiles.isRootFolder) {
    //        NSString *appName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
    //        folder=appName;
    //    }
    //
    //    self.albumController.currentRemoteFolder=_currentRemoteFolder;
    //    self.albumController.locationInfo=folder;
    
    // 第一次安装App，还未确定权限，调用这里
    if ([YFKit isPhotoAlbumNotDetermined])
    {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        {
            // 该API从iOS8.0开始支持
            // 系统弹出授权对话框
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied)
                    {
                        // 用户拒绝，跳转到自定义提示页面
                        [self showAlertController:@"提示" message:@"您已拒绝访问相册，可去设置隐私里开启"];
                    }
                    else if (status == PHAuthorizationStatusAuthorized)
                    {
                        // 用户授权，弹出相册对话框
                        //只撸出照片来
                        self.elcPicker = [[ELCImagePickerController alloc]initAllPicker:_currentRemoteFolder];
                        self.elcPicker.imagePickerDelegate = self;
                        [self presentViewController:self.elcPicker animated:YES completion:nil];
                    }
                });
            }];
        }
        else
        {
            // 以上requestAuthorization接口只支持8.0以上，如果App支持7.0及以下，就只能调用这里。
            //只撸出照片来
            self.elcPicker = [[ELCImagePickerController alloc]initAllPicker:_currentRemoteFolder];
            self.elcPicker.imagePickerDelegate = self;
            [self presentViewController:self.elcPicker animated:YES completion:nil];
        }
    }
    else if ([YFKit isPhotoAlbumDenied])
    {
        // 如果已经拒绝，则弹出对话框
        [self showAlertController:@"提示" message:@"拒绝访问相册，可去设置隐私里开启"];
    }
    else
    {
        // 已经授权，跳转到相册页面
        //只撸出照片来
        self.elcPicker = [[ELCImagePickerController alloc]initAllPicker:_currentRemoteFolder];
        self.elcPicker.imagePickerDelegate = self;
        [self presentViewController:self.elcPicker animated:YES completion:nil];
    }
}

- (void)showAlertController:(NSString *)title message:(NSString *)message
{
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - ELCImagePickerControllerDelegate Methods
/*
 * Method Delegate of the upload file selector to bring the selected files
 * @info -> array with the items
 * @remoteURLToUpload -> server path to upload selected files
 */
- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info inURL:(NSString*)remoteURLToUpload
{
    NSLog(@"相册回调：%@\n服务器地址：%@",info,remoteURLToUpload);
    //    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    //
    //    //这两步有JB卵用。。
    //    NSString *path = _nextRemoteFolder;
    //    path = [path stringByRemovingPercentEncoding];
    //
    //    if (!app.userSessionCurrentToken) {
    //        app.userSessionCurrentToken = [UtilsFramework getUserSessionToken];//生成唯一标识符
    //    }
    
    NSDictionary * args = [NSDictionary dictionaryWithObjectsAndKeys:
                           (NSArray *) info, @"info",
                           (NSString *) remoteURLToUpload, @"remoteURLToUpload", nil];//整合开线程所用参数
    [self performSelectorInBackground:@selector(initUploadFileFromGalleryInOtherThread:) withObject:args];
    
    //    app.isUploadViewVisible = NO;
    
}

//开线程，上传数据
- (void)initUploadFileFromGalleryInOtherThread:(NSDictionary *) args {
    //再次拆成俩参数。。。
    NSArray *info = [args objectForKey:@"info"];
    NSString *remoteURLToUpload = [args objectForKey:@"remoteURLToUpload"];
    
    if([info count]>0){
        
        AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //构造PrepareFilesToUpload对象
        if(app.prepareFiles == nil) {
            app.prepareFiles = [[PrepareFilesToUpload alloc] init];
            app.prepareFiles.listOfFilesToUpload = [[NSMutableArray alloc] init];
            app.prepareFiles.listOfAssetsToUpload = [[NSMutableArray alloc] init];
            app.prepareFiles.arrayOfRemoteurl = [[NSMutableArray alloc] init];
            app.prepareFiles.listOfUploadOfflineToGenerateSQL = [[NSMutableArray alloc] init];
        }
        app.prepareFiles.delegate = app;
        app.prepareFiles.counterUploadFiles = 0;
        //        app.uploadTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        //            // If you’re worried about exceeding 10 minutes, handle it here
        //            NSLog(@"上传请求超时，过了10分钟？！");
        //        }];
        
        NSMutableArray *arrayOfRemoteurl = [[NSMutableArray alloc] init];
        
        for (int i = 0 ; i < [info count] ; i++) {
            [arrayOfRemoteurl addObject:remoteURLToUpload];//同样地址存好几遍。。
        }
        
        [self performSelector:@selector(initPrepareFiles:andArrayOFfolders:) withObject:info withObject: arrayOfRemoteurl];
    }
}

//上传数据
- (void) initPrepareFiles:(NSArray *) info andArrayOFfolders: (NSMutableArray *)  arrayOfRemoteurl{
    
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.prepareFiles addAssetsToUploadFromArray:info andRemoteFoldersToUpload: arrayOfRemoteurl];
    
    //Init loading to prepare files to upload
    //    [self initLoading];
    
    //Set global loading screen global flag to YES (only for iPad)
    //    app.isLoadingVisible = YES;
}
#pragma mark - Create Folder

/*
 * This method create new folder in path
 * @name -> it is the name of the new folder
 */
-(void) newFolderSaveClicked:(NSString*)name {
    
    if (![FileNameUtils isForbiddenCharactersInFileName:name withForbiddenCharactersSupported:YES]) {
        
        //Check if exist a folder with the same name
        //        if ([self checkForSameName:name] == NO) {
        
        AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        //            [[AppDelegate sharedOCCommunication] setCredentials:app.activeUser.credDto];
        //
        //            [[AppDelegate sharedOCCommunication] setUserAgent:[UtilsUrls getUserAgent]];
        
        NSString *nowDir = [NSString stringWithFormat:@"%@/remote.php/webdav%@",serverIP,self.currenPageDirPath];
        NSString * newURL = [NSString stringWithFormat:@"%@/remote.php/webdav%@%@",serverIP,self.currenPageDirPath,[name encodeString:NSUTF8StringEncoding]];
        
        //            NSString *newURL = [NSString stringWithFormat:@"%@%@",self.currentRemoteFolder,[name encodeString:NSUTF8StringEncoding]];
        //            NSString *rootPath = [UtilsUrls getFilePathOnDBByFullPath:newURL andUser:app.activeUser];
        
        NSString *pathOfNewFolder = [NSString stringWithFormat:@"%@%@",[nowDir stringByRemovingPercentEncoding], name ];
        
        [[AppDelegate sharedOCCommunication] createFolder:pathOfNewFolder onCommunication:[AppDelegate sharedOCCommunication] withForbiddenCharactersSupported: YES successRequest:^(NSHTTPURLResponse *response, NSString *redirectedServer) {
            NSLog(@"Folder created");
            BOOL isSamlCredentialsError = NO;
            
            //Check the login error in shibboleth
            //                if (k_is_sso_active) {
            //                    //Check if there are fragmens of saml in url, in this case there are a credential error
            //                    isSamlCredentialsError = [FileNameUtils isURLWithSamlFragment:response];
            //                    if (isSamlCredentialsError) {
            //                        [self errorLogin];
            //                    }
            //                }
            if (!isSamlCredentialsError) {
                [self getPicFolder];
            }
        } failureRequest:^(NSHTTPURLResponse *response, NSError *error, NSString *redirectedServer) {
            NSLog(@"error: %@", error);
            NSLog(@"Operation error: %ld", (long)response.statusCode);
            
            BOOL isSamlCredentialsError = NO;
            
            //Check the login error in shibboleth
            //                if (k_is_sso_active) {
            //                    //Check if there are fragmens of saml in url, in this case there are a credential error
            //                    isSamlCredentialsError = [FileNameUtils isURLWithSamlFragment:response];
            //                    if (isSamlCredentialsError) {
            //                        [self errorLogin];
            //                    }
            //                }
            if (!isSamlCredentialsError) {
                //                    [self manageServerErrors:response.statusCode and:error];//先注掉
            }
            
        } errorBeforeRequest:^(NSError *error) {
            if (error.code == OCErrorForbiddenCharacters) {
                //                    [self endLoading];
                NSLog(@"The folder have problematic characters");
                
                NSString *msg = nil;
                msg = @"名字中存在至少一个非法字符。";
                
                _alert = [[UIAlertView alloc] initWithTitle:msg message:@"" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
                [_alert show];
            } else {
                //                    [self endLoading];
                NSLog(@"The folder have problems under controlled");
                _alert = [[UIAlertView alloc] initWithTitle:@"出错了。从服务器收到未知响应消息。" message:@"" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
                [_alert show];
            }
        }];
        //        }else {
        //            [self endLoading];
        //            NSLog(@"Exist a folder with the same name");
        //            _alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"folder_exist", nil) message:@"" delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", nil) otherButtonTitles:nil, nil];
        //            [_alert show];
        //        }
        
    }else{
        //        [self endLoading];
        //Forbidden characters found after the request.
        NSString *msg = nil;
        msg = @"名字中存在至少一个非法字符。";
        
        _alert = [[UIAlertView alloc] initWithTitle:msg message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [_alert show];
        
    }
}

#pragma mark - UIAlertView and UIAlertViewDelegate
- (void) alertView: (UIAlertView *) alertView willDismissWithButtonIndex: (NSInteger) buttonIndex
{
    // cancel
    if( buttonIndex == 1 ){
        //Save "Create Folder"
        
        NSString* result = [alertView textFieldAtIndex:0].text;
        [self performSelector:@selector(newFolderSaveClicked:) withObject:result];
        
    }else if (buttonIndex == 0) {
        //Cancel
        
    }else {
        //Nothing
    }
}


- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    BOOL output = YES;
    
    NSString *stringNow = [alertView textFieldAtIndex:0].text;
    
    
    //Active button of folderview only when the textfield has something.
    NSString *rawString = stringNow;
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    if ([trimmed length] == 0) {
        // Text was empty or only whitespace.
        output = NO;
    }
    
    //Button save disable when the textfield is empty
    if ([stringNow isEqualToString:@""]) {
        output = NO;
    }
    
    return output;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)dealloc{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"picListRightArrowAction" object:nil];
}

@end

//
//  JCNewTextFile.m
//  jcCloud
//
//  Created by sharingmobile on 2018/4/18.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCNewTextFile.h"
#import "UITextView+ZWPlaceHolder.h"
#import "FileNameUtils.h"
#import "UtilsFileSystem.h"
#import "AppDelegate.h"
#import "constants.h"
#import "JCDBManager.h"

@interface JCNewTextFile ()

@property(nonatomic,strong)UITextField * textTitle;
@property(nonatomic,strong)UITextView * content;

@end

@implementation JCNewTextFile

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.topItem.title = @"";
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.title = @"新文本文件";
    [self initView];
    
    
    
}

-(void)initView{
    [self.view addSubview:self.textTitle];
    [self.textTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).offset(10);
        make.right.mas_equalTo(self.view.mas_right).offset(-10);
        make.top.mas_equalTo(self.view.mas_top).offset(74);
        make.height.mas_equalTo(45);
    }];
    
    [self.view addSubview:self.content];
    [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).offset(10);
        make.top.mas_equalTo(self.textTitle.mas_bottom).offset(10);
        make.right.mas_equalTo(self.view.mas_right).offset(-10);
        make.bottom.mas_equalTo(self.view.mas_bottom);
    }];
    
    UIBarButtonItem * right1 = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStyleDone target:self action:@selector(didSelectDoneView)];

    self.navigationItem.rightBarButtonItem = right1;
}

#pragma mark - method

-(void)newTextFileOK{
    
}

-(UITextField *)textTitle{
    if (_textTitle == nil) {
        _textTitle = [[UITextField alloc] init];
        [_textTitle.layer setCornerRadius:5];
        _textTitle.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _textTitle.layer.borderWidth = 0.5;
        _textTitle.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
        _textTitle.leftViewMode = UITextFieldViewModeAlways;
        _textTitle.placeholder = @"标题";
        [_textTitle clipsToBounds];
//        [_textTitle setBackgroundColor:[UIColor greenColor]];
    }
    return _textTitle;
}

-(UITextView *)content{
    if (_content == nil) {
        _content = [[UITextView alloc] init];
        _content.zw_placeHolder = @"请输入文本内容";
        _content.font = [UIFont systemFontOfSize:16];
//        [_content setBackgroundColor:[UIColor greenColor]];
    }
    return _content;
}

#pragma mark - Action Methods

- (void) didSelectDoneView {
    NSString *fileName = @"";
    NSString *bodyTextFile = @"";
    
    if (self.isModeEditing) {
//        fileName = self.currentFileDto.fileName;
    } else {
        fileName = [self.textTitle.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet] ];//除两端的空格
    }
    bodyTextFile = self.content.text;
    
    fileName = [NSString stringWithFormat:@"%@.txt",fileName];
    
    if ( self.isModeEditing || (!self.isModeEditing && [self isValidTitleName:fileName])) {
        
//        if (![self.initialBodyContent isEqualToString:bodyTextFile] || ([bodyTextFile length] == 0)) {
            NSString *tempLocalPath = [self storeFileWithTitle:fileName andBody:bodyTextFile];
            if (tempLocalPath) {
                [self sendTextFileToUploadsByTempLocalPath:tempLocalPath andFileName:fileName];
            }
//        } else {
//            [self showAlertView:NSLocalizedString(@"no_changes_made", nil)];
//        }
        
        [self dismissViewControllerAnimated:NO completion:^{
            //Send notification in order to update the file list
//            [[NSNotificationCenter defaultCenter] postNotificationName:IPhoneDoneEditFileTextMessageNotification object:nil];
        }];
        
    }
    
}

#pragma mark - Check title name

//- (BOOL) existFileWithSameName:(NSString*)fileName {
//
//    BOOL sameName = NO;
//
//    self.currentDirectoryArray = [ManageFilesDB getFilesByFileIdForActiveUser:self.currentFileDto.idFile];
//
//    NSPredicate *predicateSameFileName = [NSPredicate predicateWithFormat:@"fileName == %@", [fileName encodeString:NSUTF8StringEncoding]];
//    NSString *folderSameName = [NSString stringWithFormat:@"%@/",[fileName encodeString:NSUTF8StringEncoding]];
//    NSPredicate *predicateSameFolderName = [NSPredicate predicateWithFormat:@"fileName == %@", folderSameName];
//
//    NSArray *filesSameFileName = [self.currentDirectoryArray filteredArrayUsingPredicate:predicateSameFileName];
//    NSArray *filesSameFolderName = [self.currentDirectoryArray filteredArrayUsingPredicate:predicateSameFolderName];
//
//
//    if ((filesSameFileName !=nil && filesSameFileName.count > 0) || (filesSameFolderName != nil && filesSameFolderName.count >0)) {
//        sameName = YES;
//    }
//
//
//    return sameName;
//}

- (BOOL) isValidTitleName:(NSString *)fileName {
    
    BOOL valid = NO;
    if (!([fileName length] == 0)) {
        if (![FileNameUtils isForbiddenCharactersInFileName:fileName withForbiddenCharactersSupported:YES]) {
            
//            if (![self existFileWithSameName:fileName]) {
                valid = YES;
//            } else {
//                NSLog(@"Exist a file with the same name");
//
//                [self showAlertView:[NSString stringWithFormat:@"%@ %@",fileName, @"已经存在"]];
//            }
        } else {
            [self showAlertView:@"名字中存在至少一个非法字符。"];
        }
    } else {
        [self showAlertView:@"文件名不能为空"];
    }
    
    return valid;
}


#pragma mark - store file

- (NSString *) storeFileWithTitle:(NSString *)fileName andBody:(NSString *)bodyTextFile {
    NSLog(@"New File with name: %@", fileName);
    
    NSString *tempPath = [UtilsFileSystem temporalFileNameByName:fileName];
    NSData* fileData = [bodyTextFile dataUsingEncoding:NSUTF8StringEncoding];
    [UtilsFileSystem createFileOnTheFileSystemByPath:tempPath andData:fileData];
    
    return tempPath;
}



#pragma mark - Upload text file

- (void) sendTextFileToUploadsByTempLocalPath:(NSString *)tempLocalPath andFileName:(NSString *)fileName {
    
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSString *fullRemotePath = @"";
    
//    if (self.isModeEditing) {
//        fullRemotePath = [NSString stringWithFormat:@"%@",[UtilsUrls getFullRemoteServerParentPathByFile:self.currentFileDto andUser:app.activeUser]];
//    } else {
//        fullRemotePath = [NSString stringWithFormat:@"%@",[UtilsUrls getFullRemoteServerFilePathByFile:self.currentFileDto andUser:app.activeUser]];
//    }
    
    long long fileLength = [[[[NSFileManager defaultManager] attributesOfItemAtPath:tempLocalPath error:nil] valueForKey:NSFileSize] unsignedLongLongValue];
    
//    if (![UtilsUrls isFileUploadingWithPath:fullRemotePath andUser:app.activeUser]) {
    
        UploadsOfflineDto *upload = [UploadsOfflineDto new];
        
        upload.originPath = tempLocalPath;
        upload.destinyFolder = self.remoteUrl;
        upload.uploadFileName = fileName;
        upload.kindOfError = notAnError;
        upload.estimateLength = (long)fileLength;
        upload.userId = 999;//回头补全
        upload.isLastUploadFileOfThisArray = YES;
        upload.chunksLength = k_lenght_chunk;
        upload.isNotNecessaryCheckIfExist = NO;
        upload.isInternalUpload = NO;
        upload.taskIdentifier = 0;
        
//        if (self.isModeEditing) {
//            upload.status = generatedByDocumentProvider;
//            [ManageFilesDB setFileIsDownloadState:self.currentFileDto.idFile andState:overwriting];
//            [ManageUploadsDB insertUpload:upload];
//            [app launchUploadsOfflineFromDocumentProvider];
//        } else {
            upload.status = pendingToBeCheck;
    JCDBManager *dbManager = [JCDBManager new];
    [dbManager insertUpload:upload];
            [app initUploadsOffline];
//        }
//    }
    
}

- (void) showAlertView:(NSString*)string{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:string message:@"" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alertView show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

@end

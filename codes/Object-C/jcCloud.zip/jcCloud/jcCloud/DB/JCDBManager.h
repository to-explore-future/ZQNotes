//
//  JCDBManager.h
//  jcCloud
//
//  Created by 万有友 on 2018/3/29.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDB/FMDB.h>
#import "UploadsOfflineDto.h"

@interface JCDBManager : NSObject

//数据库对象
@property(nonatomic,strong)FMDatabase *db;

//数据存储路径
@property(nonatomic,strong)NSString *dbPath;

//数据源
@property(nonatomic, strong)NSMutableArray *lists;

-(void) createDataBase;
-(void) insertManyUploadsOffline:(NSMutableArray *) listOfUploadOffline ;
-(UploadsOfflineDto *) getNextUploadOfflineFileToUpload;
-(void) setStatus:(NSInteger) status andKindOfError:(NSInteger) kindOfError byUploadOffline:(UploadsOfflineDto *) currentUpload;
-(void) cleanTableUploadsOfflineTheFinishedUploads;
- (NSMutableArray *) getUploads;
- (UploadsOfflineDto*)getUploadOfflineById:(NSInteger)uploadOfflineId;
- (void) setDatebyUploadOffline:(UploadsOfflineDto *)currentUpload;
-(void) insertUpload:(UploadsOfflineDto *) upload;
-(void) saveInUploadsOfflineTableTheFirst:(NSUInteger)uploads;
- (NSMutableArray *) getUploadsByStatus:(int) status andByKindOfError:(int) kindOfError;
- (void)updateAllErrorUploadOfflineWithWaitingAddUploadList;
- (void) updateErrorConflictFilesSetOverwrite:(BOOL) isNotNecessaryCheckIfExist forUploadOffline:(UploadsOfflineDto *) selectedUpload ;
@end

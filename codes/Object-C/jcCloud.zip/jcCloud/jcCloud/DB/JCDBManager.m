//
//  JCDBManager.m
//  jcCloud
//
//  Created by 万有友 on 2018/3/29.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCDBManager.h"
#import "UtilsUrls.h"

@implementation JCDBManager

-(void) createDataBase {
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL result = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS 'uploads_offline' ('id' INTEGER PRIMARY KEY, 'origin_path' VARCHAR, 'destiny_folder' VARCHAR, 'upload_filename' VARCHAR, 'estimate_length' LONG, 'user_id' INTEGER, 'is_last_upload_file_of_this_Array' BOOL, 'chunk_position' INTEGER, 'chunk_unique_number' INTEGER, 'chunks_length' LONG, 'status' INTEGER, 'uploaded_date' LONG, 'kind_of_error' INTEGER, 'is_internal_upload' BOOL, 'is_not_necessary_check_if_exist' BOOL, 'task_identifier' INTEGER);"];
        if (result) {
            NSLog(@"创建上传表成功");
        }else{
            NSLog(@"创建上传表失败");
        }
        
//        BOOL result2 = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS 'downloads_offline' ('id' INTEGER PRIMARY KEY, 'origin_path' VARCHAR, 'destiny_folder' VARCHAR, 'download_filename' VARCHAR, 'estimate_length' LONG, 'user_id' INTEGER, 'is_last_download_file_of_this_Array' BOOL, 'chunk_position' INTEGER, 'chunk_unique_number' INTEGER, 'chunks_length' LONG, 'status' INTEGER, 'downloaded_date' LONG, 'kind_of_error' INTEGER, 'is_internal_download' BOOL, 'is_not_necessary_check_if_exist' BOOL, 'task_identifier' INTEGER);"];
//        if (result2) {
//            NSLog(@"创建下载表成功");
//        }else{
//            NSLog(@"创建下载表失败");
//        }

    }
    self.db = db;
}

-(void) insertManyUploadsOffline:(NSMutableArray *) listOfUploadOffline {
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        
        for (int i = 0 ; i < [listOfUploadOffline count]; i++) {
            
            UploadsOfflineDto *current = [listOfUploadOffline objectAtIndex:i];
            
            correctQuery = [db executeUpdate:[NSString stringWithFormat:@"INSERT INTO uploads_offline SELECT null as id, '%@' as 'origin_path','%@' as 'destiny_folder', '%@' as 'upload_filename', %ld as 'estimate_length',%ld as 'user_id', %d as 'is_last_upload_file_of_this_Array', %ld as 'chunk_position', %ld as 'chunk_unique_number',%ld as 'chunks_length', %ld as 'status',%ld as 'uploaded_date', %ld as 'kind_of_error', %d as 'is_internal_upload', %d as 'is_not_necessary_check_if_exist', %ld as 'task_identifier'",
                                              current.originPath,
                                              current.destinyFolder,
                                              current.uploadFileName,
                                              current.estimateLength,
                                              (long)current.userId,
                                              current.isLastUploadFileOfThisArray,
                                              (long)current.chunkPosition,
                                              (long)current.chunkUniqueNumber,
                                              current.chunksLength,
                                              (long)current.status,
                                              current.uploadedDate,
                                              (long)current.kindOfError,
                                              current.isInternalUpload,
                                              current.isNotNecessaryCheckIfExist,
                                              (long)current.taskIdentifier]];
        }
        
        if (!correctQuery) {
           NSLog(@"Error in insertManyUploadsOffline");
        }

    }
    self.db = db;
}

-(UploadsOfflineDto *) getNextUploadOfflineFileToUpload {
    
    NSLog(@"getNextUploadOfflineFileToUpload");
    
    __block UploadsOfflineDto *output = nil;
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {

        FMResultSet *rs = [db executeQuery:@"SELECT id, origin_path, destiny_folder, upload_filename, estimate_length, user_id, is_last_upload_file_of_this_Array, chunk_position, chunk_unique_number, chunks_length, status, kind_of_error, is_internal_upload, is_not_necessary_check_if_exist, task_identifier FROM uploads_offline WHERE status = ? ORDER BY id ASC LIMIT 1", [NSNumber numberWithInt:waitingAddToUploadList]];
        
        while ([rs next]) {
            
            output = [UploadsOfflineDto new];
            
            output.idUploadsOffline = [rs intForColumn:@"id"];
            output.originPath = [rs stringForColumn:@"origin_path"];
            output.destinyFolder = [rs stringForColumn:@"destiny_folder"];
            output.uploadFileName = [rs stringForColumn:@"upload_filename"];
            output.estimateLength = [rs longForColumn:@"estimate_length"];
            output.userId = [rs intForColumn:@"user_id"];
            output.isLastUploadFileOfThisArray = [rs intForColumn:@"is_last_upload_file_of_this_Array"];
            output.chunkPosition = [rs intForColumn:@"chunk_position"];
            output.chunkUniqueNumber = [rs intForColumn:@"chunk_unique_number"];
            output.chunksLength = [rs longForColumn:@"chunks_length"];
            output.status = [rs intForColumn:@"status"];
            output.kindOfError = [rs intForColumn:@"kind_of_error"];
            output.isInternalUpload = [rs boolForColumn:@"is_internal_upload"];
            output.isNotNecessaryCheckIfExist = [rs boolForColumn:@"is_not_necessary_check_if_exist"];
            output.taskIdentifier = [rs intForColumn:@"task_identifier"];
        }
        
        [rs close];
        
    };
    
    return output;
    
}

//修改status上传状态
-(void) setStatus:(NSInteger) status andKindOfError:(NSInteger) kindOfError byUploadOffline:(UploadsOfflineDto *) currentUpload {
    
    NSLog(@"setStatus: %ld andKindOfError: %ld currentUpload: %@", (long)status, (long)kindOfError, currentUpload.uploadFileName);
    
    if (status == errorUploading) { //Refresh cell to remove uploading yellow arrow
        
#ifdef CONTAINER_APP
        AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        [app reloadCellByUploadOffline:currentUpload];
#endif
    }
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        correctQuery = [db executeUpdate:@"UPDATE uploads_offline SET status=?, kind_of_error = ? WHERE id = ?", [NSNumber numberWithInteger:status], [NSNumber numberWithInteger:kindOfError], [NSNumber numberWithInteger:currentUpload.idUploadsOffline]];
        
        if (!correctQuery) {
            NSLog(@"Error in setState");
        }
        
    }
}

/*
 * Method that delete al rows of uploads_offline table
 *
 */
-(void) cleanTableUploadsOfflineTheFinishedUploads {
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        correctQuery = [db executeUpdate:@"DELETE FROM uploads_offline WHERE status = ?",[NSNumber numberWithInt:uploaded]];
        
        if (!correctQuery) {
            NSLog(@"Error deleting uploads_offline table");
        }
    }
}

- (NSMutableArray *) getUploads {
    
    __block NSMutableArray *output = [NSMutableArray new];
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {

        FMResultSet *rs = [db executeQuery:@"SELECT id, origin_path, destiny_folder, upload_filename, estimate_length, user_id, is_last_upload_file_of_this_Array, chunk_position, chunk_unique_number, chunks_length, status, uploaded_date, kind_of_error, is_internal_upload, is_not_necessary_check_if_exist, task_identifier FROM uploads_offline ORDER BY id ASC"];
        
        while ([rs next]) {
            
            UploadsOfflineDto *current = [UploadsOfflineDto new];
            
            current.idUploadsOffline = [rs intForColumn:@"id"];
            current.originPath = [rs stringForColumn:@"origin_path"];
            current.destinyFolder = [rs stringForColumn:@"destiny_folder"];
            current.uploadFileName = [rs stringForColumn:@"upload_filename"];
            current.estimateLength = [rs longForColumn:@"estimate_length"];
            current.userId = [rs intForColumn:@"user_id"];
            current.isLastUploadFileOfThisArray = [rs intForColumn:@"is_last_upload_file_of_this_Array"];
            current.chunkPosition = [rs intForColumn:@"chunk_position"];
            current.chunkUniqueNumber = [rs intForColumn:@"chunk_unique_number"];
            current.chunksLength = [rs longForColumn:@"chunks_length"];
            current.status = [rs intForColumn:@"status"];
            current.uploadedDate = [rs longForColumn:@"uploaded_date"];
            current.kindOfError = [rs intForColumn:@"kind_of_error"];
            current.isInternalUpload = [rs boolForColumn:@"is_internal_upload"];
            current.isNotNecessaryCheckIfExist = [rs boolForColumn:@"is_not_necessary_check_if_exist"];
            current.taskIdentifier = [rs intForColumn:@"task_identifier"];
            
            [output addObject:current];
        }
        
        [rs close];
        
    };
    
    return output;
}

/*
 * Method that return a upload offline dto by id
 *  @uploadOfflineId -> id of upload offline
 */
- (UploadsOfflineDto*)getUploadOfflineById:(NSInteger)uploadOfflineId{
    
    NSLog(@"getUploadOfflineById: %ld", (long)uploadOfflineId);
    
    __block UploadsOfflineDto *output = nil;
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {

        FMResultSet *rs = [db executeQuery:@"SELECT id, origin_path, destiny_folder, upload_filename, estimate_length, user_id, is_last_upload_file_of_this_Array, chunk_position, chunk_unique_number, chunks_length, status, kind_of_error, is_internal_upload, is_not_necessary_check_if_exist, task_identifier, uploaded_date FROM uploads_offline WHERE id = ?", [NSNumber numberWithInteger:uploadOfflineId]];
        
        while ([rs next]) {
            
            output = [UploadsOfflineDto new];
            
            output.idUploadsOffline = [rs intForColumn:@"id"];
            output.originPath = [rs stringForColumn:@"origin_path"];
            output.destinyFolder = [rs stringForColumn:@"destiny_folder"];
            output.uploadFileName = [rs stringForColumn:@"upload_filename"];
            output.estimateLength = [rs longForColumn:@"estimate_length"];
            output.userId = [rs intForColumn:@"user_id"];
            output.isLastUploadFileOfThisArray = [rs intForColumn:@"is_last_upload_file_of_this_Array"];
            output.chunkPosition = [rs intForColumn:@"chunk_position"];
            output.chunkUniqueNumber = [rs intForColumn:@"chunk_unique_number"];
            output.chunksLength = [rs longForColumn:@"chunks_length"];
            output.status = [rs intForColumn:@"status"];
            output.kindOfError = [rs intForColumn:@"kind_of_error"];
            output.isInternalUpload = [rs boolForColumn:@"is_internal_upload"];
            output.isNotNecessaryCheckIfExist = [rs boolForColumn:@"is_not_necessary_check_if_exist"];
            output.taskIdentifier = [rs intForColumn:@"task_identifier"];
            output.uploadedDate = [rs longForColumn:@"uploaded_date"];
        }
        
        [rs close];
        
    };
    
    return output;
    
    
}

/*
 * This method set the date of finished upload
 * @currentUpload --> object updated
 */

- (void) setDatebyUploadOffline:(UploadsOfflineDto *)currentUpload{
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        
        correctQuery = [db executeUpdate:@"UPDATE uploads_offline SET uploaded_date=? WHERE id = ?", [NSNumber numberWithLong:currentUpload.uploadedDate], [NSNumber numberWithInteger:currentUpload.idUploadsOffline]];
        
        if (!correctQuery) {
            NSLog(@"Error in set date");
        }
        
    };
    
}

/*
 * Method that insert an upload object into uploads_offline table
 * @upload -> upload object
 */
-(void) insertUpload:(UploadsOfflineDto *) upload {
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        correctQuery = [db executeUpdate:@"INSERT INTO uploads_offline (origin_path, destiny_folder, upload_filename, estimate_length, user_id, is_last_upload_file_of_this_Array, chunk_position, chunk_unique_number, chunks_length, status,kind_of_error,is_internal_upload,is_not_necessary_check_if_exist, task_identifier) Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", upload.originPath,upload.destinyFolder,upload.uploadFileName, [NSNumber numberWithLong:upload.estimateLength], [NSNumber numberWithInteger:upload.userId], [NSNumber numberWithBool:upload.isLastUploadFileOfThisArray], [NSNumber numberWithInteger: upload.chunkPosition], [NSNumber numberWithInteger:upload.chunkUniqueNumber], [NSNumber numberWithLong:upload.chunksLength], [NSNumber numberWithInteger:upload.status], [NSNumber numberWithInteger:upload.kindOfError], [NSNumber numberWithBool:upload.isInternalUpload], [NSNumber numberWithBool:upload.isNotNecessaryCheckIfExist], [NSNumber numberWithInteger:upload.taskIdentifier]];
        
        if (!correctQuery) {
            NSLog(@"Error insert upload offline object");
        }
    };
}

/*
 * Method that save only one number the files in the uploads_offline table
 * @uploads -> The number of the first uploads to save
 */
-(void) saveInUploadsOfflineTableTheFirst:(NSUInteger)uploads{
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        correctQuery = [db executeUpdate:@"DELETE FROM uploads_offline WHERE status = ? AND id IN (SELECT id FROM uploads_offline WHERE id NOT IN (SELECT id FROM uploads_offline WHERE status = ? ORDER BY id DESC LIMIT ?))", [NSNumber numberWithInt:uploaded], [NSNumber numberWithInt:uploaded], [NSNumber numberWithInteger:uploads]];
        
        if (!correctQuery) {
            NSLog(@"Error deleting uploads_offline table");
        }
    };
    
    
    // DELETE CLIENTES
    //FROM (SELECT TOP 10 * FROM CLIENTES) AS t1
    //WHERE CLIENTE._id = t1.id
    
}

- (NSMutableArray *) getUploadsByStatus:(int) status andByKindOfError:(int) kindOfError {
    NSLog(@"getUploadsByStatus %d andByKindOfError: %d", status, kindOfError);
    
    __block NSMutableArray *output = [NSMutableArray new];
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {

        FMResultSet *rs = [db executeQuery:@"SELECT id, origin_path, destiny_folder, upload_filename, estimate_length, user_id, is_last_upload_file_of_this_Array, chunk_position, chunk_unique_number, chunks_length, status, uploaded_date , kind_of_error, is_internal_upload, is_not_necessary_check_if_exist, task_identifier FROM uploads_offline WHERE status = ? AND kind_of_error = ? ORDER BY id ASC", [NSNumber numberWithInt:status], [NSNumber numberWithInt:kindOfError]];
        
        while ([rs next]) {
            
            UploadsOfflineDto *current = [UploadsOfflineDto new];
            
            current.idUploadsOffline = [rs intForColumn:@"id"];
            current.originPath = [rs stringForColumn:@"origin_path"];
            current.destinyFolder = [rs stringForColumn:@"destiny_folder"];
            current.uploadFileName = [rs stringForColumn:@"upload_filename"];
            current.estimateLength = [rs longForColumn:@"estimate_length"];
            current.userId = [rs intForColumn:@"user_id"];
            current.isLastUploadFileOfThisArray = [rs intForColumn:@"is_last_upload_file_of_this_Array"];
            current.chunkPosition = [rs intForColumn:@"chunk_position"];
            current.chunkUniqueNumber = [rs intForColumn:@"chunk_unique_number"];
            current.chunksLength = [rs longForColumn:@"chunks_length"];
            current.status = [rs intForColumn:@"status"];
            current.uploadedDate = [rs intForColumn:@"uploaded_date"];
            current.kindOfError = [rs intForColumn:@"kind_of_error"];
            current.isInternalUpload = [rs boolForColumn:@"is_internal_upload"];
            current.isNotNecessaryCheckIfExist = [rs boolForColumn:@"is_not_necessary_check_if_exist"];
            current.taskIdentifier = [rs intForColumn:@"task_identifier"];
            
            
            [output addObject:current];
        }
        
        [rs close];
        
    };
    
    return output;
}

- (void)updateAllErrorUploadOfflineWithWaitingAddUploadList {
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        correctQuery = [db executeUpdate:@"UPDATE uploads_offline SET status=? WHERE status = ? AND kind_of_error = ?", [NSNumber numberWithInt:waitingAddToUploadList], [NSNumber numberWithInt:errorUploading], [NSNumber numberWithInt:notAnError]];
        
        if (!correctQuery) {
            NSLog(@"Error in setState");
        }
        
    };
}

/*
 * Method that update the file with conflict error that have been corrected by user set overwrite
 */
- (void) updateErrorConflictFilesSetOverwrite:(BOOL) isNotNecessaryCheckIfExist forUploadOffline:(UploadsOfflineDto *) selectedUpload {
    
    NSString *filepath =  [UtilsUrls.getOwnCloudFilePath stringByAppendingPathComponent:@"DB.sqlite"];
    self.dbPath = filepath;
    
    FMDatabase *db = [FMDatabase databaseWithPath:self.dbPath];
    //打开数据库
    if ([db open]) {
        BOOL correctQuery=NO;
        
        //We do not need set anything on the DB about overwrite only on the UploadOfflineDto
        correctQuery = [db executeUpdate:@"UPDATE uploads_offline SET kind_of_error=?, is_not_necessary_check_if_exist = ? WHERE id = ?", [NSNumber numberWithInteger:notAnError], [NSNumber numberWithBool:isNotNecessaryCheckIfExist], [NSNumber numberWithInteger:selectedUpload.idUploadsOffline]];
        
        if (!correctQuery) {
            NSLog(@"Error in setState");
        }
        
    };
}

@end

//
//  JCDownloadFileModel.m
//  jcCloud
//
//  Created by 万有友 on 2018/3/29.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCDownloadFileModel.h"

@implementation JCDownloadFileModel

@end

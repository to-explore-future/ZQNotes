//
//  JCDownloadFileModel.h
//  jcCloud
//
//  Created by 万有友 on 2018/3/29.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCDownloadFileModel : NSObject

@property NSInteger idDownloadsOffline;//id，唯一标识
@property (nonatomic, copy) NSString *originPath;//本地沙盒物理路径，含文件名及扩展名
@property (nonatomic, copy) NSString *destinyFolder;//服务器上要上传到的目的地远程地址
@property (nonatomic, copy) NSString *uploadFileName;//自定义好的文件名
@property long estimateLength;//文件二进制长度
@property NSInteger userId;//当前用户的id
@property BOOL isLastDownloadFileOfThisArray;
@property NSInteger chunkPosition;
@property NSInteger chunkUniqueNumber;
@property long chunksLength;
@property NSInteger status;
@property long downloadedDate;
@property NSInteger kindOfError;
@property BOOL isNotNecessaryCheckIfExist;
@property BOOL isInternalUpload;
@property NSInteger taskIdentifier;
@property(nonatomic, strong)NSString *identifier;

@end

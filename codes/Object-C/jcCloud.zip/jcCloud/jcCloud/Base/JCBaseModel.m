//
//  JCBaseModel.m
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCBaseModel.h"

@implementation JCBaseModel
- (instancetype)initWithJSONDict:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        if (![dict isKindOfClass:[NSNull class]]&&dict) {
            [self setValuesForKeysWithDictionary:dict];
        }
    }
    return self;
}

- (void)setValue:(id)value forKey:(NSString *)key {
    if ([key isEqualToString:@"description"]) {
        key = @"descriptionStr";
    } else if ([key isEqualToString:@"template"]) {
        key = @"templateStr";
    }
    else if([key isEqualToString:@"display-name"])
    {
        key=@"displayName";
    }
    [super setValue:value forKey:key];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
@end

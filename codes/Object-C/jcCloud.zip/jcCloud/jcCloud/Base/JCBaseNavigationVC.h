//
//  JCBaseNavigationVC.h
//  jcCloud
//
//  Created by 万有友 on 2018/4/2.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCBaseNavigationVC : UINavigationController

@end

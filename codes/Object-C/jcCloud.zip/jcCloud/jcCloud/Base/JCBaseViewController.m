//
//  JCBaseViewController.m
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCBaseViewController.h"
#import<CommonCrypto/CommonDigest.h>

@interface JCBaseViewController ()

@end

@implementation JCBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initNetWorking];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStyleDone target:nil action:nil];
    self.navigationItem.backBarButtonItem = backItem;
    [self.navigationController setNavigationBarHidden:NO];

}

-(void)initNetWorking{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end

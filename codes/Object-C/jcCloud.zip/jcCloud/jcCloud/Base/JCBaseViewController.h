//
//  JCBaseViewController.h
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTTPRequest.h"
#import "UIViewController+DDRequest.h"
#import "UIViewController+DDShowHUD.h"
#import "UIDefine.h"
@interface JCBaseViewController : UIViewController

@end

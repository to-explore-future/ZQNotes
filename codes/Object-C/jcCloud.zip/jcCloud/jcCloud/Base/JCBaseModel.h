//
//  JCBaseModel.h
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCBaseModel : NSObject
- (instancetype)initWithJSONDict:(NSDictionary *)dict;
@end

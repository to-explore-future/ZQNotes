//
//  DDLoginRegisterProtocol.h
//  dida
//
//  Created by dida on 15/7/21.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JCLoginRegisterProtocol <NSObject>

- (void)goLoginVC;
/** 登录失效处理 */
- (void)loginFailForRequest;

@end

//
//  FileTool.h
//  StockEmotion
//
//  Created by dida on 15/11/28.
//  Copyright © 2015年 StockEmotion. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "DDTDataTotalModel.h"
#define DocuentmentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]











//用户信息缓存
#define UserInfoPath @"userInfo"

#define LastChongZhiPhone @"lastchongzhiphone"


//用户页面停留时间缓存
#define UserRemainPath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]stringByAppendingPathComponent:@"UserRemainList.plist"]

//用户点击事件缓存
#define UserClickPath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]stringByAppendingPathComponent:@"UserClickList.plist"]



//首页数据缓存
#define HomeDataPath [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]stringByAppendingPathComponent:@"HomeData.plist"]

@interface FileTool : NSObject
+(void)saveDataToUserDomainMaskWithFileName:(NSString *)fileName andArray:(NSArray *)dataArray;
+(void)saveDataToUserDomainMaskWithFileName:(NSString *)fileName andDic:(NSDictionary *)dataDic;
+(void)saveDataFromUserDefault:(id)data withKey:(NSString *)key;


+(NSArray *)getDataArrayFromUserDomainMask:(NSString *)path;
+(NSDictionary *)getDataDicFromUserDomainMask:(NSString *)path;
+(void)deleteHistoryDataFromUserDomainMask:(NSString *)path;
+(id)getDataFromUserDefaultWithKey:(NSString *)key;


+(BOOL)isExitFromPath:(NSString *)pathStr;
@end

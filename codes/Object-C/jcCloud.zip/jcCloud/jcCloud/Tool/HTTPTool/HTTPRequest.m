//
//  HTTPRequest.m
//  worde
//
//  Created by dida on 15/11/11.
//  Copyright © 2015年 wordemotion. All rights reserved.
//

#import "HTTPRequest.h"
#import "AccountManager.h"
//#import "AppConfig.h"
#import "FileTool.h"
#import "JNKeychain.h"
#import "AppDelegate.h"
//#import "DDTDataStatisItemModel.h"
//#define VisitorCellPhone @"00000000000"


@interface HTTPRequest()

@end
@implementation HTTPRequest


+ (AFHTTPSessionManager *)getManager{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    AFSecurityPolicy *policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    policy.allowInvalidCertificates = YES;
    manager.securityPolicy = policy;
    
    [manager.requestSerializer setValue:[AccountManager shareAccount].userAgent forHTTPHeaderField:@"User-Agent"];
    [manager.requestSerializer setValue:[AccountManager shareAccount].token forHTTPHeaderField:@"Authorization"];
    [manager.requestSerializer setValue:@"true" forHTTPHeaderField:@"OCS-APIREQUEST"];
    
     NSLog(@"%@,%@",[AccountManager shareAccount].userAgent,[AccountManager shareAccount].token);
    return manager;
}

//GET
+ (NSURLSessionDataTask *)getRequestWithUrl:(NSString*)urlString params:(NSDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    AFHTTPSessionManager *manager = [self getManager];
    urlString=[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
   
    NSLog(@"\n\nrequest start url--->\n%@\n\n", urlString);
    return [manager GET:urlString parameters:params progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        
        if ([responseObject isKindOfClass:[NSData class]]) {
            NSLog(@"\n\nrequest end url--->\n%@\nJSON--->\n%@\n\n", urlString, dict);
            if (success) {
                success(dict);
            }
        } else {
            NSLog(@"\n\nrequest fail url--->\n%@\nerror JSON--->\n%@\n\n", urlString, dict);
            if (fail) {
                fail(@"");
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n\nrequest error url--->\n%@\nerror--->\n%@\n\n", urlString, error);
        NSString *errMsg=@"";
        if(error.userInfo){
            NSString * s = error.userInfo[@"NSLocalizedDescription"];
            if(s.length > 5){
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(401)"]){
                    errMsg = @"权限错误,请重新登录";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(400)"] ||
                   [[s substringFromIndex:s.length - 5] isEqualToString:@"(500)"]){
                    errMsg = @"服务器错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            if(s.length > 0){
                if ([s isEqualToString:@"已取消"]) {
                    errMsg = @"已取消";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            NSData *errData=error.userInfo[@"com.alamofire.serialization.response.error.data"];
            if (errData) {
                NSDictionary *errDic=[NSJSONSerialization JSONObjectWithData:errData options:NSJSONReadingAllowFragments error:nil];;
                errMsg=errDic[@"errorMessage"];
            }
            
        }
        if (fail) {
            fail(errMsg);
        }
    }];
}


+ (NSURLSessionDataTask *)deleteRequestWithUrl:(NSString*)urlString params:(NSDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    AFHTTPSessionManager *manager = [self getManager];
    urlString=[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"\n\nrequest start url--->\n%@\n\n", urlString);
    return [manager DELETE:urlString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        if ([responseObject isKindOfClass:[NSData class]]) {
            NSLog(@"\n\nrequest end url--->\n%@\nJSON--->\n%@\n\n", urlString, dict);
            if (success) {
                success(dict);
            }
        } else {
            NSLog(@"\n\nrequest fail url--->\n%@\nerror JSON--->\n%@\n\n", urlString, dict);
            if (fail) {
                fail(@"");
            }
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n\nrequest error url--->\n%@\nerror--->\n%@\n\n", urlString, error);
        NSString *errMsg=@"";
        if(error.userInfo){
            NSString * s = error.userInfo[@"NSLocalizedDescription"];
            if(s.length > 5){
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(401)"]){
                    errMsg = @"权限错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(400)"] ||
                   [[s substringFromIndex:s.length - 5] isEqualToString:@"(500)"]){
                    errMsg = @"服务器错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            if(s.length > 0){
                if ([s isEqualToString:@"已取消"]) {
                    errMsg = @"已取消";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            NSData *errData=error.userInfo[@"com.alamofire.serialization.response.error.data"];
            if (errData) {
                NSDictionary *errDic=[NSJSONSerialization JSONObjectWithData:errData options:NSJSONReadingAllowFragments error:nil];;
                errMsg=errDic[@"errorMessage"];
            }
            
        }
        if (fail) {
            fail(errMsg);
        }
    }];
    
    
    
    
}

//POST
+ (NSURLSessionDataTask *)postRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    AFHTTPSessionManager *manager = [self getManager];
    if (params == nil) {
        params = [NSMutableDictionary dictionary];
    }
    NSLog(@"\n\nrequest start url--->\n%@\nparams--->\n%@\n\n", urlString, params);
    return [manager POST:urlString parameters:params progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        if ([responseObject isKindOfClass:[NSData class]]) {
            NSLog(@"\n\nrequest end url-    -->\n%@\nJSON--->\n%@\n\n", urlString, dict);
            if (success) {
                success(dict);
            }
        } else {
            NSLog(@"\n\nrequest fail url--->\n%@\nerror JSON--->\n%@\n\n", urlString, dict);
            if (fail) {
                fail(@"服务器出错");
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n\nrequest error url--->\n%@\nerror--->\n%@\n\n", urlString, error);
        NSString *errMsg=@"";
        if(error.userInfo){
            NSString * s = error.userInfo[@"NSLocalizedDescription"];
            if(s.length > 5){
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(401)"]){
                    errMsg = @"权限错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(400)"] ||
                   [[s substringFromIndex:s.length - 5] isEqualToString:@"(500)"]){
                    errMsg = @"服务器错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            if(s.length > 0){
                if ([s isEqualToString:@"已取消"]) {
                    errMsg = @"已取消";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            NSData *errData=error.userInfo[@"com.alamofire.serialization.response.error.data"];
            if (errData) {
                NSDictionary *errDic=[NSJSONSerialization JSONObjectWithData:errData options:NSJSONReadingAllowFragments error:nil];;
                errMsg=errDic[@"errorMessage"];
            }
            
        }
        if (fail) {
            fail(errMsg);
        }
    }];
}
//put
+ (NSURLSessionDataTask *)putRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    AFHTTPSessionManager *manager = [self getManager];
    urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"\n\nrequest start url--->\n%@\nparams--->\n%@\n\n", urlString, params);
    return [manager PUT:urlString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        if ([responseObject isKindOfClass:[NSData class]]) {
            NSLog(@"\n\nrequest end url-    -->\n%@\nJSON--->\n%@\n\n", urlString, dict);
            if (success) {
                success(dict);
            }
        } else {
            NSLog(@"\n\nrequest fail url--->\n%@\nerror JSON--->\n%@\n\n", urlString, dict);
            if (fail) {
                fail(@"");
            }
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n\nrequest error url--->\n%@\nerror--->\n%@\n\n", urlString, error);
        NSString *errMsg=@"";
        if(error.userInfo){
            NSString * s = error.userInfo[@"NSLocalizedDescription"];
            if(s.length > 5){
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(401)"]){
                    errMsg = @"权限错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(400)"] ||
                   [[s substringFromIndex:s.length - 5] isEqualToString:@"(500)"]){
                    errMsg = @"服务器错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            if(s.length > 0){
                if ([s isEqualToString:@"已取消"]) {
                    errMsg = @"已取消";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            NSData *errData=error.userInfo[@"com.alamofire.serialization.response.error.data"];
            if (errData) {
                NSDictionary *errDic=[NSJSONSerialization JSONObjectWithData:errData options:NSJSONReadingAllowFragments error:nil];;
                errMsg=errDic[@"errorMessage"];
            }
        }
        if (fail) {
            fail(errMsg);
        }
    }];
}


//POST
+ (NSURLSessionDataTask *)postRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params WithfileDic:(NSDictionary *)fileDic success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    AFHTTPSessionManager *manager = [self getManager];
    urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"\n\nrequest start url--->\n%@\nparams--->\n%@\n\n", urlString, params);
    if (params == nil) {
        params = [NSMutableDictionary dictionary];
    }
    return [manager POST:urlString parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if ([fileDic count] > 0) {
            for (NSString *key in [fileDic allKeys]) {
                [formData appendPartWithFileData:fileDic[key] name:key fileName:[key stringByAppendingString:@".jpg"] mimeType:NSFileType];
            }
        }
        NSLog(@"%@",formData);
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        if ([responseObject isKindOfClass:[NSData class]]) {
            NSLog(@"\n\nrequest end url-    -->\n%@\nJSON--->\n%@\n\n", urlString, dict);
            if (success) {
                success(dict);
            }
        } else {
            
            NSLog(@"\n\nrequest fail url--->\n%@\nerror JSON--->\n%@\n\n", urlString, dict);
            if (fail) {
                fail(@"");
            }
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n\nrequest error url--->\n%@\nerror--->\n%@\n\n", urlString, error);
        NSString *errMsg=@"";
        if(error.userInfo){
            NSString * s = error.userInfo[@"NSLocalizedDescription"];
            if(s.length > 5){
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(401)"]){
                    errMsg = @"权限错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
                if([[s substringFromIndex:s.length - 5] isEqualToString:@"(400)"] ||
                   [[s substringFromIndex:s.length - 5] isEqualToString:@"(500)"]){
                    errMsg = @"服务器错误";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            if(s.length > 0){
                if ([s isEqualToString:@"已取消"]) {
                    errMsg = @"已取消";
                    if (fail) {
                        fail(errMsg);
                    }
                    return;
                }
            }
            NSData *errData=error.userInfo[@"com.alamofire.serialization.response.error.data"];
            if (errData) {
                NSDictionary *errDic=[NSJSONSerialization JSONObjectWithData:errData options:NSJSONReadingAllowFragments error:nil];;
                errMsg=errDic[@"errorMessage"];
            }
            
        }
        if (fail) {
            fail(errMsg);
        }
    }];
}




//+(void)postStringRequest
//{
//    AFHTTPSessionManager *manager = [self getManager];
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
//    manager.responseSerializer = [AFJSONResponseSerializer serializer];
//    NSString *orginStr=@"=p_act%3Dupdata%26p_append%3D%26p_cid%3D1030%26p_game_id%3D70%26p_imei%3D869834026202020p_phoneinfo%3Dvivo%2BX6Plus%2BD_vivo%26p_phonenumber%3D%26p_sdk_ver%3D4_9_7_13%26p_sid%3D0%26p_time%3D1496801361830%26p_version_number%3D1%26sign%3D05c6b387eca75cfb420fa9c2bb08e6ae";
//    NSLog(@"%@",[orginStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]);
//   
//    //
//    manager.requestSerializer=[AFHTTPRequestSerializer serializer];
//    NSString *BOdyStr=@"p_act=updata&p_append=&p_cid=1030&p_game_id=70&p_imei=869834026202020p_phoneinfo=vivo+X6Plus+D_vivo&p_phonenumber=&p_sdk_ver=4_9_7_13&p_sid=0&p_time=1496801361830&p_version_number=1&sign=05c6b387eca75cfb420fa9c2bb08e6ae";
//    NSLog(@"%@",BOdyStr);
//    [manager POST:@"https://sdkapi.mobile.x1616.com:8000/v8.html" parameters:orginStr progress:^(NSProgress * _Nonnull uploadProgress) {
//        
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        NSLog(@"%@",error);
//    }];
//    
//}
@end

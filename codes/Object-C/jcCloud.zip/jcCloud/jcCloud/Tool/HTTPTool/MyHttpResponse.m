//
//  MyHttpResponse.m
//  DKNetworkingExample
//
//  Created by 庄槟豪 on 2017/3/23.
//  Copyright © 2017年 cn.dankal. All rights reserved.
//

#import "MyHttpResponse.h"

@implementation MyHttpResponse

@end

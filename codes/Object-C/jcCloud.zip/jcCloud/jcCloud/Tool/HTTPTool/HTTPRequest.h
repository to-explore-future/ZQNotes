//
//  HTTPRequest.h
//  worde
//
//  Created by dida on 15/11/11.
//  Copyright © 2015年 wordemotion. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <AFNetworking.h>

#import "APIDefine.h"

@interface HTTPRequest : NSObject

typedef void (^HttpRequestSuccessBlock)(NSDictionary *responseDict);
typedef void (^HttpRequestFailureBlock)(NSString *errorMsg);

//GET
+ (NSURLSessionDataTask *)getRequestWithUrl:(NSString*)urlString params:(NSDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//POST
+ (NSURLSessionDataTask *)postRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//POST文件
+ (NSURLSessionDataTask *)postRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params WithfileDic:(NSDictionary *)fileDic success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail ;
//PUT
+ (NSURLSessionDataTask *)putRequestWithUrl:(NSString*)urlString params:(NSMutableDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;

//DELETE
+ (NSURLSessionDataTask *)deleteRequestWithUrl:(NSString*)urlString params:(NSDictionary *)params success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;

+(void)postDataStatisWithArr:(NSArray *)dataArr withGameId:(NSNumber *)gameId success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//+(void)postStringRequest;
@end

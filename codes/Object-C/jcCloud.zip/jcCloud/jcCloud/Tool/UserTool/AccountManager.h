//
//  AccountManager.h
//  StockEmotion
//
//  Created by dida on 15/11/19.
//  Copyright © 2015年 StockEmotion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HTTPRequest.h"
#import "UserInfo.h"

typedef void(^finishBlock)(void);
@interface AccountManager : NSObject

//用户信息
@property (nonatomic, strong) UserInfo *userInfo;
//登录状态
@property (nonatomic, assign)BOOL isLogin;
//是否新版本
@property (nonatomic, assign)BOOL isNeedWelPage;
//token
@property (nonatomic, strong) NSString *token;
//是否首次登录
//@property (nonatomic,assign) BOOL isFirstLogin;
@property (nonatomic,copy)NSString *userAgent;

+ (AccountManager *)shareAccount;
+(BOOL)isNeedWelcomeVC;
+(void)skipCurrentWelcomeVC;
//手机登录
+ (void)loginWithPhone:(NSString *)phone password:(NSString *)password success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//自动登陆
+ (void)autoLoginSuccess:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//是否自动登录
+(BOOL)isAutoLogin;
//登出
+ (void)loginOutsuccess:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;
//清空登录状态
+ (void)outAutoLoginAccount;
//保存版本号
+ (void)saveAppVersion;

//获取用户信息
+(void)getUserInfoWithSuc:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail;

////返回设备具体型号
+ (NSString *)deviceString;
+ (BOOL)validateMobile:(NSString *)mobile;

+(NSString *)getAutoLoginPhoneNumber;
+(NSString *)getAutoLoginPassword;


+(void)saveGuideImage;
+(BOOL)showGuideImage;


+ (NSString *) AFBase64EncodedStringFromString:(NSString *) string;


@end

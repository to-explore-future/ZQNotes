//
//  UserInfo.h
//  StockEmotion
//
//  Created by dida on 15/11/18.
//  Copyright © 2015年 StockEmotion. All rights reserved.
//

#import "JCBaseModel.h"
@interface UserInfo : JCBaseModel
@property (nonatomic,copy)NSString *displayName;
@property (nonatomic,copy)NSString *email;
@property (nonatomic,copy)NSString *id;


@end
//ocs =     {
//    data =         {
//        "display-name" = test;
//        email = "<null>";
//        id = test;
//    };
//    meta =         {
//        itemsperpage = "";
//        message = OK;
//        status = ok;
//        statuscode = 100;
//        totalitems = "";
//    };
//};


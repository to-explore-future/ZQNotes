//
//  AccountManager.m
//  StockEmotion
//
//  Created by dida on 15/11/19.
//  Copyright © 2015年 StockEmotion. All rights reserved.
//

#import "AccountManager.h"
#import "HTTPRequest.h"
#import "JNKeychain.h"
#import "AppConfig.h"
#import "FileTool.h"
//#import "NSString+MD5.h"
//#import "sys/utsname.h"
//#import "NSString+SHA1.h"
#define MaxContact 100
#define Key_AutoLoginAccount        @"HxlqJstj_AutoLoginAccount"
#define Key_LastVersion             @"HxlqJstj_LastVersion"
#define Key_LoginToken              @"HxlqJstj_LoginToken"

#define Key_WelcomeVersion          @"HxlqJstj_WelcomePageVersion"

#define Key_GuideImage              @"HxlqJstj_GuideImage"

@interface AccountManager()
{
    UserInfo *_userInfo;
}
@end

@implementation AccountManager

static AccountManager *account = NULL;
+(BOOL)isNeedWelcomeVC{
    NSString *lastVersion = [JNKeychain loadValueForKey:Key_WelcomeVersion];
    NSString *currentVersion = [AppConfig appVersion];
    NSLog(@"isNeedWelcomeVC--lastVersion->%@--currentVersion-->%@", lastVersion, currentVersion);
    
    return ![currentVersion isEqualToString:lastVersion];
}

+(void)skipCurrentWelcomeVC{
    NSString *currentVersion = [AppConfig appVersion];
    BOOL isSave = [JNKeychain saveValue:currentVersion forKey:Key_WelcomeVersion];
    NSLog(@"skipCurrentWelcomeVC--->%d", isSave);
}
+ (AccountManager *)shareAccount {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        account = [[AccountManager alloc] init];
        account.token=@"";
    });
    return account;
}

+ (void)loginWithPhone:(NSString *)phone password:(NSString *)password success:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    NSString *basicAuthCredentials = [NSString stringWithFormat:@"%@:%@", phone, password];
    [AccountManager shareAccount].token=[NSString stringWithFormat:@"Basic %@", [AccountManager AFBase64EncodedStringFromString: basicAuthCredentials]];
    
    [HTTPRequest getRequestWithUrl:API_Login params:nil success:^(NSDictionary *responseDict) {
        NSDictionary *dataDic=responseDict[@"ocs"][@"data"];
        [self saveAutoLoginAccount:phone password:password];
        [AccountManager shareAccount].userInfo=[[UserInfo alloc]initWithJSONDict:dataDic];
        success(responseDict);
    } fail:^(NSString *errorMsg) {
        [self outAutoLoginAccount];
        if (fail) {
            fail(errorMsg);
        }
    }];
}

+ (void)autoLoginSuccess:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail {
    NSDictionary *dict = [JNKeychain loadValueForKey:Key_AutoLoginAccount];
    if ([dict[@"phoneNumber"] length] <= 0 || dict[@"password"] <= 0) {
        [self outAutoLoginAccount];
        fail(nil);
        return;
    }
    [self loginWithPhone:dict[@"phoneNumber"] password:dict[@"password"] success:success fail:fail];
}

+(void)outAutoLoginAccount
{
    [AccountManager shareAccount].userInfo=nil;
    NSDictionary *dic=[JNKeychain loadValueForKey:Key_AutoLoginAccount];
    if (dic) {
        NSDictionary* lastLogin = @{@"phoneNumber":dic[@"phoneNumber"], @"isAutoLogin":@0};
        [JNKeychain saveValue:lastLogin forKey:Key_AutoLoginAccount];
    }
}
+(void)saveAutoLoginAccount:(NSString*)phoneNumber password:(NSString*)password {
    phoneNumber = [phoneNumber stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    password = [password stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if([phoneNumber length] <= 0 || [password length] <= 0){
        NSLog(@"saveAutoLoginAccount--error-->%@", phoneNumber);
        return;
    }
    NSDictionary* lastLogin = @{@"phoneNumber":phoneNumber,@"password":password, @"isAutoLogin":@YES};
    [JNKeychain saveValue:lastLogin forKey:Key_AutoLoginAccount];
}
+(void)loginOutsuccess:(HttpRequestSuccessBlock)success fail:(HttpRequestFailureBlock)fail
{
    [self outAutoLoginAccount];
    if (success) {
        success(nil);
    }
    
    [HTTPRequest postRequestWithUrl:API_Logout params:nil success:^(NSDictionary *responseDict) {
        
    } fail:^(NSString *errorMsg) {
        
    }];
}

+(BOOL)isAutoLogin {
    NSDictionary *dict = [JNKeychain loadValueForKey:Key_AutoLoginAccount];
    NSLog(@"isAutoLogin--Key_AutoLoginAccount----->%@", dict);
    return [dict[@"isAutoLogin"] boolValue];
}
//返回设备具体型号
//+ (NSString *)deviceString
//{
//    //导入 #import "sys/utsname.h" ;
//
//    struct utsname systemInfo;
//    uname(&systemInfo);
//    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
//
//    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G (A1203)";
//    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G (A1241/A1324)";
//    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS (A1303/A1325)";
//    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4 (A1332)";
//    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4 (A1332)";
//    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4 (A1349)";
//    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S (A1387/A1431)";
//    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5 (A1428)";
//    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5 (A1429/A1442)";
//    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5C (A1456/A1532)";
//    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5C (A1507/A1516/A1526/A1529)";
//    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5S (A1453/A1533)";
//    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5S (A1457/A1518/A1528/A1530)";
//    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6 (A1549/A1586)";
//    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus (A1522/A1524)";
//    if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6S (A1688/A1700)";
//    if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6S Plus (A1687/A1699)";
//
//    if ([platform isEqualToString:@"iPod1,1"])   return @"iPod Touch 1G (A1213)";
//    if ([platform isEqualToString:@"iPod2,1"])   return @"iPod Touch 2G (A1288)";
//    if ([platform isEqualToString:@"iPod3,1"])   return @"iPod Touch 3G (A1318)";
//    if ([platform isEqualToString:@"iPod4,1"])   return @"iPod Touch 4G (A1367)";
//    if ([platform isEqualToString:@"iPod5,1"])   return @"iPod Touch 5G (A1421/A1509)";
//
//    if ([platform isEqualToString:@"iPad1,1"])   return @"iPad 1G (A1219/A1337)";
//    if ([platform isEqualToString:@"iPad2,1"])   return @"iPad 2 (A1395)";
//    if ([platform isEqualToString:@"iPad2,2"])   return @"iPad 2 (A1396)";
//    if ([platform isEqualToString:@"iPad2,3"])   return @"iPad 2 (A1397)";
//    if ([platform isEqualToString:@"iPad2,4"])   return @"iPad 2 (A1395+New Chip)";
//    if ([platform isEqualToString:@"iPad2,5"])   return @"iPad Mini 1G (A1432)";
//    if ([platform isEqualToString:@"iPad2,6"])   return @"iPad Mini 1G (A1454)";
//    if ([platform isEqualToString:@"iPad2,7"])   return @"iPad Mini 1G (A1455)";
//
//    if ([platform isEqualToString:@"iPad3,1"])   return @"iPad 3 (A1416)";
//    if ([platform isEqualToString:@"iPad3,2"])   return @"iPad 3 (A1403)";
//    if ([platform isEqualToString:@"iPad3,3"])   return @"iPad 3 (A1430)";
//    if ([platform isEqualToString:@"iPad3,4"])   return @"iPad 4 (A1458)";
//    if ([platform isEqualToString:@"iPad3,5"])   return @"iPad 4 (A1459)";
//    if ([platform isEqualToString:@"iPad3,6"])   return @"iPad 4 (A1460)";
//
//    if ([platform isEqualToString:@"iPad4,1"])   return @"iPad Air (A1474)";
//    if ([platform isEqualToString:@"iPad4,2"])   return @"iPad Air (A1475)";
//    if ([platform isEqualToString:@"iPad4,3"])   return @"iPad Air (A1476)";
//    if ([platform isEqualToString:@"iPad4,4"])   return @"iPad Mini 2G (A1489)";
//    if ([platform isEqualToString:@"iPad4,5"])   return @"iPad Mini 2G (A1490)";
//    if ([platform isEqualToString:@"iPad4,6"])   return @"iPad Mini 2G (A1491)";
//
//    if ([platform isEqualToString:@"i386"])      return @"iPhone Simulator";
//    if ([platform isEqualToString:@"x86_64"])    return @"iPhone Simulator";
//
//    NSLog(@"NOTE: Unknown device type: %@", platform);
//    return platform;
//}


+(void)saveAppVersion
{
    [JNKeychain saveValue:[AppConfig appVersion] forKey:Key_LastVersion];
}


-(NSString *)cellPhone
{
    NSDictionary *dic=[JNKeychain loadValueForKey:Key_AutoLoginAccount];
    return [dic objectForKey:@"phoneNumber"];
}
-(BOOL)isLogin
{
    NSDictionary *dic=[JNKeychain loadValueForKey:Key_AutoLoginAccount];
    NSNumber *islogin=[dic objectForKey:@"isAutoLogin"];
    
    return islogin.intValue>0?YES:NO;
}
-(BOOL)isNeedWelPage
{
    NSString *lastVersion=[JNKeychain loadValueForKey:Key_LastVersion];
    NSString *currentVersion=[AppConfig appVersion];
    return ![lastVersion isEqualToString:currentVersion];
}
-(UserInfo *)userInfo
{
    if (_userInfo==nil) {
        NSDictionary *dic=[FileTool getDataFromUserDefaultWithKey:UserInfoPath];
        NSLog(@"%@",dic[@"item"]);
        UserInfo *info=[[UserInfo alloc]initWithJSONDict:dic[@"item"]];
        return info;
        
    }
    return _userInfo;
}
+ (BOOL)validateMobile:(NSString *)mobile {
    NSString *phoneRegex = @"^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}

+(NSString *)getAutoLoginPhoneNumber {
    NSDictionary *dict = [JNKeychain loadValueForKey:Key_AutoLoginAccount];
    return dict[@"phoneNumber"];
}

+(NSString *)getAutoLoginPassword {
    NSDictionary *dict = [JNKeychain loadValueForKey:Key_AutoLoginAccount];
    return dict[@"password"];
}
+(BOOL)showGuideImage
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:Key_GuideImage]?NO:YES;
}
+(void)saveGuideImage
{
    [[NSUserDefaults standardUserDefaults] setObject:@1 forKey:Key_GuideImage];
}

+ (NSString *) AFBase64EncodedStringFromString:(NSString *) string {
    NSData *data = [NSData dataWithBytes:[string UTF8String] length:[string lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
    NSUInteger length = [data length];
    NSMutableData *mutableData = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    
    uint8_t *input = (uint8_t *)[data bytes];
    uint8_t *output = (uint8_t *)[mutableData mutableBytes];
    
    for (NSUInteger i = 0; i < length; i += 3) {
        NSUInteger value = 0;
        for (NSUInteger j = i; j < (i + 3); j++) {
            value <<= 8;
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        static uint8_t const kAFBase64EncodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        
        NSUInteger idx = (i / 3) * 4;
        output[idx + 0] = kAFBase64EncodingTable[(value >> 18) & 0x3F];
        output[idx + 1] = kAFBase64EncodingTable[(value >> 12) & 0x3F];
        output[idx + 2] = (i + 1) < length ? kAFBase64EncodingTable[(value >> 6)  & 0x3F] : '=';
        output[idx + 3] = (i + 2) < length ? kAFBase64EncodingTable[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:mutableData encoding:NSASCIIStringEncoding];
}
-(NSString *)userAgent
{
    if (!_userAgent) {
        NSString *appVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
        _userAgent=[@"Mozilla/5.0 (iOS) ownCloud-iOS/" stringByAppendingString:appVersion];
    }
    
    return _userAgent;
}
@end

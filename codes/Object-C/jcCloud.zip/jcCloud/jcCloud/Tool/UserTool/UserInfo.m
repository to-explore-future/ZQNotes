//
//  UserInfo.m
//  StockEmotion
//
//  Created by dida on 15/11/18.
//  Copyright © 2015年 StockEmotion. All rights reserved.
//

#import "UserInfo.h"
@implementation UserInfo
- (void)setValue:(id)value forKey:(NSString *)key {
    
    [super setValue:value forKey:key];
}
@end

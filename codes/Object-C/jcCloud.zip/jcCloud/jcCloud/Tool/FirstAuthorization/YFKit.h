//
//  YFKit.h
//  AuthorityOfCameraAndPhoto
//
//  Created by chenyufeng on 6/20/16.
//  Copyright © 2016 chenyufengweb. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFKit : NSObject

+ (BOOL)isCameraDenied;
+ (BOOL)isCameraNotDetermined;

+ (BOOL)isPhotoAlbumDenied;
+ (BOOL)isPhotoAlbumNotDetermined;

@end

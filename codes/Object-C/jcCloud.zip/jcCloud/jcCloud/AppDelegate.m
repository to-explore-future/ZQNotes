//
//  AppDelegate.m
//  jcCloud
//
//  Created by mac on 2018/1/25.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "AppDelegate.h"
#import "AFNetworkReachabilityManager.h"
#import "AccountManager.h"
#import "UIDefine.h"
#import "JCDBManager.h"
#import "JCMainTabVC.h"
#import "JCUploadVC.h"

//FROM OC
#import "Customization.h"
#import "OCFrameworkConstants.h"
#import "OCURLSessionManager.h"
#import "OCCommunication.h"
#import "OCOAuth2Configuration.h"
#import "UtilsUrls.h"
#import "JCUploadVC.h"
#import "ManageUploadRequest.h"
#import "IFlyMSC/IFlyMSC.h"
#import "UploadUtils.h"
#import "constants.h"

#import <ShareSDK/ShareSDK.h>
#import <ShareSDKConnector/ShareSDKConnector.h>

//腾讯开放平台（对应QQ和QQ空间）SDK头文件
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>

//微信SDK头文件
#import "WXApi.h"




@interface AppDelegate ()

@property (nonatomic, strong) JCUploadVC *recentViewController;

@end

@implementation AppDelegate

//Delay Constants
float fiveSecondsDelay = 5.0;
float oneSecondDelay = 1.0;
float halfASecondDelay = 0.5;
float shortDelay = 0.3;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //分享
    
    

    //Set log level
    [IFlySetting setLogFile:LVL_ALL];
    
    //Set whether to output log messages in Xcode console
    [IFlySetting showLogcat:YES];
    
    //Set the local storage path of SDK
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachePath = [paths objectAtIndex:0];
    [IFlySetting setLogFilePath:cachePath];
    
    //Set APPID
    NSString *initString = [[NSString alloc] initWithFormat:@"appid=%@",APPID_VALUE];
    
    //Configure and initialize iflytek services.(This interface must been invoked in application:didFinishLaunchingWithOptions:)
    [IFlySpeechUtility createUtility:initString];
    
    JCDBManager *jcdb = [JCDBManager new];
    [jcdb createDataBase];
    _uploadArray=[[NSMutableArray alloc]init];

     NSLog(@"Launched in background %d", UIApplicationStateBackground == application.applicationState);
    // Override point for customization after application launch.
    [[NSUserDefaults standardUserDefaults] setValue:@"http://192.168.133.42" forKey:@"jcHost"];
    
    [[UINavigationBar appearance] setBarTintColor:DDTColorMain];
    [[UINavigationBar appearance] setTintColor:DDTColorMainTint];
    [[UINavigationBar appearance] setTitleTextAttributes: [NSDictionary dictionaryWithObjectsAndKeys:
                                                           DDTColorMainTint, NSForegroundColorAttributeName,
                                                           [UIFont systemFontOfSize:20],NSFontAttributeName,
                                                           nil]];
    self.window.tintColor = DDTColorMain;
    self.window.backgroundColor = DDTColorWhite;
    
//    [HTTPRequest getRequestWithUrl:@"http://192.168.133.42/status.php" params:nil success:^(NSDictionary *responseDict) {
//
//    } fail:^(NSString *errorMsg) {
//
//    }];
//    [AccountManager shareAccount].token=@"Basic dGVzdDp0ZXN0";
//    [HTTPRequest postRequestWithUrl:API_fileIndex params:nil success:^(NSDictionary *responseDict) {
//        
//    } fail:^(NSString *errorMsg) {
//        
//    }];

    
    
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
//        NSNotificationCenter * center = [NSNotificationCenter defaultCenter];
        // 当网络状态发生改变的时候调用这个block
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWiFi:
                _isNet=YES;
                _isWiFi = YES;
                [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiStatusChanges" object:@"YES"];
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                _isNet=YES;
                _isWiFi = NO;
                [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiStatusChanges" object:@"NO"];
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
            {
                _isNet=NO;
                _isWiFi = NO;
                [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiStatusChanges" object:@"NO"];
            }
                break;
                
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知网络");
                _isWiFi = NO;
                [[NSNotificationCenter defaultCenter] postNotificationName:@"WiFiStatusChanges" object:@"NO"];
                break;
            default:
                break;
        }
    }];
    
//    if ([AccountManager isNeedWelcomeVC]) {
//        self.window.rootViewController=[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"guideRootNavi"];
//    }
    // 开始监控
    [mgr startMonitoring];

    //初始化一个AVPlayer,只要应用活着不再销毁
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(initMusicPlayer:) name:@"initMusicPlayer" object:nil];


    
    //跳转首页
//    JCMainTabVC * mainTabVC = [[JCMainTabVC alloc] init];
//    self.window.rootViewController = mainTabVC;
//    [self.window makeKeyAndVisible];
//    UINavigationController *tab2NavigationVC = [mainTabVC.viewControllers objectAtIndex:1];
//    _recentViewController = [tab2NavigationVC.viewControllers objectAtIndex:0];


    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {}


- (void)applicationDidEnterBackground:(UIApplication *)application {}


- (void)applicationWillEnterForeground:(UIApplication *)application {}


- (void)applicationDidBecomeActive:(UIApplication *)application {}


- (void)applicationWillTerminate:(UIApplication *)application {}

#pragma mark - OCCommunications
//初始化
+ (OCCommunication*)sharedOCCommunication
{
    static OCCommunication* sharedOCCommunication = nil;
    if (sharedOCCommunication == nil)
    {
        //初始化上传的
        NSURLSessionConfiguration *configuration = nil;
        
        if (k_is_sso_active || !k_is_background_active) {
            configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        } else {
            configuration = [NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:k_session_name];
        }
        
        configuration.HTTPMaximumConnectionsPerHost = 1;
        configuration.requestCachePolicy = NSURLRequestUseProtocolCachePolicy;
        configuration.timeoutIntervalForRequest = k_timeout_upload;
        configuration.sessionSendsLaunchEvents = YES;
        [configuration setAllowsCellularAccess:YES];
        OCURLSessionManager *uploadSessionManager = [[OCURLSessionManager alloc] initWithSessionConfiguration:configuration];
        [uploadSessionManager.operationQueue setMaxConcurrentOperationCount:1];
        [uploadSessionManager setSessionDidReceiveAuthenticationChallengeBlock:^NSURLSessionAuthChallengeDisposition (NSURLSession *session, NSURLAuthenticationChallenge *challenge, NSURLCredential * __autoreleasing *credential) {
            return NSURLSessionAuthChallengePerformDefaultHandling;
        }];
        //初始化下载的
        NSURLSessionConfiguration *configurationDownload = nil;
        
        if (k_is_sso_active || !k_is_background_active) {
            configurationDownload = [NSURLSessionConfiguration defaultSessionConfiguration];
        } else {
            configurationDownload = [NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:k_download_session_name];
        }
        
        configurationDownload.HTTPMaximumConnectionsPerHost = 1;
        configurationDownload.requestCachePolicy = NSURLRequestUseProtocolCachePolicy;
        configurationDownload.timeoutIntervalForRequest = k_timeout_upload;
        configurationDownload.sessionSendsLaunchEvents = YES;
        [configurationDownload setAllowsCellularAccess:YES];
        OCURLSessionManager *downloadSessionManager = [[OCURLSessionManager alloc] initWithSessionConfiguration:configurationDownload];
        [downloadSessionManager.operationQueue setMaxConcurrentOperationCount:1];
        [downloadSessionManager setSessionDidReceiveAuthenticationChallengeBlock:^NSURLSessionAuthChallengeDisposition (NSURLSession *session, NSURLAuthenticationChallenge *challenge, NSURLCredential * __autoreleasing *credential) {
            return NSURLSessionAuthChallengePerformDefaultHandling;
        }];
        //初始化网络请求的
        NSURLSessionConfiguration *networkConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
        networkConfiguration.HTTPShouldUsePipelining = YES;
        networkConfiguration.HTTPMaximumConnectionsPerHost = 1;
        networkConfiguration.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        
        OCURLSessionManager *networkSessionManager = [[OCURLSessionManager alloc] initWithSessionConfiguration:networkConfiguration];
        [networkSessionManager.operationQueue setMaxConcurrentOperationCount:1];
        networkSessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        //--------------------------请求配置开始--------------------------
//        [networkSessionManager.requestSerializer setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];//郭
//        //        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
//        networkSessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json",@"text/javascript",@"text/html",@"text/plain",nil];
//        [networkSessionManager.requestSerializer setAuthorizationHeaderFieldWithUsername:@"test" password:@"test"];
//        [networkSessionManager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"authorization"];
//        networkSessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];     //http请求
//        networkSessionManager.requestSerializer.timeoutInterval = 60;                         //设置超时时间
//        [networkSessionManager.requestSerializer setStringEncoding:NSUTF8StringEncoding];     //设置编码格式
        //--------------------------请求配置结束--------------------------

        sharedOCCommunication = [[OCCommunication alloc] initWithUploadSessionManager:uploadSessionManager andDownloadSessionManager:downloadSessionManager andNetworkSessionManager:networkSessionManager];
        
        //Cookies is allways available in current supported Servers
        [sharedOCCommunication setIsCookiesAvailable:YES];
        
        [sharedOCCommunication setOauth2Configuration: [[OCOAuth2Configuration alloc]
                                                        initWithClientId:k_oauth2_client_id
                                                        clientSecret:k_oauth2_client_secret
                                                        redirectUri:k_oauth2_redirect_uri
                                                        authorizationEndpoint:k_oauth2_authorization_endpoint
                                                        tokenEndpoint:k_oauth2_token_endpoint]];
        
        [sharedOCCommunication setUserAgent:[UtilsUrls getUserAgent]];
        //OCTrustedCertificatesStore协议作用不明，先不设置，先注掉
//        OCKeychain *oKeychain = [[OCKeychain alloc] init];
//        [sharedOCCommunication setValueCredentialsStorage:oKeychain];
        //SSLCertificateManager认证作用不明，先不设置，先注掉
//        SSLCertificateManager *sslCertificateManager = [[SSLCertificateManager alloc] init];
//        [sharedOCCommunication setValueTrustedCertificatesStore: sslCertificateManager];
    }
    return sharedOCCommunication;
}

#pragma mark - DetailViewController Methods for iPad

/*
 * Method that update only the active progress view
 */

- (void) updateProgressView:(NSUInteger)num withPercent:(float)percent{
    
    NSLog(@"num: %lu", (unsigned long)num);
    NSLog(@"percent: %fd", percent);
    
    [_recentViewController updateProgressView:num withPercent:percent];
}

/*
 * This method update the badge of the recent tab and
 * update the table of recents view
 */
- (void)updateRecents {
    NSLog(@"AppDelegate update Recents and number of error uploads");
    
    __block int errorCount=0;
    __block ManageUploadRequest *currentManageUploadRequest;

    [_uploadArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {//遍历上传数组，统计错误数
        currentManageUploadRequest = obj;
        if (currentManageUploadRequest.currentUpload.kindOfError != notAnError){
            errorCount++;
        }
        
    }];
    
    NSString *errorBadge=nil;
    if (errorCount > 0) {
        errorBadge= [NSString stringWithFormat:@"%d",errorCount ];
    }
    
    NSLog(@"ERRORCOUNT: %@", errorBadge);
    
//    RecentViewController *currenRecent = [_ocTabBarController.viewControllers objectAtIndex:1];
//
//    if (![currenRecent.tabBarItem.badgeValue isEqualToString:errorBadge]) {
//        dispatch_async(dispatch_get_main_queue(), ^{
//            //update badge
//            [currenRecent.tabBarItem setBadgeValue:errorBadge];
//        });
//    }
    
    //update recents
    [_recentViewController updateRecents];
}

/*
 * Method that relaunch upload failed with timeout
 */
- (void) relaunchUploadsFailedNoForced{
//    [self relaunchUploadsFailed:NO];
}

/*
 *  This method update the _uploadArray info with a new upload with new status
 */
- (void) changeTheUploadsArrayInfoWith:(UploadsOfflineDto *) upload {
    
    for(int i = 0; i < [_uploadArray count] ; i++) {
        ManageUploadRequest *currentUploadRequest = [_uploadArray objectAtIndex:i];
        if (currentUploadRequest.currentUpload.idUploadsOffline == upload.idUploadsOffline) {
            currentUploadRequest.currentUpload = upload;
            [_uploadArray replaceObjectAtIndex:i withObject:currentUploadRequest];
        }
    }
}
#pragma mark - PrepareFilesToUploadDelegate methods

/*
 * Check if data base is ok an then refresh actual file list if not
 * check again after one second.
 */

//- (void)checkAndRefreshFiles{
//    NSLog(@"AppDelegate - checkAndRefreshFiles");
//
//    [_presentFilesViewController initLoading];
//    [_presentFilesViewController refreshTableFromWebDav];
//}

- (void)refreshAfterUploadAllFiles:(NSString *) currentRemoteFolder {
    NSLog(@"refreshAfterUploadAllFiles");
    [_presentFilesViewController getPicFolder];
    [_videoFileVC getPicFolder];
    [_allFileVC getPicFolder];

//    NSString *remoteUrlWithoutDomain = [UtilsUrls getHttpAndDomainByURL:currentRemoteFolder];
//    remoteUrlWithoutDomain = [currentRemoteFolder substringFromIndex:remoteUrlWithoutDomain.length];
//
//    NSString *currentFolderWithoutDomain = [UtilsUrls getHttpAndDomainByURL:_presentFilesViewController.currentRemoteFolder];
//    currentFolderWithoutDomain = [_presentFilesViewController.currentRemoteFolder substringFromIndex:currentFolderWithoutDomain.length];
//
//    //Only if is selected the first item: FileList.
//    if (_ocTabBarController.selectedIndex == 0 && !_isUploadViewVisible ) {
//
//        if ([remoteUrlWithoutDomain isEqualToString:currentFolderWithoutDomain]) {
//            [self checkAndRefreshFiles];
//        }
//    }
//
//    _prepareFiles = nil;
//
//    //End of the background task
//    if (uploadTask) {
//        [[UIApplication sharedApplication] endBackgroundTask:uploadTask];
//    }
}

#pragma mark - Clean the upload folder
//-----------------------------------
/// @name initUploadsOffline
///-----------------------------------

/**
 * Method to relaunch the UploadsOffline after came from background or when we killed the app
 *
 */
- (void) initUploadsOffline {
    
//    [ManageUploadsDB updateAllUploadsWithNotNecessaryCheck];
    
    JCDBManager *dbManager = [JCDBManager new];
    NSMutableArray *allUploads = [dbManager getUploads];
    NSMutableArray *allUploadsToBeModified = [NSMutableArray arrayWithArray:allUploads];
    
    //We save on allUploadsToBeModified the UploadsOfflineDto that are not on the _uploadArray (the files that are uploading now). On iOS6 _uploadArray should be empty
    for (ManageUploadRequest *currentUploadRequest in _uploadArray) {
        for (UploadsOfflineDto *currentUploadOffline in allUploads) {
            if (currentUploadOffline.idUploadsOffline == currentUploadRequest.currentUpload.idUploadsOffline) {
                
                UploadsOfflineDto *uploadToBeRemoved = nil;
                
                for (UploadsOfflineDto *current in allUploadsToBeModified) {
                    if (current.idUploadsOffline == currentUploadOffline.idUploadsOffline) {
                        uploadToBeRemoved = current;
                    }
                }
                if (uploadToBeRemoved) {
                    [allUploadsToBeModified removeObjectIdenticalTo:uploadToBeRemoved];
                }
            }
        }
    }
    
    
    NSUserDefaults * standardUserDefaults = [NSUserDefaults standardUserDefaults];
//    if ([standardUserDefaults boolForKey:k_app_killed_by_user] || k_is_sso_active) {
//        //We set all the UploadsOfflineDto that are not uploading but should as ready to be uploaded
//        [ManageUploadsDB updateNotFinalizeUploadsOfflineBy:allUploadsToBeModified];
//    } else {
        [self checkTheUploadFilesOnTheServer: allUploadsToBeModified];
//    }
    
    //We clean the tmp folder and the list
//    [self cleanUploadFolder];//先注掉这俩行，目的不明
//    JCDBManager *jcdb = [JCDBManager new];
//    [jcdb saveInUploadsOfflineTableTheFirst:k_number_uploads_shown];
    
    //Add finished uploads to Array
    [self addFinishedUploadsOfflineDataToUploadsArray];//刷新下_uploadArray
    
//    [standardUserDefaults setBool:NO forKey:k_app_killed_by_user];
//    [standardUserDefaults synchronize];
    
    //Refresh the tab
    [self performSelector:@selector(updateRecents) withObject:nil afterDelay:shortDelay];
}

//-----------------------------------
/// @name checkTheUploadFilesOnTheServer
///-----------------------------------

/**
 * Method called to check if a file was uploaded on the server
 *
 * @param NSArray -> uploadsBackground
 *
 */
- (void) checkTheUploadFilesOnTheServer: (NSArray *) uploadsBackground {
    
    for (UploadsOfflineDto *currentUploadBackground in uploadsBackground) {
        if ((currentUploadBackground.status != uploaded) && (currentUploadBackground.status != errorUploading)) {
//            NSString * path = [NSString stringWithFormat:@"%@%@", [currentUploadBackground.destinyFolder stringByRemovingPercentEncoding ], currentUploadBackground.uploadFileName];
//
//            [[AppDelegate sharedOCCommunication] readFile:path onCommunication:[AppDelegate sharedOCCommunication] successRequest:^(NSHTTPURLResponse *response, NSArray *items, NSString *redirectedServer) {
//                if (items != nil && [items count] > 0) {
//                    FileDto *currentFile = [items objectAtIndex:0];
//                    [self theFileWasUploadedByCurrentUploadInBackground:currentUploadBackground andCurrentFile:currentFile];
//                }
//
//            } failureRequest:^(NSHTTPURLResponse *response, NSError *error, NSString *redirectedServer) {
//                //Check the error for to know if there is a server connection error
//                if (error.code == kCFURLErrorCannotConnectToHost) {
//                    //The connection of the server is down. Set the status of the file to: "Pending to be check"
//                    NSLog(@"The server is down");
//                    [ManageUploadsDB setStatus:pendingToBeCheck andKindOfError:notAnError byUploadOffline:currentUploadBackground];
//                    [self addPendingToCheckUploadsToRecentsTab];
//                } else {
                    //Set the file status as a background error
            JCDBManager *dbManager = [JCDBManager new];
                    [dbManager setStatus:errorUploading andKindOfError:notAnError byUploadOffline:currentUploadBackground];
                    //Update the currentUploadBackground with DB
                    UploadsOfflineDto *fileForUpload = [dbManager getUploadOfflineById:(int)currentUploadBackground.idUploadsOffline];
                    [self createAManageRequestUploadWithTheUploadOffline:fileForUpload];
                    NSLog(@"The file is not on server");
                    [self relaunchUploadsFailed:YES];
            
//                }
//            }];
        }
    }
}

//-----------------------------------
/// @name createAManageRequestUploadWithTheUploadOffline
///-----------------------------------

/**
 * Method to create a ManageUploadRequest from a UploadsOfflineDto
 *
 * @param UploadsOfflineDto -> currentUploadBackground
 *
 */
- (void) createAManageRequestUploadWithTheUploadOffline: (UploadsOfflineDto*) currentUploadBackground {
    
    //Create ManageUploadRequest
    ManageUploadRequest *currentManageUploadRequest = [ManageUploadRequest new];
    
    //Insert the specific data to recents view
    NSDate *uploadedDate = [NSDate dateWithTimeIntervalSince1970:currentUploadBackground.uploadedDate];
    currentManageUploadRequest.date = uploadedDate;
    currentManageUploadRequest.currentUpload.uploadedDate = uploadedDate.timeIntervalSince1970;
    //Set uploadOffline
    currentManageUploadRequest.currentUpload = currentUploadBackground;
    currentManageUploadRequest.lenghtOfFile = [UploadUtils makeLengthString:currentUploadBackground.estimateLength];
//    currentManageUploadRequest.userUploading = [ManageUsersDB getUserByUserId:currentUploadBackground.userId];
    
//    currentManageUploadRequest.pathOfUpload = [UtilsUrls getPathWithAppNameByDestinyPath:currentUploadBackground.destinyFolder andUser:currentManageUploadRequest.userUploading];
    currentManageUploadRequest.pathOfUpload = currentUploadBackground.destinyFolder;
    
    currentManageUploadRequest.isFromBackground = YES;
    
    //This for prevent the duplication of the Uploads in the array
    [self addToTheUploadArrayWithoutDuplicatesTheFile:currentManageUploadRequest];
    
    [self updateRecents];
}

#pragma mark - Background Fetch methods

//-----------------------------------
/// @name addToTheUploadArrayWithoutDuplicatesTheFile
///-----------------------------------

/**
 * Method to add to the _uploadArray a ManageUploadRequest checking if exist before to prevent duplications
 *
 * @param ManageUploadRequest -> uploadFile
 *
 */
//根据uploadFile构造_uploadArray，没有加上，有就替换
- (void) addToTheUploadArrayWithoutDuplicatesTheFile: (ManageUploadRequest *) uploadFile {
    
    BOOL isExist = NO;
    //Check if the ManageUploadRequest exists on the uploadArray
    for (ManageUploadRequest *currentInUploadArray in [self.uploadArray copy]) {
        if (currentInUploadArray.currentUpload.idUploadsOffline == uploadFile.currentUpload.idUploadsOffline) {
            isExist = YES;
        }
    }
    //If the file doesn't exist add it to the uploadArray
    if (!isExist) {
        [_uploadArray addObject:uploadFile];//第二个tab页下展示的数据
    } else {
        [self changeTheUploadsArrayInfoWith:uploadFile.currentUpload];
    }
}

#pragma mark - Recent Tab and methods with uploads
/*
 * This method add the finished files data of the uploads_offline table to uploadsArray
 */
- (void) addFinishedUploadsOfflineDataToUploadsArray{
    
    //1.- An array of Uploads
    NSArray *uploadsFromDB = nil;
    JCDBManager *dbManager = [JCDBManager new];
    uploadsFromDB = [dbManager getUploadsByStatus:uploaded andByKindOfError:notAnError];
    
    //for in
    for(UploadsOfflineDto *current in uploadsFromDB) {
        
        //Create the object
        ManageUploadRequest *currentManageUploadRequest = [ManageUploadRequest new];
        
        //Insert the specific data to recents view
        NSDate *uploadedDate = [NSDate dateWithTimeIntervalSince1970:current.uploadedDate];
        currentManageUploadRequest.date = uploadedDate;
        //Set uploadOffline
        currentManageUploadRequest.currentUpload = current;
        currentManageUploadRequest.lenghtOfFile = [UploadUtils makeLengthString:current.estimateLength];
//        currentManageUploadRequest.userUploading = [ManageUsersDB getUserByUserId:current.userId];
        
        currentManageUploadRequest.pathOfUpload = current.destinyFolder;
        
        //Add the object to the uploadArray without duplicates
        [self addToTheUploadArrayWithoutDuplicatesTheFile:currentManageUploadRequest];
    }
}

/*
 * Method relaunch the upload failed if exist
 * This method has a timeout
 *@isForced -> If YES the timeout is 0 secs
 */
- (void) relaunchUploadsFailed:(BOOL)isForced {
    
    long currentDate = [[NSDate date] timeIntervalSince1970];
    //NSLog(@"currentDate - _dateLastRelaunch: %ld", currentDate - _dateLastRelaunch);
    if ((currentDate - _dateLastRelaunch) > k_minimun_time_to_relaunch || isForced) {
        
        _dateLastRelaunch = currentDate;
        
        //We get all the files that are with any error
        JCDBManager *dbManager = [JCDBManager new];
        NSMutableArray *listOfUploadsFailed = [dbManager getUploadsByStatus:errorUploading andByKindOfError:notAnError];
        NSMutableArray *listOfPendingToBeCheckFiles = [dbManager getUploadsByStatus:pendingToBeCheck andByKindOfError:notAnError];
        NSLog(@"There are: %ld in the list of uploads failed", (long)listOfUploadsFailed.count);
        NSLog(@"There are: %ld files in the list of pending to be check", (long)listOfPendingToBeCheckFiles.count);
        
        //First, check if there are
        if (listOfUploadsFailed.count > 0) {
            //We update all the files with error to the status waitingAddToUploadList
            JCDBManager *dbManager = [JCDBManager new];
            [dbManager updateAllErrorUploadOfflineWithWaitingAddUploadList];
            
            if (_prepareFiles == nil) {
                _prepareFiles = [[PrepareFilesToUpload alloc] init];
                _prepareFiles.listOfFilesToUpload = [[NSMutableArray alloc] init];
                _prepareFiles.listOfAssetsToUpload = [[NSMutableArray alloc] init];
                _prepareFiles.arrayOfRemoteurl = [[NSMutableArray alloc] init];
                _prepareFiles.listOfUploadOfflineToGenerateSQL = [[NSMutableArray alloc] init];
                _prepareFiles.delegate = self;
            }
            
            for (UploadsOfflineDto *upload in listOfUploadsFailed) {
                upload.status=waitingAddToUploadList;
            }
            
            [_prepareFiles sendFileToUploadByUploadOfflineDto:[listOfUploadsFailed objectAtIndex:0]];
        }
        
        
        if (listOfPendingToBeCheckFiles.count > 0) {
            [self checkTheUploadFilesOnTheServer:listOfPendingToBeCheckFiles];
        }
        
    }
}

/*
 * Method that relaunch upload failed without timeout
 */
- (void) relaunchUploadsFailedForced{
    [self relaunchUploadsFailed:YES];
}

@end

//
//  DDMyTextTipHeader.m
//  dida
//
//  Created by mac on 2017/2/13.
//  Copyright © 2017年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "DDMyTextTipHeader.h"

@implementation DDMyTextTipHeader
-(void)prepare
{
//    [super prepare];
//    self.lastUpdatedTimeLabel.hidden=YES;
//    self.stateLabel.hidden=YES;
//    UILabel *tipLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 50)];
//    [self.stateLabel.superview addSubview:tipLabel];
//    tipLabel.font=[UIFont systemFontOfSize:13];
//    tipLabel.textColor=[UIColor grayColor];
//    tipLabel.text=@"下拉关闭评论";
//    tipLabel.textAlignment=NSTextAlignmentCenter;
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

//
//  DDMyTextTipHeader.h
//  dida
//
//  Created by mac on 2017/2/13.
//  Copyright © 2017年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "MJRefreshStateHeader.h"

@interface DDMyTextTipHeader : MJRefreshStateHeader

@end

//
//  DDLoadingView.m
//  dida
//
//  Created by dida on 15/8/13.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "DDLoadingView.h"

#import "UIDefine.h"

@implementation DDLoadingView

//- (void)dealloc {
//    
//}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, 100, 100);
        
        self.layer.shadowColor = [UIColor blackColor].CGColor;//阴影颜色
        self.layer.shadowOffset = CGSizeMake(0, 0);//偏移距离
        self.layer.shadowOpacity = 0.3;//不透明度
        self.layer.shadowRadius = 4.0;//半径
        
        UIView *shadowView = [[UIView alloc] initWithFrame:self.bounds];
        shadowView.backgroundColor = UIColorFromRGBAlpha(0xffffff, 0.9);
        [self addSubview:shadowView];
        
        shadowView.layer.cornerRadius = 50;
        shadowView.layer.masksToBounds = YES;
        
        UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lanqiu_icon"]];
        imgView.center = CGPointMake(self.frame.size.width/2, 20);
        [shadowView addSubview:imgView];
        
        self.qiuView = imgView;
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 80, self.frame.size.width, 1)];
        lineView.backgroundColor = UIColorFromRGB(0xea5413);
        [shadowView addSubview:lineView];
        
        UILabel *label = [[UILabel alloc] init];
        label.text = @"加载中...";
        label.font = [UIFont systemFontOfSize:10];
        label.textColor = UIColorFromRGB(0xea5413);
        [label sizeToFit];
        label.center = CGPointMake(self.frame.size.width/2, self.frame.size.height-10);

        [shadowView addSubview:label];
        
        [UIView animateKeyframesWithDuration:0.6 delay:0 options:UIViewKeyframeAnimationOptionRepeat animations:^{
            [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.5 animations:^{
                self.qiuView.center = CGPointMake(self.frame.size.width/2, 65);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.5 relativeDuration:0.5 animations:^{
                self.qiuView.center = CGPointMake(self.frame.size.width/2, 20);
            }];
        } completion:^(BOOL finished) {
            
        }];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

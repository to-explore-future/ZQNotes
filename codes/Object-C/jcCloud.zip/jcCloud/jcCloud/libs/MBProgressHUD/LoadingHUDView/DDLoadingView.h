//
//  DDLoadingView.h
//  dida
//
//  Created by dida on 15/8/13.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDLoadingView : UIView

@property (nonatomic, weak) UIImageView *qiuView;

@end

//
//  ELCImagePickerController.m
//  ELCImagePickerDemo
//
//  Created by ELC on 9/9/10.
//  Copyright 2010 ELC Technologies. All rights reserved.
//

#import "ELCImagePickerController.h"
#import "ELCAsset.h"
#import "ELCAssetCell.h"
#import "ELCAssetTablePicker.h"
#import "ELCAlbumPickerController.h"
#import <CoreLocation/CoreLocation.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import "ELCConsole.h"
#import "ELCConstants.h"
#import <Photos/Photos.h>



@implementation ELCImagePickerController

//Using auto synthesizers

- (id)initImagePicker
{
    ELCAlbumPickerController *albumPicker = [[ELCAlbumPickerController alloc] init];
    
    self = [super initWithRootViewController:albumPicker];
    if (self) {
        self.maximumImagesCount = 4;
        self.returnsImage = YES;
        self.returnsOriginalImage = YES;
        [albumPicker setParent:self];
        self.mediaTypes = @[(NSString *)kUTTypeImage, (NSString *)kUTTypeMovie];
    }
    return self;
}

- (id)initOnlyImagePicker:(NSString *)remoteUrl
{
    ELCAssetTablePicker *picker = [[ELCAssetTablePicker alloc] initWithNibName: nil bundle: nil];

    self = [super initWithRootViewController:picker];
    if (self) {
        self.maximumImagesCount = 4;
        self.returnsImage = YES;
        self.returnsOriginalImage = YES;
        [picker setParent:self];
//        self.mediaTypes = @[(NSString *)kUTTypeImage, (NSString *)kUTTypeMovie];
        
        picker.currentRemoteFolder = remoteUrl;
//        picker.assetGroup = [[self.assetGroups objectAtIndex:indexPath.row] allValues][0];
        picker.assetGroupName = @"请选择图片";
//        picker.assetPickerFilterDelegate = self.assetPickerFilterDelegate;
        picker.filterShowType=1;
    }
    
    return self;
}

- (id)initOnlyVideoPicker:(NSString *)remoteUrl
{
    ELCAssetTablePicker *picker = [[ELCAssetTablePicker alloc] initWithNibName: nil bundle: nil];
    
    self = [super initWithRootViewController:picker];
    if (self) {
        self.maximumImagesCount = 4;
        self.returnsImage = YES;
        self.returnsOriginalImage = YES;
        [picker setParent:self];
        //        self.mediaTypes = @[(NSString *)kUTTypeImage, (NSString *)kUTTypeMovie];
        
        picker.currentRemoteFolder = remoteUrl;
        //        picker.assetGroup = [[self.assetGroups objectAtIndex:indexPath.row] allValues][0];
        picker.assetGroupName = @"请选择视频";
        //        picker.assetPickerFilterDelegate = self.assetPickerFilterDelegate;
        picker.filterShowType=2;
    }
    
    return self;
}

- (id)initAllPicker:(NSString *)remoteUrl
{
    ELCAssetTablePicker *picker = [[ELCAssetTablePicker alloc] initWithNibName: nil bundle: nil];
    
    self = [super initWithRootViewController:picker];
    if (self) {
        self.maximumImagesCount = 4;
        self.returnsImage = YES;
        self.returnsOriginalImage = YES;
        [picker setParent:self];
        //        self.mediaTypes = @[(NSString *)kUTTypeImage, (NSString *)kUTTypeMovie];
        
        picker.currentRemoteFolder = remoteUrl;
        //        picker.assetGroup = [[self.assetGroups objectAtIndex:indexPath.row] allValues][0];
        picker.assetGroupName = @"请选择资源";
        //        picker.assetPickerFilterDelegate = self.assetPickerFilterDelegate;
        picker.filterShowType=3;
    }
    
    return self;
}

- (id)initWithRootViewController:(UIViewController *)rootViewController
{

    self = [super initWithRootViewController:rootViewController];
    if (self) {
        self.maximumImagesCount = 4;
        self.returnsImage = YES;
    }
    return self;
}

- (ELCAlbumPickerController *)albumPicker
{
    return self.viewControllers[0];
}

- (void)setMediaTypes:(NSArray *)mediaTypes
{
    self.albumPicker.mediaTypes = mediaTypes;
}

- (NSArray *)mediaTypes
{
    return self.albumPicker.mediaTypes;
}

- (void)cancelImagePicker
{
	if ([_imagePickerDelegate respondsToSelector:@selector(elcImagePickerControllerDidCancel:)]) {
		[_imagePickerDelegate performSelector:@selector(elcImagePickerControllerDidCancel:) withObject:self];
	}
}

//Method to block the number of items that allow to select using the self.maximumImagesCount
- (BOOL)shouldSelectAsset:(ELCAsset *)asset previousCount:(NSUInteger)previousCount
{
    return YES;
}

- (BOOL)shouldDeselectAsset:(ELCAsset *)asset previousCount:(NSUInteger)previousCount;
{
    return YES;
}

//选择相册最终代理
//assets本地图像集合，urlToUpload远程文件夹地址
-(void)selectedAssets:(NSArray*)assets andURL:(NSString*)urlToUpload {
    NSLog(@"selectedAssets");
    
    NSMutableDictionary *args = [[NSMutableDictionary alloc] init];
    [args setObject:assets forKey:@"assets"];
    [args setObject:urlToUpload forKey:@"urlToUpload"];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    //合并成一个参数，传给唤起线程方法
    [self performSelector:@selector(initThredInABackgroundThread:) withObject:args afterDelay:0.2];
}

-(void) initThredInABackgroundThread:(NSMutableDictionary*)args{
    [self performSelectorInBackground:@selector(initInOtherThread:) withObject:args];
}

//子线程中执行
-(void)initInOtherThread:(NSMutableDictionary*)args{
    NSMutableArray *returnArray = [[NSMutableArray alloc] init];
    //拆回两个参数
    NSArray *_assets = [args objectForKey:@"assets"];
    NSString *urlToUpload = [args objectForKey:@"urlToUpload"];
    
    for(ELCAsset *elcAsset in _assets) {//构造PHAsset集合returnArray，ELCAsset除asset其它信息不回传
        
        PHAsset *asset = (PHAsset*) elcAsset.asset;
        
        [returnArray addObject:asset];
        
        NSLog(@"Doing something");
    }
    
    if([self.imagePickerDelegate respondsToSelector:@selector(elcImagePickerController:didFinishPickingMediaWithInfo:inURL:)]) {
        [self.imagePickerDelegate elcImagePickerController:self didFinishPickingMediaWithInfo:[NSArray arrayWithArray:returnArray] inURL:urlToUpload];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        return YES;
    } else {
        return toInterfaceOrientation != UIInterfaceOrientationPortraitUpsideDown;
    }
}

- (BOOL)onOrder
{
    return [[ELCConsole mainConsole] onOrder];
}

- (void)setOnOrder:(BOOL)onOrder
{
    [[ELCConsole mainConsole] setOnOrder:onOrder];
}

@end

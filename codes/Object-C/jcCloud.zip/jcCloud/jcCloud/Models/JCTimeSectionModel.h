//
//  JCTimeSectionModel.h
//  jcCloud
//
//  Created by mac on 2018/1/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCBaseModel.h"

@interface JCTimeSectionModel : JCBaseModel
@property (nonatomic,copy)NSString *title;
@property (nonatomic,strong)NSArray *files;
@end

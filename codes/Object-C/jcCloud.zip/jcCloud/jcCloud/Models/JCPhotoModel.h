//
//  JCPhotoModel.h
//  jcCloud
//
//  Created by mac on 2018/1/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCBaseModel.h"

@interface JCPhotoModel : JCBaseModel
@property (nonatomic,copy)NSString *city;
@property (nonatomic,copy)NSString *country;
@property (nonatomic,copy)NSString *district;
@property (nonatomic,copy)NSString *etag;
@property (nonatomic,strong)NSNumber *id;
@property (nonatomic,copy)NSString *mimetype;
@property (nonatomic,strong)NSNumber *mtime;
@property (nonatomic,copy)NSString *name;
@property (nonatomic,strong)NSNumber *parentId;
@property (nonatomic,strong)NSNumber *permissions;
@property (nonatomic,copy)NSString *path;
@property (nonatomic,copy)NSString *province;
@property (nonatomic,strong)NSNumber *size;
@property (nonatomic,strong)NSString *street;
@property (nonatomic,strong)NSNumber *upload_time;
@property (nonatomic,copy)NSString *type;
@end
//city = "\U592a\U539f\U5e02";
//country = "\U4e2d\U56fd";
//district = "\U8fce\U6cfd\U533a";
//etag = b9b5cddedcb4e8be06dc8e44be8f1957;
//id = 139;
//mimetype = "image/jpeg";
//mtime = 1511946641000;
//name = "IMG_20120330_133736.jpg";
//parentId = 75;
//path = "IMG_20120330_133736.jpg";
//permissions = 27;
//province = "\U5c71\U897f\U7701";
//size = 4374893;
//street = "";
//type = file;
//"upload_time" = 1515651882000;


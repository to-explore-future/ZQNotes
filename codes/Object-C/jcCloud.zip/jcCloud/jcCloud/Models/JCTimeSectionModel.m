//
//  JCTimeSectionModel.m
//  jcCloud
//
//  Created by mac on 2018/1/26.
//  Copyright © 2018年 danqing. All rights reserved.
//

#import "JCTimeSectionModel.h"
#import "JCPhotoModel.h"
@implementation JCTimeSectionModel
-(void)setValue:(id)value forKey:(NSString *)key
{
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"files"]) {
        NSMutableArray *arr=[NSMutableArray array];
        for (NSDictionary *dic in value) {
            JCPhotoModel *m=[[JCPhotoModel alloc]initWithJSONDict:dic];
            [arr addObject:m];
        }
        self.files=arr;
    }
}
@end

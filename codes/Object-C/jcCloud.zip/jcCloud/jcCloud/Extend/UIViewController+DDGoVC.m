//
//  UIViewController+DDGoVC.m
//  dida
//
//  Created by dida on 15/7/6.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "UIViewController+DDGoVC.h"
#import "AccountManager.h"
static UIAlertView *_loginFailAlertView = nil;

@implementation UIViewController (DDGoVC)

+ (id)initialViewControllerForStoryBoardName:(NSString *)name {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:name bundle:nil];
    return [storyBoard instantiateInitialViewController];
}



+ (id)viewControllerForStoryBoardName:(NSString *)name Identifier:(NSString *)identifier {
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:name bundle:nil];
    return [storyBoard instantiateViewControllerWithIdentifier:identifier];
}

- (void)goRegisterVC {
    UIViewController* ctrl = [self.class viewControllerForStoryBoardName:@"Login" Identifier:@"RegisterViewController"];
    [ctrl setValue:self forKey:@"fromVC"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:ctrl];
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)goBindPhoneVC {
    UIViewController* ctrl = [self.class viewControllerForStoryBoardName:@"Login" Identifier:@"RegisterViewController"];
    [ctrl setValue:@YES forKey:@"isBindPhone"];
    UINavigationController *navi=[[UINavigationController alloc] initWithRootViewController:ctrl];
    
    [self presentViewController:navi animated:YES completion:nil];
}




- (UIAlertView *)loginFailAlertView {
    return _loginFailAlertView;
}

- (void)setLoginFailAlertView:(UIAlertView *)alertView {
    _loginFailAlertView = alertView;
}

- (void)pushMatchDetailVCWithMatchModel:(DDMatchListModel *)model
{
    UIViewController *detailVC=[self.storyboard instantiateViewControllerWithIdentifier:@"DDTMatchDetailVC"];
    [detailVC setValue:model forKey:@"model"];
    [self.navigationController pushViewController:detailVC animated:NO];
}

- (void)pushMatchMemberRecordVCWithModel:(DDMatchSchduleModel *)model WithMatchId:(NSNumber *)matchId
{
    UIViewController *detailVC=[self.storyboard instantiateViewControllerWithIdentifier:@"DDTMatchMemberRecordVC"];
    [detailVC setValue:model forKey:@"model"];
    [detailVC setValue:matchId forKey:@"matchId"];
    [detailVC setValue:self forKey:@"matchDetailVC"];
    [self.navigationController pushViewController:detailVC animated:YES];
}
- (void)pushRecordVCWithTotalModel:(DDTDataTotalModel *)model
{
    UIViewController *detailVC=[self.storyboard instantiateViewControllerWithIdentifier:@"DDTRecordListVC"];
    [detailVC setValue:model forKey:@"model"];
    [detailVC setValue:self forKey:@"delegate"];
   
    [self presentViewController:detailVC animated:YES completion:^{
        
    }];
}
-(void)loginFailForRequest
{
    [AccountManager outAutoLoginAccount];
    [self goLoginVC];
}
- (void)goLoginVC
{
    
}
@end


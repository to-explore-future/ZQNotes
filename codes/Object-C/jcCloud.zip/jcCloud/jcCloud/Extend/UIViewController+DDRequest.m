//
//  UIViewController+DDRequest.m
//  dida
//
//  Created by dida on 15/8/3.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "UIViewController+DDRequest.h"
#import "AppDelegate.h"
@implementation UIViewController (DDRequest)

- (void)requestFail:(NSString *)errorMsg {
    [self hideHUD];
//    if ([errorMsg isEqualToString:@"401"]||[errorMsg isEqualToString:@"权限错误"]) {
//        [self loginFailForRequest];
//    } else {
    AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
    [self showAutoDelayHUDWithText:errorMsg.length==0?app.isNet?@"服务器有点小情绪":@"您的网络有点问题":errorMsg];
//    }
}

@end

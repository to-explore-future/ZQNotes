//
//  UIViewController+DDShowHUD.m
//  dida
//
//  Created by dida on 15/7/1.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import "UIViewController+DDShowHUD.h"

#import "DDLoadingView.h"

@implementation UIViewController (DDShowHUD)

#pragma mark - Show MBProgressHUD

- (void)showLoadingHUD {
    [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.color = [UIColor clearColor];
    hud.customView = [[DDLoadingView alloc] init];
    hud.mode = MBProgressHUDModeCustomView;
}

- (void)showLoadingHUDWithText:(NSString *)text {
    [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = text;
}

- (void)showAutoDelayHUDWithText:(NSString *)text {
    [self showAutoDelayHUDWithText:text hideDelegate:nil];
}

- (void)showAutoDelayHUDWithText:(NSString *)text hideDelegate:(id<MBProgressHUDDelegate>)delegate {
    [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.delegate = delegate;
    hud.mode = MBProgressHUDModeText;
    hud.labelText = text;
    [hud hide:YES afterDelay:2];
}

- (void)hideHUD {
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

#pragma mark - MBProgressHUDDelegate

- (void)hudWasHidden:(MBProgressHUD *)hud {
    
}

#pragma mark - Show UIAlertView

- (UIAlertView *)showAlertViewWithTitle:(NSString *)title {
    return [self showAlertView:title message:nil];
}

- (UIAlertView *)showAlertViewWithMessage:(NSString *)message {
    return [self showAlertView:nil message:message];
}

- (UIAlertView *)showAlertView:(NSString *)title message:(NSString *)message {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alertView show];
    
    return alertView;
}

@end

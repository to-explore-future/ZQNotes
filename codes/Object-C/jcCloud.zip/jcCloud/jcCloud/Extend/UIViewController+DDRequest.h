//
//  UIViewController+DDRequest.h
//  dida
//
//  Created by dida on 15/8/3.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIViewController+DDShowHUD.h"
#import "UIViewController+DDGoVC.h"
@interface UIViewController (DDRequest)

/** 请求失败处理 */
- (void)requestFail:(NSString *)errorMsg;

@end

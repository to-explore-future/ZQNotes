//
//  UIViewController+DDGoVC.h
//  dida
//
//  Created by dida on 15/7/6.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DDTMatchDetailVC;
#import "JCLoginRegisterProtocol.h"

@class DDMatchListModel;
@class DDMatchSchduleModel;
@class DDTDataTotalModel;
@interface UIViewController (DDGoVC) <JCLoginRegisterProtocol>

+ (id)initialViewControllerForStoryBoardName:(NSString *)name;
+ (id)viewControllerForStoryBoardName:(NSString *)name Identifier:(NSString *)identifier;

- (void)goRegisterVC;
- (void)goBindPhoneVC;
- (void)goLoginVC;


- (UIAlertView *)loginFailAlertView;
- (void)setLoginFailAlertView:(UIAlertView *)alertView;

- (void)pushMatchDetailVCWithMatchModel:(DDMatchListModel *)model;

- (void)pushMatchMemberRecordVCWithModel:(DDMatchSchduleModel *)model WithMatchId:(NSNumber *)matchId;

- (void)pushGameDataStatisVCWithTotalModel:(DDTDataTotalModel *)totalModel withMatchDetailVC:(DDTMatchDetailVC *)matchDetailVC;
- (void)pushRecordVCWithTotalModel:(DDTDataTotalModel *)model;
@end

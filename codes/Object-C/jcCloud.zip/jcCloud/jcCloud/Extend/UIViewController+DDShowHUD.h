//
//  UIViewController+DDShowHUD.h
//  dida
//
//  Created by dida on 15/7/1.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MBProgressHUD.h"

@interface UIViewController (DDShowHUD) <MBProgressHUDDelegate>

/** 显示加载框 */
- (void)showLoadingHUD;
/** 显示带文字的加载框 */
- (void)showLoadingHUDWithText:(NSString *)text;
/** 显示自动隐藏带文字的加载框 */
- (void)showAutoDelayHUDWithText:(NSString *)text;
/** 显示自动隐藏，隐藏后需要处理，带文字的加载框 */
- (void)showAutoDelayHUDWithText:(NSString *)text hideDelegate:(id<MBProgressHUDDelegate>)delegate;
/** 隐藏加载框 */
- (void)hideHUD;

/** 显示只带title的AlertView */
- (UIAlertView *)showAlertViewWithTitle:(NSString *)title;
/** 显示只带message的AlertView */
- (UIAlertView *)showAlertViewWithMessage:(NSString *)message;
/** 显示带title、message的AlertView */
- (UIAlertView *)showAlertView:(NSString *)title message:(NSString *)message;

@end

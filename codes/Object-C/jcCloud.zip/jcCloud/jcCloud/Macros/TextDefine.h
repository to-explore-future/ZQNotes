//
//  TextDefine.h
//  dida
//
//  Created by dida on 15/6/14.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#ifndef dida_TextDefine_h
#define dida_TextDefine_h

#define Text_AddFriendShare @"我加入了火星篮球APP，快来一起玩耍吧！火星篮球APP是一款集头条、学球及打球为一体的篮球APP，精彩的篮球资讯，视频讲解让你秒成球场扛把子，约球局找球场，兄弟，该你上场了！火星篮球APP下载链接—http://t.cn/RqOvWkQ"

#define Text_AddFriendJoinGroup @"快伸出你的双手，来拥抱这一条条大腿"

#define Title_AddFriendJoinGroup @"快来加入[%@]俱乐部"

#define Title_AddFriend @"%@喊你一起加入火星篮球!"

#define DynamicShareTitle @"火星篮球：最好玩的篮球社区"
#define DynamicDefaultContent @"“欲”罢不能的篮球视界"
#define HeadLineDefaultTitle @"火星篮球,只为篮球爱好者"

#define WeiBoGuanZhuText @"#火星篮球APP#  我加入了火星篮球APP，快来一起玩耍吧！火星篮球APP是一款集头条、学球及打球为一体的篮球APP，精彩的篮球资讯，视频讲解让你秒成球场扛把子，约球局找球场，兄弟，该你上场了！火星篮球APP下载链接—http://t.cn/RqOvWkQ"

#define PersonNullText @"这个人很懒啥也没留下~~"

#define FavoriteAlertTitle @"亲，跪求星好评"

#define FavoriteAlertMessage @"所有工程师和运营狗给您请安了，篮球万岁"

#endif

//
//  APIDefine.h
//  dida
//
//  Created by dida on 15/6/9.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//



#define API_Host                 [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"jcHost"]]
#define API_V1                   [API_Host stringByAppendingString:@"/ocs/v1.php/apps"]
#define API_Login                [API_V1 stringByAppendingString:@"/cloud/user?format=json"]
#define API_connectServer                API_Host@"/status.php?format=json"
#define API_fileIndex                [API_V1 stringByAppendingString:@"/jiacc_index/api/v1/index?format=json"]
#define API_photoList                [API_V1 stringByAppendingString:@"/jiacc_image/api/v1/list?format=json"]

#define API_Logout     @"123"




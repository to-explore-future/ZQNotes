//
//  AppConfig.m
//  worde
//
//  Created by dida on 15/11/11.
//  Copyright © 2015年 wordemotion. All rights reserved.
//

#import "AppConfig.h"

#import <UIKit/UIKit.h>
#import <AFNetworkActivityIndicatorManager.h>
#import <JNKeychain.h>
#import "UIDefine.h"


@implementation AppConfig

+ (void)appInitialize {
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    [AppConfig deviceId];
    [AppConfig appVersion];
}

+ (NSString *)deviceId {
    NSDictionary *dic = [[NSBundle mainBundle] infoDictionary];
    NSString *bundleId = dic[@"CFBundleIdentifier"];
    NSString *key = @"uuid";
    NSDictionary *appInfo = [JNKeychain loadValueForKey:bundleId];
    NSString *deviceId = appInfo[key];
    if ([deviceId length] == 0) {
        deviceId = [self uuid];
        NSMutableDictionary *appDict = [NSMutableDictionary dictionaryWithDictionary:appInfo];
        appDict[key] = deviceId;
        [JNKeychain saveValue:appDict forKey:bundleId];
    }
    return deviceId;
}

+ (NSString *)appVersion {
    NSDictionary *bundleDic = [[NSBundle mainBundle] infoDictionary];
    NSString *version = [bundleDic objectForKey:@"CFBundleShortVersionString"];
     return version;
}

+ (NSString*) uuid {
    CFUUIDRef puuid = CFUUIDCreate( nil );
    CFStringRef uuidString = CFUUIDCreateString( nil, puuid );
    NSString * result = (NSString *)CFBridgingRelease(CFStringCreateCopy( NULL, uuidString));
    CFRelease(puuid);
    CFRelease(uuidString);
    return result;
}

@end

//
//  ThirdServicesDefine.h
//  dida
//
//  Created by dida on 15/6/16.
//  Copyright (c) 2015年 &#24352; &#22269;&#25104;. All rights reserved.
//

#ifndef dida_ThirdServicesDefine_h
#define dida_ThirdServicesDefine_h
//七牛

#define QNToken @"mqOhZRrMU2bEqSOdwlNzfGjkHCEegy62AOhnGvbR:3DbLs_iAjcyNBGsd_nAaWnDlF5U=:eyJzY29wZSI6ImRpZGF5dW5kb25nIiwiZGVhZGxpbmUiOjE0NzAwMjkwNjl9"
//微信
#define WXPartnerId @"1304622201"
#define WXAppId @"wx73dab4f0b787222e"
#define WXAppKey @"017f7b17a2f5ea6ce8b749ecabc91317"


//百度APPKey
#define BaiDu_APPKEY @"LeVk1wuVd19Gvt9OKzK2luTy"
//友盟APPKey
//正式
#define UMENG_APPKEY @"553b0d2267e58e7bcc000788"
//测试
//#define UMENG_APPKEY @"5822ea083eae2570cf000c7c"

//微博key
#define WeiBo_APPKEY @"1597883502"
#define WBRedirectURI    @"https://api.weibo.com/oauth2/default.html"


#define  QQAppId  @"1104663694"
#define  QQkEY    @"pPefUsqzEtxZG3RN"


//讯飞
#define  IFkEY    @"5787078f"

#ifdef DEBUG
//测试环境
//融云APPKey
#define RONGCLOUD_IM_APPKEY @"pwe86ga5elzk6"

//#define RONGCLOUD_IM_APPKEY @"4z3hlwrv3c1ft"

#else
//正式环境
//融云APPKey
#define RONGCLOUD_IM_APPKEY @"4z3hlwrv3c1ft"
//#define RONGCLOUD_IM_APPKEY @"pwe86ga5elzk6"


#endif

#endif

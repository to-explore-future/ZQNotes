//
//  UIDefine.h
//  worde
//
//  Created by dida on 15/11/11.
//  Copyright © 2015年 wordemotion. All rights reserved.
//

#ifndef UIDefine_h
#define UIDefine_h

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define UIColorFromRGBAlpha(rgbValue, a) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:a]
#define UIColorRGB(r,g,b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1]

#define TeamColorArr @[UIColorFromRGB(0x595858),UIColorFromRGB(0xefefef),UIColorFromRGB(0x00479c),UIColorFromRGB(0xFAC000),UIColorFromRGB(0xe63a21),UIColorFromRGB(0x2ab16a),UIColorFromRGB(0x5f1986)]

//默认界面背景
#define ColorNormalBackgroundColor      UIColorFromRGB(0xf9f9f9)
#define DDTColorMainBar    UIColorFromRGB(0xeeeeee)
#define DDTColorMainTint   UIColorFromRGB(0xffffff)
#define DDTColorMain      UIColorFromRGB(0x4d728c)


#define DDTColorWhite      UIColorFromRGB(0xffffff)

#define Color_ZUHeBlue          UIColorFromRGB(0x0068b7)
#define Color_ZuHeGray          ColorDarkTitleColor

#define Color_Red               UIColorFromRGB(0xf22c3f)
#define Color_Green             UIColorFromRGB(0x2DB052)
#define Color_Blue              UIColorFromRGB(0x404BC7)
#define Color_Orange            UIColorFromRGB(0xF8AA00)
#define Color_Black             UIColorFromRGB(0x616161)

#define Color_Gray              UIColorFromRGB(0x9C9C9C)

#define Color_Clear             [UIColor clearColor]

#define Color_Purple            UIColorFromRGB(0x448aca)

#define WDColor_red             UIColorFromRGB(0xf22c3f)
#define WDColor_orange          UIColorFromRGB(0xff8019)
#define WDColor_green           UIColorFromRGB(0x3eb55f)
#define WDColor_lightGreen      UIColorFromRGB(0x70e491)
#define WDColor_lightBrown      UIColorFromRGB(0xad9b86)

#define IOS8 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0 ? YES : NO)

#endif /* UIDefine_h */

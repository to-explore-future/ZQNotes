//
//  AppConfig.h
//  worde
//
//  Created by dida on 15/11/11.
//  Copyright © 2015年 wordemotion. All rights reserved.
//

#import <Foundation/Foundation.h>
#define  iOS8 [[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0
#define  iOS7 [[[UIDevice currentDevice] systemVersion] floatValue] < 8.0
#define  iOS9 [[[UIDevice currentDevice] systemVersion] floatValue] >= 8.4
@interface AppConfig : NSObject

+ (void)appInitialize;
+ (NSString *)deviceId;
+ (NSString *)appVersion;
+ (NSString *)innerVersion;
//+ (BOOL)saveAppInfo:(NSDictionary *)info;

@end
